package com.yash.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.yash.entities.Employee;

public class PersistEmployee {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA1");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		Employee e = new Employee() ;
		e.setEmpId(1003);
		e.setEmpName("Sabbir");
		e.setEmpSalary(20321);
		e.setEmpDesignation("Trainer");
		
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		entityManager.persist(e);
		transaction.commit();
		
		entityManager.close();
	}

}
