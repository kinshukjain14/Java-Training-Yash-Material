package com.yash.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.yash.entities.Employee;

public class RetrieveEmployeeById {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA1");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		Query query = entityManager.createNamedQuery("FindEmployee");
		query.setParameter("id", 1003);
		Employee e = (Employee) query.getSingleResult();
		System.out.println(e);
	}
}
