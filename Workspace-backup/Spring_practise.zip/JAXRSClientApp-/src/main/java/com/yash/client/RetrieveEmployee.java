package com.yash.client;

import java.io.StringReader;
import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import com.yash.model.EmployeeResponse;
import com.yash.model.EmployeeResponses;

public class RetrieveEmployee {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		Client client = ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
		WebTarget webTarget = client.target("http://localhost:8081/JAXRSApp/rest/employeeApp").path("/employeesxml");
		Builder builder = webTarget.request(MediaType.APPLICATION_XML);
		Response response = builder.get();
		String readEntity = response.readEntity(String.class);
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(EmployeeResponses.class);
			Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
			EmployeeResponses employeeResponses = (EmployeeResponses) unmarshaller.unmarshal(new StringReader(readEntity));
			List<EmployeeResponse> employeeResponseList = employeeResponses.getEmployeeResponse();
			for (EmployeeResponse employeeResponse : employeeResponseList) {
				System.out.println(employeeResponse);
			}
			
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		
		
	}

}
