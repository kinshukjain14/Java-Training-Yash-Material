package com.yash.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import com.yash.model.EmployeeRequest;
import com.yash.model.EmployeeResponse;

public class RegisterEmployeJSON 
{
	public static void main(String[] args) 
	{
		Client client = ClientBuilder.newClient(new ClientConfig()
				.register(LoggingFilter.class));
		WebTarget webTarget = client.target("http://localhost:8081/JAXRSApp/rest/employeeApp")
				.path("/employeesjson");
		Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_JSON);
		EmployeeRequest employeeRequest = new EmployeeRequest();
		employeeRequest.setEmpId(11890);
		employeeRequest.setEmpName("Suresh Jain");
		employeeRequest.setEmpSalary(98000);
		employeeRequest.setEmpDesignation("Sr. HR Manager");
		Response response = invocationBuilder.post(Entity.entity(employeeRequest, MediaType.APPLICATION_JSON));
		EmployeeResponse employeeResponse = response.readEntity(EmployeeResponse.class);
		System.out.println(employeeResponse);
	}
}
