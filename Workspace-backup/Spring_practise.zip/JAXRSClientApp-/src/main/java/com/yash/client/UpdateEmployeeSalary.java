package com.yash.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.client.WebTarget;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import com.yash.model.EmployeeRequest;
import com.yash.model.EmployeeResponse;

public class UpdateEmployeeSalary {
	public static void main(String[] args) {
		Client client = ClientBuilder.newClient(new ClientConfig()
				.register(LoggingFilter.class));
		WebTarget webTarget = client.target("http://localhost:8081/JAXRSApp/rest/employeeApp")
				.path("/employees")
				.queryParam("empId", 11889)
				.queryParam("empSalary", 77000);
		EmployeeRequest employeeRequest = new EmployeeRequest();
		
		Builder builder = webTarget.request();
		Response response = builder.put(Entity.entity(employeeRequest, MediaType.APPLICATION_JSON));
		EmployeeResponse employeeResponse = response.readEntity(EmployeeResponse.class);
		System.out.println(employeeResponse);
	}
}
