package com.yash.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

import com.yash.model.EmployeeResponse;

public class RetrieveEmployeeByEmpId {
	public static void main(String[] args) {
		Client client = ClientBuilder.newClient(new ClientConfig().register(LoggingFilter.class));
		WebTarget webTarget = client.target("http://localhost:8081/JAXRSApp/rest/employeeApp")
				.path("/employees")
				.path(String.valueOf(101));
		Builder builder = webTarget.request(MediaType.APPLICATION_JSON);
		Response response = builder.get();
		EmployeeResponse employeeResponse = response.readEntity(EmployeeResponse.class);
		System.out.println(employeeResponse);
	}
}
