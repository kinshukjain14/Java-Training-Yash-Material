package com.yash.message;

import java.io.IOException;
import java.io.InputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyReader;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import com.yash.model.EmployeeResponse;

public class EmployeeResponseMessageReader implements MessageBodyReader<EmployeeResponse>{

	public boolean isReadable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		return type==EmployeeResponse.class;
	}

	public EmployeeResponse readFrom(Class<EmployeeResponse> type, Type genericType, Annotation[] annotations,
			MediaType mediaType, MultivaluedMap<String, String> httpHeaders, InputStream entityStream)
			throws IOException, WebApplicationException {
		EmployeeResponse employeeResponse=null;
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(EmployeeResponse.class);
			employeeResponse = (EmployeeResponse) jaxbContext.createUnmarshaller().unmarshal(entityStream);
			return employeeResponse;
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		return employeeResponse;
	}

}
