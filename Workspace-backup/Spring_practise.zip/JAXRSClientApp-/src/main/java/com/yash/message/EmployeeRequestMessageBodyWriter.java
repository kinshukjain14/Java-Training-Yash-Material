package com.yash.message;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.MessageBodyWriter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import com.yash.model.EmployeeRequest;

@Produces("application/xml")
public class EmployeeRequestMessageBodyWriter implements MessageBodyWriter<EmployeeRequest> {

	public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		return type == EmployeeRequest.class;
	}

	public long getSize(EmployeeRequest t, Class<?> type, Type genericType, Annotation[] annotations,
			MediaType mediaType) {
		return 0;
	}

	public void writeTo(EmployeeRequest t, Class<?> type, Type genericType, Annotation[] annotations,
			MediaType mediaType, MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
			throws IOException, WebApplicationException {
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(EmployeeRequest.class);
			jaxbContext.createMarshaller().marshal(t,entityStream);
			
		} catch (JAXBException e) {
			e.printStackTrace();
		}
	}


}
