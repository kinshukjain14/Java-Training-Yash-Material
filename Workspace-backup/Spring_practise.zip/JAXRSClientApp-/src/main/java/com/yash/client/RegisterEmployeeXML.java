package com.yash.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;

import com.yash.message.EmployeeRequestMessageBodyWriter;
import com.yash.message.EmployeeResponseMessageReader;
import com.yash.model.EmployeeRequest;
import com.yash.model.EmployeeResponse;

public class RegisterEmployeeXML {

	public static void main(String[] args) {
		Client client = ClientBuilder.newClient(new ClientConfig()
				.register(EmployeeRequestMessageBodyWriter.class)
				.register(EmployeeResponseMessageReader.class));
		WebTarget webTarget = client.target("http://localhost:8081/JAXRSApp/rest/employeeApp")
				.path("/employeesxml");
		
		Invocation.Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_XML);
		EmployeeRequest employeeRequest = new EmployeeRequest();
		employeeRequest.setEmpId(11889);
		employeeRequest.setEmpName("Mahesh");
		employeeRequest.setEmpSalary(28000);
		employeeRequest.setEmpDesignation("Developer");
		Response response = invocationBuilder.post(Entity.xml(employeeRequest));
		EmployeeResponse employeeResponse = response.readEntity(EmployeeResponse.class);
		System.out.println(employeeResponse);
	}
}
