package com.yash.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import org.glassfish.jersey.client.ClientConfig;
import org.glassfish.jersey.filter.LoggingFilter;

public class EmployeeDelete {
	public static void main(String[] args) {
		Client client = ClientBuilder.newClient(new ClientConfig()
				.register(LoggingFilter.class));
		WebTarget webTarget = client.target("http://localhost:8081/JAXRSApp/rest/employeeApp")
				.path("/employees")
				.matrixParam("empId", 11889);
		Builder builder = webTarget.request();
		Response response = builder.delete();
		String readEntity = response.readEntity(String.class);
		System.out.println(readEntity);
	}
}
