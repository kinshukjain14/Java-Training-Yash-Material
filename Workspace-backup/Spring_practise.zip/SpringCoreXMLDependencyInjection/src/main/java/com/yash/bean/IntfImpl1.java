package com.yash.bean;

public class IntfImpl1 implements Intf {

	public void x() {

		System.out.println("--impl1--");
	}

}
