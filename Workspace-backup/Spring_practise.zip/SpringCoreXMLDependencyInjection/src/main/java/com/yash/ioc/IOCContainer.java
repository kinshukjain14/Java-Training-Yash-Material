package com.yash.ioc;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.yash.bean.Bean1;
import com.yash.bean.Bean4;
import com.yash.bean.BeanCollection;
import com.yash.bean.BeanIntf;
import com.yash.bean.ControllerBean;
import com.yash.bean.ControllerBean1;
import com.yash.bean.DataSource1;
import com.yash.bean.DataSource2;

public class IOCContainer {

	public static void main(String[] args) {

		/*custom code to create object of Bean1
		Bean1 bean1=new Bean1();
		bean1.x();*/
		/*
		Resource resource=new ClassPathResource("applicationContext.xml");
		BeanFactory ioc1=new XmlBeanFactory(resource);
		Bean1 bean1=(Bean1)ioc1.getBean("b1");
		bean1.x();*/
		
		ApplicationContext ioc2=new ClassPathXmlApplicationContext("applicationContext.xml");
		Bean1 bean11=(Bean1)ioc2.getBean("b1");
		bean11.x();
		
		Bean1 bean12=(Bean1)ioc2.getBean("b1");
		bean12.x();
		
		if(bean11==bean12)
		{
			System.out.println("Both references point to same object.i.e Singleton Scope");
		}
		
		Bean1 beanPrototype1=(Bean1)ioc2.getBean("b2");
		Bean1 beanPrototype2=(Bean1)ioc2.getBean("b2");
		
		if(beanPrototype1!=beanPrototype2)
		{
			System.out.println("Both references point to different object.i.e Prototype Scope");
		}
		
		Bean1 bean13=(Bean1)ioc2.getBean("alias1");
		bean13.x();
		
		Bean1 bean14=(Bean1)ioc2.getBean("alias2");
		bean14.x();
		
//		ApplicationContext ioc3=
//				new FileSystemXmlApplicationContext("d:\\javainductionio\\spring\\beans.xml");
//		
//		Bean1 bean15=(Bean1)ioc3.getBean("b1");
//		bean15.x();
		

		ApplicationContext mainIOC=new ClassPathXmlApplicationContext("main.xml");
		Bean1 bean16=(Bean1)mainIOC.getBean("b1");
		bean16.x();
		
		AbstractApplicationContext ioc4=new ClassPathXmlApplicationContext("applicationContext.xml");
		Bean1 bean17=(Bean1)ioc4.getBean("b3");
		bean17.x();
		ioc4.registerShutdownHook();
		
		ApplicationContext ioc5=new ClassPathXmlApplicationContext("applicationContext.xml");
		Bean1 bean18=(Bean1)ioc5.getBean("b4");
		bean18.x();
	

		
        DataSource1 dataSource1=(DataSource1)ioc5.getBean("datasource1");
        System.out.println(dataSource1);
	    
	
        DataSource2 dataSource2=(DataSource2)ioc5.getBean("datasource2");
        System.out.println(dataSource2);
        
        BeanIntf beanIntf=(BeanIntf)ioc5.getBean("beanintf");
        beanIntf.beanMethod();
        
        DataSource1 dataSource11=(DataSource1)ioc5.getBean("datasource11");
        System.out.println(dataSource11);

        DataSource2 dataSource21=(DataSource2)ioc5.getBean("datasource21");
        System.out.println(dataSource21);
        
        BeanCollection beancollection=(BeanCollection)ioc5.getBean("beancollection");
        System.out.println(beancollection);
        /*
        ControllerBean controllerBean=(ControllerBean)ioc5.getBean("controllerbean");
        controllerBean.controllerMethod();
        
        ControllerBean1 controllerBean1=(ControllerBean1)ioc5.getBean("controllerbean1");
        controllerBean1.controllerMethod1();
        */
        ControllerBean1 controllerbeanAuto=(ControllerBean1)ioc5.getBean("controllerbeanauto");
        controllerbeanAuto.controllerMethod1();
        
        Bean4 bean4=(Bean4)ioc5.getBean("bean4");
        bean4.bean4Method();
	}

}
