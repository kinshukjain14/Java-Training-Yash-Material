package com.yash.ioc;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.bean.PrototypeBean;

public class AbstractIOContainer {

	public static void main(String[] args) {

		AbstractApplicationContext ioc=new ClassPathXmlApplicationContext("applicationContext.xml");
		PrototypeBean prototypeBean=(PrototypeBean)ioc.getBean("prototypebean");
		ioc.registerShutdownHook();
	}

}
