package com.yash.bean;

public class Bean4 {
	
	private Intf intf;

	public Intf getIntf() {
		return intf;
	}

	public void setIntf(Intf intf) {
		this.intf = intf;
	}
	
	public void bean4Method() {
		intf.x();
	}

}
