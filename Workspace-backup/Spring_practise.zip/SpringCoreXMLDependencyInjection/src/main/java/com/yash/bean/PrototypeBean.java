package com.yash.bean;

import org.springframework.beans.factory.DisposableBean;

public class PrototypeBean implements DisposableBean {
	
	public PrototypeBean() {
		System.out.println("---PrototypeBean constructor---");
	}
	
	public void initMethod() {
		System.out.println("--PrototypeBean initMethod--");
	}
	public void destroyMethod() {
		System.out.println("--PrototypeBean destroyMethod--");
	}

	public void destroy() throws Exception {
		destroyMethod();
	}
	
	

}
