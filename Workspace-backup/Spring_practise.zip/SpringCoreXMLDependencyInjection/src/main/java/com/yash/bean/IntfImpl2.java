package com.yash.bean;

public class IntfImpl2 implements Intf {

	public void x() {
	System.out.println("--impl2--");
	}

}
