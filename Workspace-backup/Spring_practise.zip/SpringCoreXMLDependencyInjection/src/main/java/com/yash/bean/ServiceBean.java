package com.yash.bean;

public class ServiceBean {
	
	private DataBean dataBean;
	
	public ServiceBean(DataBean dataBean) {
		super();
		this.dataBean = dataBean;
	}


	public void serviceMethod() {
		dataBean.dataMethod();
	}

}
