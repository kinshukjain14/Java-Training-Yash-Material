package com.yash.bean;

public class DataBean1 {

	public void dataMethod1() {
		System.out.println("--data method 1--");
	}
	
}
