package com.yash.bean;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class BeanCollection {
	
	private List<String> cityNames;
	private Set<String> countryNames;
	private Map<String,String> regionNames;
	
	public BeanCollection() {}

	public List<String> getCityNames() {
		return cityNames;
	}

	public void setCityNames(List<String> cityNames) {
		this.cityNames = cityNames;
	}

	public Set<String> getCountryNames() {
		return countryNames;
	}

	public void setCountryNames(Set<String> countryNames) {
		this.countryNames = countryNames;
	}

	public Map<String, String> getRegionNames() {
		return regionNames;
	}

	public void setRegionNames(Map<String, String> regionNames) {
		this.regionNames = regionNames;
	}

	@Override
	public String toString() {
		return "BeanCollection [cityNames=" + cityNames + ", countryNames=" + countryNames + ", regionNames="
				+ regionNames + "]";
	}
	
	

}
