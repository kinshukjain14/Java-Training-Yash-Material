package com.yash.bean;

public interface Intf {

	public void x();
}
