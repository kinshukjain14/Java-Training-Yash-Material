package com.yash.bean;

public class ServiceBean1 {
	
	private DataBean1 dataBean1;
	
	public DataBean1 getDataBean1() {
		return dataBean1;
	}
	public void setDataBean1(DataBean1 dataBean1) {
		this.dataBean1 = dataBean1;
	}

	public void serviceMethod1() {
		dataBean1.dataMethod1();
	}
}
