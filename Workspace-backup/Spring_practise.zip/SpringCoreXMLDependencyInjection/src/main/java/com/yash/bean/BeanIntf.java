package com.yash.bean;

public interface BeanIntf {
	
	public void beanMethod();

}
