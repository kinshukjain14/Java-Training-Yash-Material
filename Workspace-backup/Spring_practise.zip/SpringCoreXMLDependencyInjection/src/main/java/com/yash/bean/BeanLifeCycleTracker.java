package com.yash.bean;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class BeanLifeCycleTracker  implements BeanPostProcessor,InitializingBean,DisposableBean,BeanFactoryAware{

	private BeanFactory beanFactory;
	Map<String,Object> beanMap=new HashMap<String,Object>();
	
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("--bean before initialization--"+beanName);
		return bean;
	}
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("--bean after initialization--"+beanName);
		synchronized(beanMap) {
			beanMap.put(beanName, bean);
		}
		
		return bean;
	}
	public void afterPropertiesSet() throws Exception {

		System.out.println("--after propertiesSet---");
	}
	public void destroy() throws Exception {
		Set<Map.Entry<String,Object>> set=beanMap.entrySet();
		Iterator<Map.Entry<String,Object>> iterator=set.iterator();
		while(iterator.hasNext()) {
			Map.Entry<String,Object> me=(Map.Entry<String,Object>)iterator.next();
			if(beanFactory.isPrototype(me.getKey())&& me.getKey().equals("prototypebean")) {
				if(me.getValue() instanceof DisposableBean) {
					DisposableBean disposable=(DisposableBean)me.getValue();
					disposable.destroy();
				}
			}
		}
		
	}
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		this.beanFactory=beanFactory;		
	}
}
