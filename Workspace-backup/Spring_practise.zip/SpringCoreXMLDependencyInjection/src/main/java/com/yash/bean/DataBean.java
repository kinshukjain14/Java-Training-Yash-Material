package com.yash.bean;

public class DataBean {
	public DataBean() {}
	public void dataMethod() {
		System.out.println("--data method--");
	}
}
