package com.yash.bean;

public class ControllerBean {

	private ServiceBean serviceBean;
	
	
	public ControllerBean(ServiceBean serviceBean) {
		super();
		this.serviceBean = serviceBean;
	}


	public void controllerMethod() {
		serviceBean.serviceMethod();
	}
}
