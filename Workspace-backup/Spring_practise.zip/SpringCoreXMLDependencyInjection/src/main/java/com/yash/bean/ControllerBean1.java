package com.yash.bean;

public class ControllerBean1 {
	
	private ServiceBean1 serviceBean1;

	public ServiceBean1 getServiceBean1() {
		return serviceBean1;
	}
	public void setServiceBean1(ServiceBean1 serviceBean1) {
		this.serviceBean1 = serviceBean1;
	}
	public void controllerMethod1() {
		serviceBean1.serviceMethod1();
	}
}
