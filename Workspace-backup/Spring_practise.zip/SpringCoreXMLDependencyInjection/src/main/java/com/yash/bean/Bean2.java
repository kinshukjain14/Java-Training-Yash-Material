package com.yash.bean;

public class Bean2 implements BeanIntf {

	public void beanMethod() {
		System.out.println("--beanMethod--");
	}

}
