package com.yash.bean;

public class Bean1 {

	public Bean1() {
		System.out.println("--Bean1 constructor--");
	}
	
	public void initMethod() {
		System.out.println("--initMethod--");
	}
	public void destroyMethod() {
		System.out.println("--destroyMethod--");
	}
	
	public static Bean1 createInstance() {
		System.out.println("--createInstance--");
		Bean1 bean1=new Bean1();
		return bean1;
	}
	public void x() {
		System.out.println("--x--");
	}
}
