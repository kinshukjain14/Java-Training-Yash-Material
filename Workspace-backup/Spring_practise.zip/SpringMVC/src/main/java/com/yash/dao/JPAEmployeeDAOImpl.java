package com.yash.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.entity.Employee;
//@Repository("jPAEmployeeDAOImpl")
public class JPAEmployeeDAOImpl implements EmployeeDAO {
	
	@Autowired
	private EntityManagerFactory entityManagerFactory;

	public List<Employee> getAllEmployees() {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Query query=entityManager.createNamedQuery("FindAllEmployees");
        List<Employee> employeeList=query.getResultList();
        entityManager.close();
		return employeeList;
	}

	public Employee getEmployeeById(int empId) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Query query=entityManager.createNamedQuery("FindEmployee");
		query.setParameter("id", empId);
		Employee employee=(Employee)query.getSingleResult();
		return employee;
	}

	public boolean persistEmployee(Employee employee) {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
        EntityTransaction entityTransaction=entityManager.getTransaction();
        entityTransaction.begin();
        entityManager.persist(employee);
        entityTransaction.commit();
        
        Query query=entityManager.createNamedQuery("FindEmployee");
        query.setParameter("id", employee.getEmpId());
        Employee employeeDB=(Employee)query.getSingleResult();
        if(employee.getEmpId()==employeeDB.getEmpId()) {
        	return true;
        }
		return false;
	}

	public boolean updateEmployeeSalaryById(int empId, double empSalary) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		return false;
	}

	public List<String> getEmployeeDesignations() {
		EntityManager entityManager=entityManagerFactory.createEntityManager();
        Query query=entityManager.createNativeQuery("select designation_name from designation");
        List<String> designationList=query.getResultList();
        entityManager.close();
		return designationList;
	}

	public boolean checkEmpId(int empId) {

		List<Employee> employeeList=getAllEmployees();
		for(Employee employee:employeeList) {
			if(employee.getEmpId()==empId) {
				return true;
			}
		}
		
		return false;
	}

}
