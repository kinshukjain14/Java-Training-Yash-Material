package com.yash.model;

public class DesignationModel {
	
	public DesignationModel() {}
	
	private String designationName;

	public String getDesignationName() {
		return designationName;
	}

	public void setDesignationName(String designationName) {
		this.designationName = designationName;
	}

	@Override
	public String toString() {
		return "DesignationtModel [designationName=" + designationName + "]";
	}

	

}
