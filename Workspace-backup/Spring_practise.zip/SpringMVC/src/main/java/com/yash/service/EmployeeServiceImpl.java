package com.yash.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.yash.dao.EmployeeDAO;
import com.yash.entity.Employee;
import com.yash.model.DesignationModel;
import com.yash.model.EmployeeModel;
@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired@Qualifier("hibernateEmployeeDAOImpl")
	private EmployeeDAO employeeDAO;
	
	public List<EmployeeModel> getEmployeesModel() {
       List<Employee> employeeList=employeeDAO.getAllEmployees();
       List<EmployeeModel> employeeModelList=new ArrayList<EmployeeModel>();
       for(Employee employee:employeeList) {
    	   EmployeeModel model=new EmployeeModel();
    	   model.setEmpId(employee.getEmpId());
    	   model.setEmpName(employee.getEmpName());
    	   model.setEmpSalary(employee.getEmpSalary());
    	   model.setEmpDesignation(employee.getEmpDesignation());
    	   employeeModelList.add(model);
       }
		return employeeModelList;
	}

	public EmployeeModel getEmployeeId(int empId) {
		   Employee employee=employeeDAO.getEmployeeById(empId);
		   EmployeeModel model=new EmployeeModel();
    	   model.setEmpId(employee.getEmpId());
    	   model.setEmpName(employee.getEmpName());
    	   model.setEmpSalary(employee.getEmpSalary());
    	   model.setEmpDesignation(employee.getEmpDesignation());
		return model;
	}

	public String persistEmployee(EmployeeModel employeeModel) {

		Employee employee=new Employee();
		employee.setEmpId(employeeModel.getEmpId());
		employee.setEmpName(employeeModel.getEmpName());
		employee.setEmpSalary(employeeModel.getEmpSalary());
		employee.setEmpDesignation(employeeModel.getEmpDesignation());
		boolean result=employeeDAO.persistEmployee(employee);
		if(result)
			return "success";
		else
			return "fail";
		
		}

	public String updateEmployeeSalary(int empId, double empSalary) {
		boolean result=employeeDAO.updateEmployeeSalaryById(empId, empSalary);
		if(result)
			return "success";
		else
			return "fail";
		
		}
	

	public String deleteEmployee(int empId) {
		boolean result=employeeDAO.deleteEmployee(empId);
		if(result)
			return "success";
		else
			return "fail";
	}

	public List<String> getDesignationNames() {
        List<String> designationNames=employeeDAO.getEmployeeDesignations();
		return designationNames;
	}

	public boolean checkEmpId(int empId) {
		return employeeDAO.checkEmpId(empId);
	}

}
