package com.yash.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.yash.entity.Employee;
import com.yash.helper.EmployeeDBQuery;
@Repository("springJDBCEmployeeDAOImpl")
public class SpringJDBCEmployeeDAOImpl implements EmployeeDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private EmployeeDBQuery query;

	@Autowired@Qualifier("employeeRowMapper")
	private RowMapper<Employee> employeeRowMapper;
	@Autowired@Qualifier("designationNameMapper")
	private RowMapper<String> desginationRowMapper;
	@Autowired@Qualifier("employeeIdMapper")
	private RowMapper<Integer> rowIdMapper;
	
	public List<Employee> getAllEmployees() {
		List<Employee> employeeList=jdbcTemplate.query(query.getSelectEmployeeQuery(), employeeRowMapper);
		return employeeList;
	}

	public Employee getEmployeeById(int empId) {
		Employee employee=jdbcTemplate.queryForObject(query.getSelectEmployeeByIdQuery(), new Object[] {empId},  employeeRowMapper);
		return employee;
	}

	public boolean persistEmployee(Employee employee) {
		int rows=jdbcTemplate.update(query.getInsertEmployeeQuery(),new Object[] {employee.getEmpId(),employee.getEmpName(),employee.getEmpSalary(),employee.getEmpDesignation()});
		if(rows>0)
		return true;
		else
		return false;
	}

	public boolean updateEmployeeSalaryById(int empId, double empSalary) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		return false;
	}

	public List<String> getEmployeeDesignations() {
		List<String> designationList=jdbcTemplate.query(query.getSelectEmployeeDesignationQuery(), desginationRowMapper);
		return designationList;
	}

	public boolean checkEmpId(int empId) {
		List<Integer> employeeList=jdbcTemplate.query(query.getCheckEmpIdQuery(), new Object[] {empId},rowIdMapper);
		if(!employeeList.isEmpty())
		return true;
		else
		return false;
	}

}
