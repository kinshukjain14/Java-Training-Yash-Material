package com.yash.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.entity.Employee;
@Repository("hibernateEmployeeDAOImpl")
public class HibernateEmployeeDAOImpl implements EmployeeDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	public List<Employee> getAllEmployees() {
		Session session=sessionFactory.openSession();
        Query query=session.createQuery("from Employee o");
        List<Employee> employeeList=query.list();
        session.close();
		return employeeList;
	}

	public Employee getEmployeeById(int empId) {
		Session session=sessionFactory.openSession();
		Employee employee=(Employee) session.load(Employee.class, empId);
		System.out.println(employee);
		session.close();
		return employee;
	}

	public boolean persistEmployee(Employee employee) {
		Session session=sessionFactory.openSession();
        Transaction transaction=session.getTransaction();
        transaction.begin();
        session.persist(employee);
        transaction.commit();
       
       Employee employeeDB=(Employee)session.load(Employee.class, employee.getEmpId());
       session.close();
       if(employee.getEmpId()==employeeDB.getEmpId()) {
    	   return true;
       }
		return false;
	}

	public boolean updateEmployeeSalaryById(int empId, double empSalary) {
		Session session = sessionFactory.openSession();
		Employee employee = (Employee)session.get(Employee.class, empId);
		if(employee !=null) {
			employee.setEmpSalary(empSalary);
			Transaction transaction = session.getTransaction();
			transaction.begin();
			Employee updatedEmployee = (Employee) session.merge(employee);
			if(updatedEmployee.getEmpSalary() == empSalary) {
				transaction.commit();
				session.close();
				return true;
			}			
		}
		session.close();
		return false;
	}

	public boolean deleteEmployee(int empId) {
		Session session=sessionFactory.openSession();
		Employee employee = (Employee)session.load(Employee.class,empId);
		Transaction transaction = session.getTransaction();
		
		if(employee!=null) {
			transaction.begin();
			session.delete(employee);
			transaction.commit();
		}
		Employee employeeById =(Employee)session.get(Employee.class,empId); 
		session.close();
		if(employeeById == null) {
			return true;
		}
		return false;
	}

	public List<String> getEmployeeDesignations() {
		Session session=sessionFactory.openSession();
		Query query=session.createSQLQuery("select designation_name from designation");
		List<String> designationList=query.list();
		return designationList;
	}

	public boolean checkEmpId(int empId) {
		List<Employee> employeeList=getAllEmployees();
		for(Employee employee:employeeList) {
			if(employee.getEmpId()==empId)
			{
				return true;
			}
		}
		return false;
	}

}
