package com.yash.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import com.yash.configuration.ClientConfiguration;

@SpringBootApplication(scanBasePackages = "com.yash.*")
@Import({ClientConfiguration.class})
public class SpringBootRestClientAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestClientAppApplication.class, args);
	}

}
