package com.yash.controller;

import java.nio.charset.Charset;
import java.util.Base64;
import java.util.Base64.Encoder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.yash.model.EmployeeRequest;
import com.yash.model.EmployeeResponse;

@RestController
@RequestMapping("clientApi")
public class ClientController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping("clientemployees")
	public ResponseEntity<EmployeeResponse[]> handleAllEmployees(){
		HttpHeaders headers = new HttpHeaders();
		
		String auth="user"+":"+"user123";
		
		Encoder encoder = Base64.getEncoder();
		byte[]encodeAuth = encoder.encode(auth.getBytes((Charset.forName("US-ASCII"))));
//		byte[] encodeAuth = org.apache.tomcat.util.codec.binary.Base64.encodeBase64(auth.getBytes((Charset.forName("US-ASCII"))));
		String authHeader  = "Basic "+new String(encodeAuth);
		headers.add("Authorization", authHeader);
		
		headers.setContentType(MediaType.APPLICATION_JSON);
		String uri = "http://localhost:8082/employeeApp/api/employees";
		HttpEntity<String> requestEntity = new HttpEntity<String>(headers);
		ResponseEntity<EmployeeResponse[]> responseEntity = restTemplate.exchange(uri, HttpMethod.GET,requestEntity,EmployeeResponse[].class);
		EmployeeResponse[] employeeResponses = responseEntity.getBody();
		return new ResponseEntity<EmployeeResponse[]>(employeeResponses,HttpStatus.OK);
	}
	
	@GetMapping("clientemployees/{empId}")
	public ResponseEntity<EmployeeResponse> getEmployee(@PathVariable("empId") int empId){
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		String uri = "http://localhost:8082/employeeApp/api/employees/{empId}";
		HttpEntity<String> requestEntity = new HttpEntity<String>(headers);
		ResponseEntity<EmployeeResponse> responseEntity = restTemplate.exchange(uri, HttpMethod.GET,requestEntity,EmployeeResponse.class,empId);
		EmployeeResponse employeeResponse = responseEntity.getBody();
		
		return new ResponseEntity<EmployeeResponse>(employeeResponse,HttpStatus.OK);
	}
	
	@PostMapping("clientemployees")
	public ResponseEntity<EmployeeResponse> registerEmployee(@RequestBody EmployeeRequest employeeRequest){
		String uri = "http://localhost:8082/employeeApp/api/employees";
		
		HttpHeaders headers = new HttpHeaders();
		String auth="admin"+":"+"admin123";
		
//		Encoder encoder = Base64.getEncoder();
//		byte[]encodeAuth = encoder.encode(auth.getBytes((Charset.forName("US-ASCII"))));
		byte[] encodeAuth = org.apache.tomcat.util.codec.binary.Base64.encodeBase64(auth.getBytes((Charset.forName("US-ASCII"))));
		String authHeader  = "Basic "+new String(encodeAuth);
		headers.add("Authorization", authHeader);
		
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<EmployeeRequest> httpEntity = new HttpEntity<>(employeeRequest,headers);
		EmployeeResponse employeeResponse = restTemplate.postForObject(uri, httpEntity, EmployeeResponse.class);
		ResponseEntity<EmployeeResponse> responseEntity = new ResponseEntity<>(employeeResponse,HttpStatus.CREATED);
		return responseEntity;
	}
	
	@PutMapping("clientemployees")
	public ResponseEntity<String> updateEmployee(@RequestBody EmployeeRequest employeeRequest) {
		String uri = "http://localhost:8082/employeeApp/api/employees";
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<EmployeeRequest> httpEntity = new HttpEntity<>(employeeRequest,headers);
		
		try {
			restTemplate.put(uri,httpEntity);
			return new ResponseEntity<String>("Employee record updated",HttpStatus.ACCEPTED);
		}
		catch(Exception e) {
			return new ResponseEntity<String>("Employee not updated",HttpStatus.NOT_MODIFIED);
			
		}
	}
	
	@DeleteMapping("clientemployees/{empId}")
	public ResponseEntity<String> deleteEmployee(@PathVariable("empId") int empId){
		String uri = "http://localhost:8082/employeeApp/api/employees/{empId}";
		try {
			restTemplate.delete(uri,empId);
			return new ResponseEntity<String>("Employee resource deleted",HttpStatus.ACCEPTED);
		}
		catch (Exception e) {
			return new ResponseEntity<String>("Employee resource not removed",HttpStatus.BAD_REQUEST);
		}
	}
	
}
