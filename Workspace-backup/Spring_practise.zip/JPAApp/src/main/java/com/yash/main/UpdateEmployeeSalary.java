package com.yash.main;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class UpdateEmployeeSalary {

	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA1");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();
		Query query=entityManager.createNamedQuery("UpdateSalary");
		query.setParameter(1, 45000D);
		query.setParameter(2, 1001);
		
		int rows=query.executeUpdate();
		entityTransaction.commit();
		System.out.println("Rows updated:"+rows);
	}

}
