package com.yash.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.yash.entities.Employee;

public class RetrieveAllEmployeeNamedQuery {

	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA1");
		EntityManager entityManager=entityManagerFactory.createEntityManager();
		Query query=entityManager.createNamedQuery("FindAllEmployees");
		List<Employee> empList=query.getResultList();
		for(Employee e:empList) {
			System.out.println(e);
		}
	}
	}


