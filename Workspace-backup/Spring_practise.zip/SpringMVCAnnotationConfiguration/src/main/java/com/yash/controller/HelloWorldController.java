package com.yash.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloWorldController {
	
	@RequestMapping(value = "hello.htm",method = RequestMethod.GET)
	public ModelAndView sayHello() {
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("message","HelloWorld!");
		modelAndView.setViewName("hellopage");
		return modelAndView;
	}

}
