package com.yash.helper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class EmployeeDBQuery {
	
	@Value("${selectEmployeeQuery}")
	private String selectEmployeeQuery;
	@Value("${insertEmployeeQuery}")
	private String insertEmployeeQuery;
	@Value("${updateEmployeeQuery}")
	private String updateEmployeeQuery;
	@Value("${deleteEmployeeQuery}")
	private String deleteEmployeeQuery;
	@Value("${selectEmployeeByIdQuery}")
	private String selectEmployeeByIdQuery;
	@Value("${selectEmployeeDesignationQuery}")
	private String selectEmployeeDesignationQuery;
	@Value("${checkEmpIdQuery}")
	private String checkEmpIdQuery;
	
	public EmployeeDBQuery() {}


	public String getSelectEmployeeQuery() {
		return selectEmployeeQuery;
	}


	public void setSelectEmployeeQuery(String selectEmployeeQuery) {
		this.selectEmployeeQuery = selectEmployeeQuery;
	}


	public String getInsertEmployeeQuery() {
		return insertEmployeeQuery;
	}


	public void setInsertEmployeeQuery(String insertEmployeeQuery) {
		this.insertEmployeeQuery = insertEmployeeQuery;
	}


	public String getUpdateEmployeeQuery() {
		return updateEmployeeQuery;
	}


	public void setUpdateEmployeeQuery(String updateEmployeeQuery) {
		this.updateEmployeeQuery = updateEmployeeQuery;
	}


	public String getDeleteEmployeeQuery() {
		return deleteEmployeeQuery;
	}


	public void setDeleteEmployeeQuery(String deleteEmployeeQuery) {
		this.deleteEmployeeQuery = deleteEmployeeQuery;
	}


	public String getSelectEmployeeByIdQuery() {
		return selectEmployeeByIdQuery;
	}


	public void setSelectEmployeeByIdQuery(String selectEmployeeByIdQuery) {
		this.selectEmployeeByIdQuery = selectEmployeeByIdQuery;
	}


	public String getSelectEmployeeDesignationQuery() {
		return selectEmployeeDesignationQuery;
	}


	public void setSelectEmployeeDesignationQuery(String selectEmployeeDesignationQuery) {
		this.selectEmployeeDesignationQuery = selectEmployeeDesignationQuery;
	}


	public String getCheckEmpIdQuery() {
		return checkEmpIdQuery;
	}


	public void setCheckEmpIdQuery(String checkEmpIdQuery) {
		this.checkEmpIdQuery = checkEmpIdQuery;
	}


	@Override
	public String toString() {
		return "EmployeeDBQuery [selectEmployeeQuery=" + selectEmployeeQuery + ", insertEmployeeQuery="
				+ insertEmployeeQuery + ", updateEmployeeQuery=" + updateEmployeeQuery + ", deleteEmployeeQuery="
				+ deleteEmployeeQuery + ", selectEmployeeByIdQuery=" + selectEmployeeByIdQuery
				+ ", selectEmployeeDesignationQuery=" + selectEmployeeDesignationQuery + ", checkEmpIdQuery="
				+ checkEmpIdQuery + "]";
	}


	
	
	
}
