package com.yash.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.yash.model.EmployeeModel;
import com.yash.service.EmployeeService;

@Component("employeeModelValidator")
public class EmployeeModelValidator implements Validator {

	@Autowired
	private EmployeeService employeeService;
	
	public boolean supports(Class<?> clazz) {
		return clazz.equals(EmployeeModel.class);
	}

	public void validate(Object target, Errors errors) {
		EmployeeModel model=(EmployeeModel)target;
		boolean result=employeeService.checkEmpId(model.getEmpId());
		if(result) {
			errors.rejectValue("empId", "com.yash.model.EmployeeModel.empId.error");
		}
		double salary=model.getEmpSalary();
		if(salary<25000) {
			errors.rejectValue("empSalary", "com.yash.model.EmployeeModel.empSalary.error");

		}
		String empName=model.getEmpName();
		if(empName.length()<4) {
			errors.rejectValue("empName", "com.yash.model.EmployeeModel.empName.length");

		}
	}

 
}
