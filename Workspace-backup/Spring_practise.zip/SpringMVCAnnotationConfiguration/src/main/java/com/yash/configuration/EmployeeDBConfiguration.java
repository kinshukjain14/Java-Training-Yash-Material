package com.yash.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.yash.integrate.DataSource;


@Configuration
@ComponentScan(basePackages = "com.yash.*")
@PropertySource({"classpath:/db.properties","classpath:/sql.properties"})
//@ImportResource("classpath:/applicationContext.xml")
//@Import(SomeOtherConfiguration.class)
public class EmployeeDBConfiguration {
	
	@Autowired
	private DataSource dataSource;
	
	@Bean
	public JdbcTemplate jdbcTemplate() {
		DriverManagerDataSource driverManagerDataSource = new DriverManagerDataSource();
		driverManagerDataSource.setDriverClassName(dataSource.getDriver());
		driverManagerDataSource.setUrl(dataSource.getUrl());
		driverManagerDataSource.setUsername(dataSource.getUsername());
		driverManagerDataSource.setPassword(dataSource.getPassword());
		
		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		jdbcTemplate.setDataSource(driverManagerDataSource);
		return jdbcTemplate;
	}

}
