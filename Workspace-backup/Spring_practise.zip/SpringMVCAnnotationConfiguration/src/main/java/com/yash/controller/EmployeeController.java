package com.yash.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.yash.model.EmployeeModel;
import com.yash.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@Autowired@Qualifier("employeeModelValidator")
	private Validator validator;

	@RequestMapping(value = "getEmployees.htm",method=RequestMethod.GET)
	public ModelAndView handleGetAllEmployee() {
		ModelAndView modelAndView=new ModelAndView();
		List<EmployeeModel> modelList=employeeService.getEmployeesModel();
		modelAndView.addObject("modelList",modelList);
		modelAndView.setViewName("employeedetails");
		boolean flag=false;
		if(flag) {
		throw new RuntimeException("exception occurred");}

		return modelAndView;
	}
	@RequestMapping(value="getEmployeeByIdForm.htm",method=RequestMethod.GET)
	public String loadEmployeeByIdForm() {
		return "employeeidform";
	}
	@RequestMapping(value = "getEmployeeById.htm",method=RequestMethod.GET)
	public ModelAndView handleGetEmployeeById(HttpServletRequest request) {
		int empId=Integer.parseInt(request.getParameter("empId"));
		EmployeeModel model=employeeService.getEmployeeId(empId);
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("employeemodel",model);
		modelAndView.setViewName("employeeinfo");
		return modelAndView;
	}

	@RequestMapping(value="getEmployeeRegisterForm.htm",method=RequestMethod.GET)
	public String loadEmployeeRegisterForm() {
		return "employeeregisterform";
	}
    
    @ModelAttribute("employeemodel")
    public EmployeeModel defaultEmployeeModelObject() {
    	EmployeeModel model=new EmployeeModel();
    	model.setEmpId(0);
    	model.setEmpName("Type firstname lastname");
    	model.setEmpSalary(0.0);
    	return model;
    }
    
    @ModelAttribute("designationList")
    public List<String> getEmployeeDesignations(){
    	System.out.println(employeeService.getDesignationNames());
    	return employeeService.getDesignationNames();
    }
    
    @RequestMapping(value="register.htm",method = RequestMethod.POST)
    public ModelAndView registerEmployee(@ModelAttribute("employeemodel")EmployeeModel employeeModel,Errors errors) {
    	ModelAndView modelAndView=new ModelAndView();

    	ValidationUtils.invokeValidator(validator, employeeModel, errors);
    	if(errors.hasErrors()) {
        	modelAndView.setViewName("employeeregisterform");
    	}else {
    	String result=employeeService.persistEmployee(employeeModel);
    	if(result.equals("success")) {
    	modelAndView.addObject("message","Registration successful");
    	}else {
        	modelAndView.addObject("message","Registration was unsuccessful");

    	}
    	modelAndView.setViewName("employeeregisterform");
    	}
    	return modelAndView;
    }
    @ExceptionHandler(Exception.class)
    public ModelAndView handlerOfException(Exception e) {
    	ModelAndView modelAndView=new ModelAndView();
    	modelAndView.addObject("message",e.getMessage());
    	modelAndView.setViewName("error");
    	return modelAndView;
    }

}
