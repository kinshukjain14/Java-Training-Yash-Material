package com.yash.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.yash.entity.Employee;
import com.yash.helper.EmployeeDBQuery;
@Repository("springJDBCEmployeeDAOImpl")
public class SpringJDBCEmployeeDAOImpl implements EmployeeDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private EmployeeDBQuery queries;
	
	@Autowired@Qualifier("employeeRowMapper")
	private RowMapper<Employee> employeeRowMapper;
	@Autowired@Qualifier("designationNameMapper")
	private RowMapper<String> desginationNameMapper;
	@Autowired@Qualifier("employeeIdMapper")
	private RowMapper<Integer> rowIdMapper;
	
	public List<Employee> getAllEmployees() {
		List<Employee> list = jdbcTemplate.query(queries.getSelectEmployeeQuery(), employeeRowMapper);
		return list;
	}

	public Employee getEmployeeById(int empId) {
		Employee employee = jdbcTemplate.queryForObject(queries.getSelectEmployeeByIdQuery(), new Object[] {empId}, employeeRowMapper);
		return employee;
	}

	public boolean persistEmployee(Employee employee) {
		int rows = jdbcTemplate.update(queries.getInsertEmployeeQuery(), employee.getEmpId(), employee.getEmpName(),
				employee.getEmpSalary(), employee.getEmpDesignation());
		if(rows>0)
			return true;
		return false;
	}

	public boolean updateEmployeeSalaryById(int empId, double empSalary) {
		int rows = jdbcTemplate.update(queries.getSelectEmployeeQuery(),new Object[] {empSalary,empId});
		if(rows>0)
			return true;
		return false;
	}

	public boolean deleteEmployee(int empId) {
		int rows = jdbcTemplate.update(queries.getDeleteEmployeeQuery(),new Object[]{empId});
		if(rows>0)
			return true;
		return false;
	}

	public List<String> getEmployeeDesignations() {
		List<String> designationList = jdbcTemplate.query(queries.getSelectEmployeeDesignationQuery(),desginationNameMapper);
		return designationList;
	}

	public boolean checkEmpId(int empId) {
		List<Integer> integer = jdbcTemplate.query(queries.getCheckEmpIdQuery(), new Object[] {empId}, rowIdMapper);
		if(integer.isEmpty()) {
			return true;
		}
		return false;
	}

}
