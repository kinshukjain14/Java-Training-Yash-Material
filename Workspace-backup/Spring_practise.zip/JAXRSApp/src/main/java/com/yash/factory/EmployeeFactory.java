package com.yash.factory;

import com.yash.dao.EmployeeDAO;
import com.yash.dao.JDBCEmployeeDAOImpl;
import com.yash.service.EmployeeService;
import com.yash.service.EmployeeServiceImpl;

public class EmployeeFactory {

	public static EmployeeDAO createEmployeeDAO() {
		EmployeeDAO employeeDAO=new JDBCEmployeeDAOImpl();
		return employeeDAO;
	}
	public static EmployeeService createEmployeeService() {
		EmployeeService employeeService=new EmployeeServiceImpl();
		return employeeService;
	}
}
