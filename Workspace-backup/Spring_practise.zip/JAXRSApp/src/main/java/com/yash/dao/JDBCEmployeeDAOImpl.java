package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.yash.entities.Employee;
import com.yash.helper.ConnectionManager;

public class JDBCEmployeeDAOImpl implements EmployeeDAO {

	ConnectionManager manager=new ConnectionManager();
	public List<Employee> getAllEmployees() {
		Connection connection=manager.openConnection();
		List<Employee> employeeList=new ArrayList<Employee>();
		Statement statement;
		try {
			statement = connection.createStatement();
		
		ResultSet resultSet=statement.executeQuery("select * from emp");
		while(resultSet.next()) {
			Employee employee=new Employee();
			employee.setEmpId(resultSet.getInt("emp_id"));
			employee.setEmpName(resultSet.getString("emp_name"));
			employee.setEmpSalary(resultSet.getDouble("emp_salary"));
			employee.setEmpDesignation(resultSet.getString("emp_designation"));
			employeeList.add(employee);
		}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		manager.closeConnection();
		return employeeList;
	}
	public Employee getEmployee(int empId) {
		Connection connection=manager.openConnection();
		PreparedStatement statement;
		Employee employee=new Employee();
		try {
			statement = connection.prepareStatement("select * from emp where emp_id=?");
		    statement.setInt(1, empId);
		ResultSet resultSet=statement.executeQuery();
		while(resultSet.next()) {
			employee.setEmpId(resultSet.getInt("emp_id"));
			employee.setEmpName(resultSet.getString("emp_name"));
			employee.setEmpSalary(resultSet.getDouble("emp_salary"));
			employee.setEmpDesignation(resultSet.getString("emp_designation"));
		}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		manager.closeConnection();	
	    return employee;
	
	}
	public boolean persistEmployee(Employee employee) {
		Connection connection=manager.openConnection();
		PreparedStatement statement;
		int rows=0;
		try {
			statement = connection.prepareStatement("insert into emp values(?,?,?,?)");
			statement.setInt(1, employee.getEmpId());
			statement.setString(2, employee.getEmpName());
			statement.setDouble(3, employee.getEmpSalary());
			statement.setString(4,employee.getEmpDesignation());
			rows=statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	   if(rows>0)
		return true;
	   else
		return false;
	}
	public boolean updateEmployee(double empSalary, int empId) {
		Connection connection = manager.openConnection();
		int rows=0;
		try {
			PreparedStatement statement = connection.prepareStatement("update emp set emp_salary=? where emp_id=?");
			statement.setDouble(1, empSalary);
			statement.setInt(2, empId);
			rows = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(rows>0)
			return true;
			
		return false;
	}
	public boolean deleteEmployee(int empId) {
		Connection connection = manager.openConnection();
		int rows=0;
		try {
			PreparedStatement statement = connection.prepareStatement("delete from emp where emp_id=?");
			statement.setInt(1, empId);
			rows = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if(rows>0)
			return true;
			
		return false;
	}
}
