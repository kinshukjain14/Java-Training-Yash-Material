package com.yash.service;

import java.util.ArrayList;
import java.util.List;

import com.yash.dao.EmployeeDAO;
import com.yash.entities.Employee;
import com.yash.factory.EmployeeFactory;
import com.yash.model.EmployeeRequest;
import com.yash.model.EmployeeResponse;
import com.yash.model.EmployeeResponses;

public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeDAO employeeDAO=EmployeeFactory.createEmployeeDAO();
	public EmployeeResponses employeesRetrievalServicesXML() {

		List<Employee> employeeList=employeeDAO.getAllEmployees();
		List<EmployeeResponse> employeeResponseList=new ArrayList<EmployeeResponse>();
		for(Employee employee:employeeList) {
			EmployeeResponse employeeResponse=new EmployeeResponse();
			employeeResponse.setEmpId(employee.getEmpId());
			employeeResponse.setEmpName(employee.getEmpName());
			employeeResponse.setEmpSalary(employee.getEmpSalary());
			employeeResponse.setEmpDesignation(employee.getEmpDesignation());
			employeeResponseList.add(employeeResponse);
		}
		EmployeeResponses employeeResponses=new EmployeeResponses();
		employeeResponses.setEmployeeResponse(employeeResponseList);
		return employeeResponses;
	}

	public List<EmployeeResponse> employeesRetrievalServicesJSON() {
		List<Employee> employeeList=employeeDAO.getAllEmployees();
		List<EmployeeResponse> employeeResponseList=new ArrayList<EmployeeResponse>();
		for(Employee employee:employeeList) {
			EmployeeResponse employeeResponse=new EmployeeResponse();
			employeeResponse.setEmpId(employee.getEmpId());
			employeeResponse.setEmpName(employee.getEmpName());
			employeeResponse.setEmpSalary(employee.getEmpSalary());
			employeeResponse.setEmpDesignation(employee.getEmpDesignation());
			employeeResponseList.add(employeeResponse);
		}

		return employeeResponseList;
	}

	public EmployeeResponse getEmployee(int empId) {
			Employee employee=employeeDAO.getEmployee(empId);
			EmployeeResponse employeeResponse=new EmployeeResponse();
			employeeResponse.setEmpId(employee.getEmpId());
			employeeResponse.setEmpName(employee.getEmpName());
			employeeResponse.setEmpSalary(employee.getEmpSalary());
			employeeResponse.setEmpDesignation(employee.getEmpDesignation());
		return employeeResponse;
	}

	public boolean persistEmployee(EmployeeRequest employeeRequest) {
        Employee employee=new Employee();
        employee.setEmpId(employeeRequest.getEmpId());
        employee.setEmpName(employeeRequest.getEmpName());
        employee.setEmpSalary(employeeRequest.getEmpSalary());
        employee.setEmpDesignation(employeeRequest.getEmpDesignation());
        return employeeDAO.persistEmployee(employee);
	}

	public boolean updateEmployee(double empSalary, int empId) {
		return employeeDAO.updateEmployee(empSalary, empId);
	}

	public boolean deleteEmployee(int empId) {
		return employeeDAO.deleteEmployee(empId);
	}
}
