package com.yash.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.yash.factory.EmployeeFactory;
import com.yash.model.EmployeeRequest;
import com.yash.model.EmployeeResponse;
import com.yash.model.EmployeeResponses;
import com.yash.service.EmployeeService;

@Path("/employeeApp")
public class EmployeeController {
	
	private EmployeeService employeeService=EmployeeFactory.createEmployeeService();
	
	@GET
	@Path("/employeesxml")
	@Produces(MediaType.APPLICATION_XML)
	public EmployeeResponses getAllEmployeesXML(){
		EmployeeResponses employeeResponses=employeeService.employeesRetrievalServicesXML();
		return employeeResponses;
	}
	
	@GET
	@Path("/employees")
	@Produces(MediaType.APPLICATION_JSON)
	public List<EmployeeResponse> getAllEmployees(){
		List<EmployeeResponse> employeeResponseList=employeeService.employeesRetrievalServicesJSON();
		return employeeResponseList;
	}
	
	@GET
	@Path("/employees/{empId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response retrieveEmployeeEmployeeIdPath(@PathParam("empId")int empId){
		EmployeeResponse employeeResponse=employeeService.getEmployee(empId);
		if(employeeResponse.getEmpId()!=0) 
		{
		return Response.status(Response.Status.OK)
				.type(MediaType.APPLICATION_JSON)
				.entity(employeeResponse)
				.build();
		}else {
			return Response.status(Response.Status.NOT_FOUND)
			.type(MediaType.APPLICATION_JSON)
			.entity(new String("Employee Record not found"))
			.build();
		}
	}
	
	@GET
	@Path("/employeesreq")
	@Produces(MediaType.APPLICATION_JSON)
	public Response retrieveEmployeeEmployeeIdQuery(@QueryParam("empId")int empId){
		EmployeeResponse employeeResponse=employeeService.getEmployee(empId);
		if(employeeResponse.getEmpId()!=0) {
		return Response.status(Response.Status.OK)
				.type(MediaType.APPLICATION_JSON)
				.entity(employeeResponse)
				.build();
		}else {
			return Response.status(Response.Status.NOT_FOUND)
				.type(MediaType.APPLICATION_JSON)
				.entity(new String("Employee Record not found"))
				.build();
		}
	}
	@GET
	@Path("/employeesmatrix")
	@Produces(MediaType.APPLICATION_JSON)
	public Response retrieveEmployeeEmployeeIdMatrix(@MatrixParam("empId")int empId){
		EmployeeResponse employeeResponse=employeeService.getEmployee(empId);
		if(employeeResponse.getEmpId()!=0) {
		return Response.status(Response.Status.OK)
				.type(MediaType.APPLICATION_JSON)
				.entity(employeeResponse)
				.build();
		}else {
			return Response.status(Response.Status.NOT_FOUND)
			.type(MediaType.APPLICATION_JSON)
			.entity(new String("Employee Record not found"))
			.build();
		
		}
	}
	@POST
	@Path("/employeesform")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response registerEmployeeForm(@FormParam("empId")int empId,@FormParam("empName")String empName,@FormParam("empSalary")double empSalary,@FormParam("empDesignation")String empDesignation){
		EmployeeRequest employeeRequest=new EmployeeRequest();
		employeeRequest.setEmpId(empId);
		employeeRequest.setEmpName(empName);
		employeeRequest.setEmpSalary(empSalary);
		employeeRequest.setEmpDesignation(empDesignation);
		boolean result=employeeService.persistEmployee(employeeRequest);
		
		EmployeeResponse employeeResponse=new EmployeeResponse();
		employeeResponse.setEmpId(empId);
		employeeResponse.setEmpName(empName);
		employeeResponse.setEmpSalary(empSalary);
		employeeResponse.setEmpDesignation(empDesignation);
		
		if(result) {
		return Response.status(Response.Status.CREATED)
				.type(MediaType.APPLICATION_JSON)
				.entity(employeeResponse)
				.build();
		}else {
			return Response.status(Response.Status.CONFLICT)
			.type(MediaType.APPLICATION_JSON)
			.entity(new String("Employee Record not registered"))
			.build();
		
		}
	}
	
	@POST
	@Path("/employeesxml")
	@Consumes(MediaType.APPLICATION_XML)
	public Response registerEmployeeXML(EmployeeRequest employeeRequest){

		boolean result=employeeService.persistEmployee(employeeRequest);
		
		EmployeeResponse employeeResponse=new EmployeeResponse();
		employeeResponse.setEmpId(employeeRequest.getEmpId());
		employeeResponse.setEmpName(employeeRequest.getEmpName());
		employeeResponse.setEmpSalary(employeeRequest.getEmpSalary());
		employeeResponse.setEmpDesignation(employeeRequest.getEmpDesignation());
		
		if(result) {
		return Response.status(Response.Status.CREATED)
				.type(MediaType.APPLICATION_XML)
				.entity(employeeResponse)
				.build();
		}else {
			return Response.status(Response.Status.CONFLICT)
			.build();
		
		}
	}
	@POST
	@Path("/employeesjson")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response registerEmployeeJSON(EmployeeRequest employeeRequest){

		boolean result=employeeService.persistEmployee(employeeRequest);
		
		EmployeeResponse employeeResponse=new EmployeeResponse();
		employeeResponse.setEmpId(employeeRequest.getEmpId());
		employeeResponse.setEmpName(employeeRequest.getEmpName());
		employeeResponse.setEmpSalary(employeeRequest.getEmpSalary());
		employeeResponse.setEmpDesignation(employeeRequest.getEmpDesignation());
		
		if(result) {
		return Response.status(Response.Status.CREATED)
				.type(MediaType.APPLICATION_JSON)
				.entity(employeeResponse)
				.build();
		}else {
			return Response.status(Response.Status.CONFLICT)
			.type(MediaType.APPLICATION_JSON)
			.entity(new String("Employee Record not registered"))
			.build();
		
		}
	}
	
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/employees")
	public Response updateEmployeeSalary(@QueryParam("empId") int empId, @QueryParam("empSalary") double empSalary) {
		boolean result = employeeService.updateEmployee(empSalary, empId);
		EmployeeResponse employee = employeeService.getEmployee(empId);
		
		if(result) {
			return Response.status(Response.Status.ACCEPTED)
					.type(MediaType.APPLICATION_JSON)
					.entity(employee)
					.build();
		}
		else {
			return Response.status(Response.Status.NOT_MODIFIED)
					.type(MediaType.APPLICATION_JSON)
					.entity(new String("Resource not modified"))
					.build();
		}
	}
	
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/employees")
	public Response deleteEmployee(@MatrixParam("empId") int empId) {
		boolean result = employeeService.deleteEmployee(empId);

		if(result) {
			return Response.status(Response.Status.ACCEPTED)
					.type(MediaType.APPLICATION_JSON)
					.entity(new String("Resource removed"))
					.build();
		}
		else {
			return Response.status(Response.Status.NOT_FOUND)
					.type(MediaType.APPLICATION_JSON)
					.entity(new String("Resource removed failed"))
					.build();
		}
	}

}
