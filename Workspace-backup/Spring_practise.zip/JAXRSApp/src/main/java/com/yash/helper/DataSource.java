package com.yash.helper;

import java.util.ResourceBundle;

public class DataSource {
	private String driver;
	private String url;
	private String username;
	private String password;
	
	

	public DataSource(String baseName) {
		
		ResourceBundle resourceBundle=ResourceBundle.getBundle(baseName);
		this.driver = resourceBundle.getString("driver");
		this.url = resourceBundle.getString("url");
		this.username = resourceBundle.getString("username");
		this.password = resourceBundle.getString("password");
	}



	public String getDriver() {
		return driver;
	}



	public String getUrl() {
		return url;
	}



	public String getUsername() {
		return username;
	}



	public String getPassword() {
		return password;
	}



	@Override
	public String toString() {
		return "DataSource [driver=" + driver + ", url=" + url + ", username=" + username + ", password=" + password
				+ "]";
	}
	
	

}
