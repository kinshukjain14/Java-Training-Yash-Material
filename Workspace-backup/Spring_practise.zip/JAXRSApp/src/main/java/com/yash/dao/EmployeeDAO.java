package com.yash.dao;

import java.util.List;

import com.yash.entities.Employee;

public interface EmployeeDAO {

	public List<Employee> getAllEmployees();
	public Employee getEmployee(int empId);
	public boolean persistEmployee(Employee employee);
	public boolean updateEmployee(double empSalary,int empId);
	public boolean deleteEmployee(int empId);
}
