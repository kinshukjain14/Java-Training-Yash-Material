package com.yash.service;

import java.util.List;

import com.yash.model.EmployeeRequest;
import com.yash.model.EmployeeResponse;
import com.yash.model.EmployeeResponses;

public interface EmployeeService {
	
	public EmployeeResponses employeesRetrievalServicesXML();
	public List<EmployeeResponse> employeesRetrievalServicesJSON();
	public EmployeeResponse getEmployee(int empId);
	public boolean persistEmployee(EmployeeRequest employeeRequest);
	public boolean updateEmployee(double empSalary,int empId);
	public boolean deleteEmployee(int empId);
	}
