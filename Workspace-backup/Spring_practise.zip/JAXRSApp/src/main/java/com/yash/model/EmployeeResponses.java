package com.yash.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class EmployeeResponses {
	
	private List<EmployeeResponse> employeeResponse;

	public List<EmployeeResponse> getEmployeeResponse() {
		return employeeResponse;
	}

	public void setEmployeeResponse(List<EmployeeResponse> employeeResponse) {
		this.employeeResponse = employeeResponse;
	}



	

}
