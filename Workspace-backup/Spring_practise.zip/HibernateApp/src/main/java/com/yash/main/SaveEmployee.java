package com.yash.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.yash.entity.Employee;

public class SaveEmployee {

	public static void main(String[] args) {

		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session1=sessionFactory.openSession();
		
		Employee e1=new Employee();
		e1.setEmpId(1010);
		e1.setEmpName("Rakesh");
		e1.setEmpSalary(90000);
		e1.setEmpDesignation("Manager");
		Transaction transaction=session1.getTransaction();
		transaction.begin();
		session1.save(e1);
		transaction.commit();
		
		//e1=(Employee)session1.load(Employee.class, 1009);
		
		Session session2=sessionFactory.openSession();
		//session2.save(e1);
		
		
		Employee e1Session2=(Employee)session2.load(Employee.class, 1010);
		System.out.println("Object loaded from session2:"+e1Session2);

		
	}

}
