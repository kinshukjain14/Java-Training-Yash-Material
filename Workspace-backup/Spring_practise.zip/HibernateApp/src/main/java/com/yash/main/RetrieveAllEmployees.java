package com.yash.main;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import com.yash.entity.Employee;

public class RetrieveAllEmployees {

	public static void main(String[] args) {

		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		Query query=session.createQuery("from Employee o");
		List<Employee> employeeList=query.list();
		for(Employee employee:employeeList) {
			System.out.println(employee);
		}
		session.close();

	}

}
