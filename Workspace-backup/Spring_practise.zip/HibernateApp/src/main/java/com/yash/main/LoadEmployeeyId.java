package com.yash.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import com.yash.entity.Employee;

public class LoadEmployeeyId {

	public static void main(String[] args) {

		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		Employee employeeLoad=(Employee)session.load(Employee.class, 1001);
		System.out.println("Object's class returned from load:"+session.load(Employee.class, 1001).getClass());
		System.out.println("Load object:"+employeeLoad);
		
		Employee employeeGet=(Employee)session.get(Employee.class, 1002);
		System.out.println("Object's class returned from get:"+session.get(Employee.class, 1001).getClass());
		System.out.println("Get object:"+employeeGet);
		session.close();
		
	}

}
