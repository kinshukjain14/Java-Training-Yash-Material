package com.yash.main;

import com.yash.entity.Employee;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

public class EHCacheInternal {

	public static void main(String[] args) {

		CacheManager cacheManager=CacheManager.getInstance();
		
		cacheManager.addCache("employeeCache");
		
		Cache employeeCache=cacheManager.getCache("employeeCache");
		
		Employee e1=new Employee();
		e1.setEmpId(1001);
		e1.setEmpName("Sabbir");
		e1.setEmpSalary(34000);
		e1.setEmpDesignation("Trainer");
		employeeCache.put(new Element(1001,e1));
		Element element=employeeCache.get(1001);
		System.out.println(element.getObjectValue().toString());
	}

}
