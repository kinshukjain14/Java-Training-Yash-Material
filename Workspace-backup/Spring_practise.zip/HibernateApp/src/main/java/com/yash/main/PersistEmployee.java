package com.yash.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.yash.entity.Employee;


public class PersistEmployee {

	public static void main(String[] args) {

		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		Employee e1=new Employee();
		e1.setEmpId(1003);
		e1.setEmpName("Rohit");
		e1.setEmpSalary(13000);
		e1.setEmpDesignation("Sr.Software Engineer");
		
		Transaction transaction=session.getTransaction();
		transaction.begin();
		session.persist(e1);
		transaction.commit();
		
		session.close();
		
		
	}

}
