package com.yash.main;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.yash.entity.Employee;

public class DeleteEmployee {

	public static void main(String[] args) {
		try {
		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.getTransaction();
		transaction.begin();
		Query query=session.createQuery("delete from Employee o where o.empId=:id" );
		query.setParameter("id", 1001);
		int rows=query.executeUpdate();
		System.out.println("Rows deleted:"+rows);
		transaction.commit();
		session.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
