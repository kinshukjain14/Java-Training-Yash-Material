package com.yash.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.yash.entity.Employee;

public class UpdateEmployee {

	public static void main(String[] args) {

		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		Employee employee=(Employee)session.load(Employee.class, 1001);
		employee.setEmpSalary(75000);
		
		Transaction transaction=session.getTransaction();
		transaction.begin();
		Employee employeeUpdated=(Employee)session.merge(employee);
		transaction.commit();
		System.out.println(employeeUpdated);
		session.close();
		
	}

}
