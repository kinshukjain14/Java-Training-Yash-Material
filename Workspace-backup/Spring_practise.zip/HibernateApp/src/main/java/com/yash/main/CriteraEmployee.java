package com.yash.main;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.LogicalExpression;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.SimpleExpression;

import com.yash.entity.Employee;

public class CriteraEmployee {

	public static void main(String[] args) {
		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		Criteria criteria1=session.createCriteria(Employee.class);
		criteria1.add(Restrictions.eq("empSalary",15000D));
		List<Employee> employeeList1=criteria1.list();
		for(Employee e:employeeList1) {
			System.out.println(e);
		}
		System.out.println("***************************");
		
		Criteria criteria2=session.createCriteria(Employee.class);
		criteria2.add(Restrictions.lt("empSalary",50000D));
		List<Employee> employeeList2=criteria2.list();
		for(Employee e:employeeList2) {
			System.out.println(e);
		}
		System.out.println("***************************");
		Criteria criteria3=session.createCriteria(Employee.class);
		criteria3.add(Restrictions.like("empName","A%"));
		List<Employee> employeeList3=criteria3.list();
		for(Employee e:employeeList3) {
			System.out.println(e);
		}
		System.out.println("***************************");

		Criteria criteria4=session.createCriteria(Employee.class);
		
		SimpleExpression criteriaForSalary=Restrictions.lt("empSalary", 50000D);
		SimpleExpression criteriaForEmpName=Restrictions.like("empName", "A%");
		
		LogicalExpression expression1=Restrictions.or(criteriaForSalary, criteriaForEmpName);
		
		criteria4.add(expression1);
		List<Employee> employeeList4=criteria4.list();
		System.out.println("***************************");
		for(Employee e:employeeList4) {
			System.out.println(e);
		}
		
		LogicalExpression expression2=Restrictions.and(criteriaForSalary, criteriaForEmpName);
		criteria4.add(expression2);
		List<Employee> employeeList5=criteria4.list();
		System.out.println("***************************");
		for(Employee e:employeeList5) {
			System.out.println(e);
		}
		
		Criteria criteria5=session.createCriteria(Employee.class);
		criteria5.addOrder(Order.desc("empDesignation"));
		List<Employee> employeeList6=criteria5.list();
		System.out.println("***************************");
		for(Employee e:employeeList6) {
			System.out.println(e);
		}      
		
	}

}
