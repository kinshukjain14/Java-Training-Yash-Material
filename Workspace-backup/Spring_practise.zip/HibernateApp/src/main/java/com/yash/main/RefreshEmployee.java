package com.yash.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import com.yash.entity.Employee;

public class RefreshEmployee {

	public static void main(String[] args) {

		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		Employee employee=(Employee)session.load(Employee.class, 1001);
		while(true) {
		session.refresh(employee);
		System.out.println(employee);
		}

	}

}
