package com.yash.main;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cache.CacheKey;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.stat.Statistics;

import com.yash.entity.Employee;

import edu.emory.mathcs.backport.java.util.Arrays;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

public class SecondLevelCache {

	public static void main(String[] args) {

		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session1=sessionFactory.openSession();
		
		Employee e7=new Employee();
		e7.setEmpId(765432);
		e7.setEmpName("kumar");
		e7.setEmpSalary(98000);
		e7.setEmpDesignation("Accountant");
		Transaction transaction=session1.getTransaction();
		transaction.begin();
		session1.save(e7);
		transaction.commit();
		
		
		Statistics statistics=sessionFactory.getStatistics();
		String regions[]=statistics.getSecondLevelCacheRegionNames();
		
		System.out.println(Arrays.toString(regions));
		
		session1.close();
	
        
		CacheManager cacheManager=(CacheManager) CacheManager.ALL_CACHE_MANAGERS.get(0);
		System.out.println("Objects in cache:"+cacheManager.getCache("employee").getSize());
		
		List<CacheKey> keys=cacheManager.getCache("employee").getKeys();
		for(CacheKey key:keys) {
			System.out.println(cacheManager.getCache("employee").get(key));

		}
		Session session2=sessionFactory.openSession();
		Employee employeeSession2=(Employee)session2.load(Employee.class, 765432);
        System.out.println(employeeSession2);
		
        List<CacheKey> keys1=cacheManager.getCache("employee").getKeys();
		for(CacheKey key:keys1) {
			System.out.println(cacheManager.getCache("employee").get(key));

		}
	}

}
