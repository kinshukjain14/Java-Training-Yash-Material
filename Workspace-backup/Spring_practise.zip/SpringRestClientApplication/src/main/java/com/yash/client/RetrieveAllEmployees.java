package com.yash.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.yash.configuration.ClientConfiguration;
import com.yash.model.EmployeeResponse;

public class RetrieveAllEmployees {

	public static void main(String[] args) {

     HttpHeaders headers=new HttpHeaders();
     headers.setContentType(MediaType.APPLICATION_JSON);
     
     String uri="http://localhost:8082/employeeApp/api/employees";
     
     AnnotationConfigApplicationContext ioc=new AnnotationConfigApplicationContext(ClientConfiguration.class);
	 RestTemplate restTemplate=(RestTemplate)ioc.getBean("restTemplate");
	 
	 HttpEntity<String> requestEntity=new HttpEntity<String>(headers);
	 ResponseEntity<EmployeeResponse[]> response=
			 restTemplate.exchange(uri,HttpMethod.GET,requestEntity,EmployeeResponse[].class);
	 
	EmployeeResponse[] employeeResponses= response.getBody();
	 for(EmployeeResponse employeeResponse:employeeResponses) {
		 System.out.println(employeeResponse);
	 }
	}

}
