package com.yash.helper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component
public class EmployeeDBQuery {
	
	@Value("${selectEmployeeQuery}")
	private String selectEmployeeQuery;
	@Value("${insertEmployeeQuery}")
	private String insertEmployeeQuery;
	@Value("${updateEmployeeQuery}")
	private String updateEmployeeQuery;
	@Value("${deleteEmployeeQuery}")
	private String deleteEmployeeQuery;
	@Value("${selectEmployeeByIdQuery}")
	private String selectEmployeeByIdQuery;
	

	public EmployeeDBQuery() {}


	public String getSelectEmployeeQuery() {
		return selectEmployeeQuery;
	}


	public void setSelectEmployeeQuery(String selectEmployeeQuery) {
		this.selectEmployeeQuery = selectEmployeeQuery;
	}


	public String getInsertEmployeeQuery() {
		return insertEmployeeQuery;
	}


	public void setInsertEmployeeQuery(String insertEmployeeQuery) {
		this.insertEmployeeQuery = insertEmployeeQuery;
	}


	public String getUpdateEmployeeQuery() {
		return updateEmployeeQuery;
	}


	public void setUpdateEmployeeQuery(String updateEmployeeQuery) {
		this.updateEmployeeQuery = updateEmployeeQuery;
	}


	public String getDeleteEmployeeQuery() {
		return deleteEmployeeQuery;
	}


	public void setDeleteEmployeeQuery(String deleteEmployeeQuery) {
		this.deleteEmployeeQuery = deleteEmployeeQuery;
	}


	public String getSelectEmployeeByIdQuery() {
		return selectEmployeeByIdQuery;
	}


	public void setSelectEmployeeByIdQuery(String selectEmployeeByIdQuery) {
		this.selectEmployeeByIdQuery = selectEmployeeByIdQuery;
	}


	@Override
	public String toString() {
		return "EmployeeDBQuery [selectEmployeeQuery=" + selectEmployeeQuery + ", insertEmployeeQuery="
				+ insertEmployeeQuery + ", updateEmployeeQuery=" + updateEmployeeQuery + ", deleteEmployeeQuery="
				+ deleteEmployeeQuery + ", selectEmployeeByIdQuery=" + selectEmployeeByIdQuery + "]";
	}
	
	
}
