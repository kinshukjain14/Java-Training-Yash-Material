package com.yash.service;

import java.util.List;

import com.yash.model.EmployeeModel;

public interface EmployeeService {

	public List<EmployeeModel >getEmployeesModel();
	public EmployeeModel getEmployeeId(int empId);
	public String persistEmployee(EmployeeModel employeeModel);
	public String updateEmployeeSalary(int empId,double empSalary);
	public String deleteEmployee(int empId);
}
