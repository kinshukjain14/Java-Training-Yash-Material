package com.yash.main;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;

import com.yash.controller.EmployeeController;
import com.yash.helper.IOCContainer;

public class UpdateEmployeeModel {

	public static void main(String[] args) {
		ApplicationContext ioc=IOCContainer.createIOContainer();
		EmployeeController controller=(EmployeeController)ioc.getBean("employeeController");
		Scanner scanner=new Scanner(System.in);
		System.out.print("Employee Id:");
		int empId=0;
		if(scanner.hasNextInt()) {
			empId=scanner.nextInt();
		}
	
		System.out.print("Employee Salary:");
		double empSalary=0;
		if(scanner.hasNextDouble()) {
			empSalary=scanner.nextDouble();
		}
		
		String result=controller.handleUpdateEmployeeModel(empId, empSalary);
		System.out.println("Result:"+result);
		

	}

}
