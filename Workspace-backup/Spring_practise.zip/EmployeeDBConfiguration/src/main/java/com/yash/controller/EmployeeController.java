package com.yash.controller;

import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yash.model.EmployeeModel;
import com.yash.service.EmployeeService;

@Controller
@Lazy
@Scope("prototype")
@EnableAspectJAutoProxy
public class EmployeeController {
	@Autowired
	private EmployeeService employeeService;
	@Autowired
	ObjectMapper objectMapper;
	
	public String handleGetAllEmployeeModels(){
		
		String modelsList=null;
		try {
			modelsList=objectMapper.writeValueAsString(employeeService.getEmployeesModel());
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return modelsList;
	}
	
	public String handleGetEmployeeModelById(int empId) {
		String model=null;
		try {
			model=objectMapper.writeValueAsString(employeeService.getEmployeeId(empId));
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return model;
	}
	
	public String handlePersistEmployeeModel(String jsonData) {
		EmployeeModel employeeModel=null;
		try {
			employeeModel=objectMapper.readValue(jsonData, EmployeeModel.class);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return employeeService.persistEmployee(employeeModel);
	}
	
	public String handleUpdateEmployeeModel(int empId,double empSalary) {
		return employeeService.updateEmployeeSalary(empId, empSalary);
	}
	
	public String handleDeleteEmployeeModel(int empId) {
		return employeeService.deleteEmployee(empId);
	}

}
