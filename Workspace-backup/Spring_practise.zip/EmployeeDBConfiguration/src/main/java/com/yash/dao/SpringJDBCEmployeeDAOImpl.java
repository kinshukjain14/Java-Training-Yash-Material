package com.yash.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.yash.entity.Employee;
@Repository("springJDBCEmployeeDAOImpl")
public class SpringJDBCEmployeeDAOImpl implements EmployeeDAO {

	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	public Employee getEmployeeById(int empId) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean persistEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean updateEmployeeSalaryById(int empId, double empSalary) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		return false;
	}

}
