package com.yash.helper;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.yash.configuration.EmployeeDBConfiguration;

public class IOCContainer {
	
	public static ApplicationContext createIOContainer() {
		ApplicationContext ioc=new AnnotationConfigApplicationContext(EmployeeDBConfiguration.class);
		return ioc;
	}

}
