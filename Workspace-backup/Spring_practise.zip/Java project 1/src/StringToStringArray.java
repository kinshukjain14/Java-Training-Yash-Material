
public class StringToStringArray {
	public static void main(String[] args) 
	{
		String[] strArr = new String[100];
		String str = "Hello World Java Program";
		int wordCount = 0;
		String temp = "";
		for(int i=0,x=0;i<=str.length();i++) 
		{
			try {
				char c = str.charAt(i);
				if(c == ' ') 
				{
					strArr[x] = temp;
					temp="";
					x++;
					wordCount++;
				}
				else {
					temp=temp+c;
				}
			}
			catch(Exception e) {
				if(str.charAt(i-1) == ' ') {
					wordCount--;
				}
				else {
					temp = temp + str.charAt(i-1);
					strArr[x]=temp;					
				}
					
			}
		}
		
		for(int i=0;i<wordCount+1;i++) {
			System.out.println("Word "+i+" "+strArr[i]);
		}
		
	}
}
