
// Method 1

public class WordsCount {
	public static void main(String[] args) {
		String str = "Hello this is a java program";
		int wordCount=0;
		char[] charArray = str.toCharArray();
		for (char c : charArray) {
			if(c==' ') {
				wordCount++;
			}
		}
		
		// to count total words, Count total number of spaces present in the line
		// then add 1 to the total counts obtained to get the words count
		
		System.out.println("Total words : "+(wordCount+1));
	}
}


