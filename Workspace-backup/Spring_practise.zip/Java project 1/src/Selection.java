
public class Selection {
	void sort(int arrayInput[]) {
		int n = arrayInput.length;
		for (int i = 0; i < n - 1; i++) {
			int minimumElement = i;
			for (int j = i + 1; j < n; j++)
				if (arrayInput[j] < arrayInput[minimumElement])
					minimumElement = j;
			int temp = arrayInput[minimumElement];
			arrayInput[minimumElement] = arrayInput[i];
			arrayInput[i] = temp;
		}
	}

	void printarrayay(int arrayInput[]) {
		int n = arrayInput.length;
		for (int i = 0; i < n; ++i)
			System.out.print(arrayInput[i] + " ");
		System.out.println();
	}

	public static void main(String args[]) {
		Selection selectionSort = new Selection();
		int arrayInput[] = { 15, 10, 99, 53, 36 };
		selectionSort.sort(arrayInput);
		System.out.println("Sorted arrayay");
		selectionSort.printarrayay(arrayInput);
	}
}
