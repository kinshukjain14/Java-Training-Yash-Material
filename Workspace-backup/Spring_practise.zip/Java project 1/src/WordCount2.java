
public class WordCount2 {
	public static void main(String[] args) {
		String str = "Hello this is a java program";
		int wordCount = 0;
		char[] charArray = str.toCharArray();
		for (int i = 0; i < charArray.length; i++) {
			if (charArray[i] == ' ') {
				wordCount++;
			}
		}
		// to count total words, Count total number of spaces present in the line
		// then add 1 to the total counts obtained to get the words count

		System.out.println("Total words : " + (wordCount + 1));
	}
}
