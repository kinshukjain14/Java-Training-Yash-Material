
public class Quick {

	static void swapNumbers(int[] arrInput, int i, int j) {
		int temp = arrInput[i];
		arrInput[i] = arrInput[j];
		arrInput[j] = temp;
	}

	static int partition(int[] arrInput, int lower, int higher) {
		int pivot = arrInput[higher];
		int i = (lower - 1);

		for (int j = lower; j <= higher - 1; j++) {
			if (arrInput[j] < pivot) {
				i++;
				swapNumbers(arrInput, i, j);
			}
		}
		swapNumbers(arrInput, i + 1, higher);
		return (i + 1);
	}

	static void quickSort(int[] arr, int low, int high) {
		if (low < high) {

			int pi = partition(arr, low, high);

			quickSort(arr, low, pi - 1);
			quickSort(arr, pi + 1, high);
		}
	}

	static void printArray(int[] arr, int size) {
		for (int i = 0; i < size; i++)
			System.out.print(arr[i] + " ");

		System.out.println();
	}

	public static void main(String[] args) {
		int[] inputArray = { 10, 7, 8, 9, 1, 5 };
		int len = inputArray.length;

		quickSort(inputArray, 0, len - 1);
		System.out.println("Sorted array: ");
		printArray(inputArray, len);
	}
}
