import java.util.Arrays;

public class Merge {

	void mergeElement(int arrayInput[], int x, int y, int z) {

		int num1 = y - x + 1;
		int num2 = z - y;

		int large[] = new int[num1];
		int merged[] = new int[num2];

		for (int i = 0; i < num1; i++)
			large[i] = arrayInput[x + i];
		for (int j = 0; j < num2; j++)
			merged[j] = arrayInput[y + 1 + j];

		int p, q, r;
		p = 0;
		q = 0;
		r = x;

		while (p < num1 && q < num2) {
			if (large[p] <= merged[q]) {
				arrayInput[r] = large[p];
				p++;
			} else {
				arrayInput[r] = merged[q];
				q++;
			}
			r++;
		}

		while (p < num1) {
			arrayInput[r] = large[p];
			p++;
			r++;
		}

		while (q < num2) {
			arrayInput[r] = merged[q];
			q++;
			r++;
		}
	}

	void sort(int arrayInput[], int leftElement, int rightElement) {
		if (leftElement < rightElement) {
			int mid = (leftElement + rightElement) / 2;

			sort(arrayInput, leftElement, mid);
			sort(arrayInput, mid + 1, rightElement);

			mergeElement(arrayInput, leftElement, mid, rightElement);
		}
	}

	public static void main(String args[]) {

		int[] inputArray = { 6, 5, 12, 10, 9, 1 };

		Merge ob = new Merge();
		ob.sort(inputArray, 0, inputArray.length - 1);

		System.out.println("Sorted Array:");
		System.out.println(Arrays.toString(inputArray));
	}
}