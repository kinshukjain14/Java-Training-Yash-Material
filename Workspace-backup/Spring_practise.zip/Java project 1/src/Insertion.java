import java.util.Arrays;

public class Insertion {

	void sort(int arrayInput[]) {
		int arraySize = arrayInput.length;

		for (int i = 1; i < arraySize; i++) {
			int key = arrayInput[i];
			int j = i - 1;

			while (j >= 0 && key < arrayInput[j]) {
				arrayInput[j + 1] = arrayInput[j];
				--j;
			}

			arrayInput[j + 1] = key;
		}
	}

	public static void main(String args[]) {
		int[] dataInput = { 9, 5, 1, 4, 3 };
		Insertion insertionSort = new Insertion();
		insertionSort.sort(dataInput);
		System.out.println("Sorted Array in Ascending Order: ");
		System.out.println(Arrays.toString(dataInput));
	}
}