package com.yash.main;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Matchers.anyDouble;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yash.controller.EmployeeController;
import com.yash.model.EmployeeRequest;
import com.yash.model.EmployeeResponse;
import com.yash.service.EmployeeService;
import com.yash.validation.EmpIdCustomValidator;
import com.yash.validation.EmployeeCustomValidator;
@AutoConfigureMockMvc
@WebMvcTest
@ContextConfiguration(classes=SpringRestApplication.class)
class TestEmployeeController {
	
	private MockMvc mockMvc;
	@Mock
	private EmployeeService employeeService;
	@InjectMocks
	private EmployeeController employeeController;
	@InjectMocks
	@Spy
	private EmployeeCustomValidator employeeCustomValidator;
	@InjectMocks
	@Spy
	private EmpIdCustomValidator empIdCustomValidator;
	
	private RestTemplate template;
	@Mock
	private RestTemplate mockTemplate;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
		mockMvc=MockMvcBuilders.standaloneSetup(employeeController).build();
		template=new RestTemplate();
		
	}
	@Test
	void testhandleGetAllEmployeesJSON_positive() {
		try {
		List<EmployeeResponse> employeeResponseList=new ArrayList<EmployeeResponse>();
		
		EmployeeResponse employeeResponse=new EmployeeResponse();
		employeeResponse.setEmpId(1001);
		employeeResponse.setEmpName("Sabbir");
		employeeResponse.setEmpSalary(34000);
		employeeResponse.setEmpDesignation("Manager");
		
		employeeResponseList.add(employeeResponse);
		
		when(employeeService.employeesRetrievalServicesJSON()).thenReturn(employeeResponseList);
		
		ResponseEntity<List<EmployeeResponse>> responseEntity=employeeController.handleGetAllEmployeesJSON();
		List<EmployeeResponse> responseBody=responseEntity.getBody();
		assertTrue(responseBody.size()>0);
		}catch(Exception e) {
			assertTrue(false);
		}
	
		
		
}
	@Test
	void retrieveEmployeeById_positive() {
		
		when(employeeService.getEmployee(anyInt())).thenAnswer(
				new Answer<EmployeeResponse>() {
					
					public EmployeeResponse answer(InvocationOnMock invocation) throws Exception {
						EmployeeResponse employeeResponse=new EmployeeResponse();
						employeeResponse.setEmpId(1001);
						employeeResponse.setEmpName("Sabbir");
						employeeResponse.setEmpSalary(34000);
						employeeResponse.setEmpDesignation("Manager");
						return employeeResponse;
					}});
		
		ResponseEntity<EmployeeResponse> responseEntity=employeeController.retrieveEmployeeByIdRequest(1001);
		EmployeeResponse employeeResponse=responseEntity.getBody();
		assertEquals(1001,employeeResponse.getEmpId());
	}
	
	@Test
	void retrieveEmployeeByIdRequestURIPositive() 
 {
		EmployeeResponse employeeResponse=new EmployeeResponse();
		employeeResponse.setEmpId(1002);
		employeeResponse.setEmpName("Sabbir");
		employeeResponse.setEmpSalary(34000);
		employeeResponse.setEmpDesignation("Manager");
		
		when(employeeService.getEmployee(anyInt())).thenReturn(employeeResponse);
		
		try {
			MvcResult result=
					mockMvc.perform(get("http://localhost:8082/api/employeesreq?empId=1002"))
			.andExpect(status().isFound()).andReturn();
		} catch (Exception e) {

       assertTrue(false);
		}
	}
	
	void retrieveEmployeeByIdRequestURINegative() 
	 {
			EmployeeResponse employeeResponse=new EmployeeResponse();
			employeeResponse.setEmpId(1001);
			employeeResponse.setEmpName("Sabbir");
			employeeResponse.setEmpSalary(34000);
			employeeResponse.setEmpDesignation("Manager");
			
			when(employeeService.getEmployee(anyInt())).thenReturn(employeeResponse);
			
			try {
				MvcResult result=
						mockMvc.perform(get("http://localhost:8082/api/employeesreq?empId=1002"))
				.andExpect(status().isNotFound()).andReturn();
			} catch (Exception e) {
				assertTrue(false);
			}
		}

	@Test
	void retrieveEmployeeByIdPathURIPositive() 
 {
		EmployeeResponse employeeResponse=new EmployeeResponse();
		employeeResponse.setEmpId(1002);
		employeeResponse.setEmpName("Sabbir");
		employeeResponse.setEmpSalary(34000);
		employeeResponse.setEmpDesignation("Manager");
		  when(employeeService.checkEmpId(anyInt())).thenReturn(true);
		Errors errorsMock=Mockito.mock(Errors.class);
		  when(errorsMock.hasErrors()).thenReturn(false);
		when(employeeService.getEmployee(anyInt())).thenReturn(employeeResponse);
		
		try {
					MvcResult mvcResult = mockMvc.perform(get("http://localhost:8082/api/employees/{empId}",1002))
			.andExpect(status().isFound()).andReturn();
		} catch (Exception e) {

       assertTrue(false);
		}
	}
	
	
  @Test
  void persistEmployeePositive() {
	  EmployeeRequest employeeRequest=new EmployeeRequest();
	 
	  employeeRequest.setEmpId(1001);
	  employeeRequest.setEmpName("Sabbir");
	  employeeRequest.setEmpSalary(34000);
	  employeeRequest.setEmpDesignation("Manager");
	  when(employeeService.checkEmpId(anyInt())).thenReturn(true);

	  Errors errorsMock=Mockito.mock(Errors.class);
	  when(errorsMock.hasErrors()).thenReturn(false);
	  when(employeeService.persistEmployee(employeeRequest)).thenReturn(true);
	  ResponseEntity<EmployeeResponse> responseEntity=employeeController.persistEmployee(employeeRequest, errorsMock);
	  EmployeeResponse employeeResponse=responseEntity.getBody();
	  assertEquals(employeeResponse.getEmpId(),employeeRequest.getEmpId());
  }
  @Test
  void updateEmployeeSalary() {
	  when(employeeService.updateEmployee(anyInt(), anyDouble())).thenReturn(true);
	  try {
		MvcResult result=mockMvc.perform(patch("http://localhost:8082/api/employees/{empId}/{empSalary}",1001,32000))
		  .andExpect(status().isAccepted()).andReturn();
	} catch (Exception e) {
		assertTrue(false);
	}
  }
  
  @Test
  void retrieveEmployeeById_restTemplate() {
	  EmployeeResponse employeeResponse=new EmployeeResponse();
		employeeResponse.setEmpId(1002);
		employeeResponse.setEmpName("Sabbir");
		employeeResponse.setEmpSalary(34000);
		employeeResponse.setEmpDesignation("Manager");
		
		when(mockTemplate
				.getForEntity("http://localhost:8082/api/employees/1002",EmployeeResponse.class))
		.thenReturn(new ResponseEntity<EmployeeResponse>(employeeResponse,HttpStatus.OK));
		
		ResponseEntity<EmployeeResponse> responseEntity=
				mockTemplate.getForEntity("http://localhost:8082/api/employees/1002", EmployeeResponse.class);
		  when(employeeService.checkEmpId(anyInt())).thenReturn(true);
			Errors errorsMock=Mockito.mock(Errors.class);
			  when(errorsMock.hasErrors()).thenReturn(false);
		EmployeeResponse response=responseEntity.getBody();
		assertEquals(employeeResponse.getEmpId(),response.getEmpId());
		
  
  }
  @Test
  public void retrieveEmployeeByIdActualCallRestTemplate() {
	  ResponseEntity<EmployeeResponse> responseEntity=
			  template.getForEntity("http://localhost:8082/api/employees/1002", 
					  EmployeeResponse.class);
	  EmployeeResponse employeeResponse=responseEntity.getBody();
	  assertEquals(1002,employeeResponse.getEmpId());
  }
  @Test
  public void testJSONData() throws ClientProtocolException, IOException {
	  HttpUriRequest request=new HttpGet("http://localhost:8082/api/employees/1002");
	  
	  HttpResponse response=HttpClientBuilder.create().build().execute(request);
	  ObjectMapper mapper=new ObjectMapper()
			  .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, true);
	  
	  String stringOfResponse=EntityUtils.toString(response.getEntity());
	  EmployeeResponse employeeResponse=mapper.readValue(stringOfResponse, EmployeeResponse.class);
	  assertEquals(1002,employeeResponse.getEmpId());
	  assertEquals("amit",employeeResponse.getEmpName());
	  
  }
  @Test
  public void testJSONMockData() throws Exception {
		EmployeeResponse employeeResponse=new EmployeeResponse();
		employeeResponse.setEmpId(1002);
		employeeResponse.setEmpName("Sabbir");
		employeeResponse.setEmpSalary(34000);
		employeeResponse.setEmpDesignation("Manager");
		  when(employeeService.checkEmpId(anyInt())).thenReturn(true);
		Errors errorsMock=Mockito.mock(Errors.class);
		  when(errorsMock.hasErrors()).thenReturn(false);
		when(employeeService.getEmployee(anyInt())).thenReturn(employeeResponse);
		
		mockMvc.perform(get("http://localhost:8082/api/employeesjson/{empId}",1002))
		.andExpect(status().isOk())
		.andExpect(jsonPath("$.empId").value(1002))
		.andExpect(jsonPath("$.empName").value("Sabbir"))
		.andExpect(jsonPath("$.empSalary").value(34000))
		.andExpect(jsonPath("$.empDesignation").value("Manager")).andReturn();

  }
}
