package com.yash.validation;

import java.lang.annotation.Target;

import javax.validation.Constraint;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import javax.validation.Payload;
@Constraint(validatedBy=EmpIdConstraintValidator.class)
@Target({ElementType.METHOD,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface EmpIdConstraint {

	String message() default "Employee Id already exists";
	Class<?>[] groups() default{};
	Class<? extends Payload>[] payload() default{};
	
}
