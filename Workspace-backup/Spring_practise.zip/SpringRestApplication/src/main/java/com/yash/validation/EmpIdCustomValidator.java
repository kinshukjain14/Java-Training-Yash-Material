package com.yash.validation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.yash.model.EmployeeRequest;
import com.yash.service.EmployeeService;
@Component("empIdCustomValidator")
public class EmpIdCustomValidator implements Validator {
	@Autowired
	private EmployeeService employeeService;

	@Override
	public boolean supports(Class<?> clazz) {
		return EmployeeRequest.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
     EmployeeRequest employeeRequest=(EmployeeRequest)target;
     int empId=employeeRequest.getEmpId();
     boolean result=employeeService.checkEmpId(empId);
     if(!result) {
    	 errors.rejectValue("empId", "No error code","Employee Id does not exists");
     }
     	}
}
