package com.yash.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import com.yash.validation.EmpIdConstraint;

@XmlRootElement
public class EmployeeRequest {
	@EmpIdConstraint
	private int empId;
	@NotBlank(message="{com.yash.model.EmployeeRequest.empName.blank}")
	private String empName;
	private double empSalary;
	@Size(min=3,max=15,message= "{com.yash.model.EmployeeRequest.empDesignation.size}")
	private String empDesignation;
	
	public EmployeeRequest() {}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	public String getEmpDesignation() {
		return empDesignation;
	}

	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empDesignation="
				+ empDesignation + "]";
	}
}
