package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.yash.entity.Employee;
import com.yash.helper.EmployeeDBQuery;
import com.yash.integrate.ConnectionManager;
@Repository("jDBCEmployeeDAOImpl")
public class JDBCEmployeeDAOImpl implements EmployeeDAO {
	@Autowired
	private ConnectionManager connectionManager;
	@Autowired
	private EmployeeDBQuery employeeDBQuery;

	public List<Employee> getAllEmployees() {
		System.out.println("*********getAllEmployees************");
		Connection connection=connectionManager.openConnection();
		List<Employee> empList=new ArrayList<Employee>();
		try {
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery(employeeDBQuery.getSelectEmployeeQuery());
			while(resultSet.next()) {
				Employee e=new Employee();
				e.setEmpId(resultSet.getInt(1));
				e.setEmpName(resultSet.getString(2));
				e.setEmpSalary(resultSet.getDouble(3));
				e.setEmpDesignation(resultSet.getString(4));
				empList.add(e);
			}
			connectionManager.closeConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empList;
	}

	public Employee getEmployeeById(int empId) {
		Connection connection=connectionManager.openConnection();
		Employee e=new Employee();
		try {
			PreparedStatement statement=connection.prepareStatement(employeeDBQuery.getSelectEmployeeByIdQuery());
			statement.setInt(1, empId);
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next()) {
				e.setEmpId(resultSet.getInt(1));
				e.setEmpName(resultSet.getString(2));
				e.setEmpSalary(resultSet.getDouble(3));
				e.setEmpDesignation(resultSet.getString(4));
			}
			connectionManager.closeConnection();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return e;
	}

	public boolean persistEmployee(Employee employee) {
		Connection connection=connectionManager.openConnection();
		int rows=0;
		try {
			PreparedStatement statement=connection.prepareStatement(employeeDBQuery.getInsertEmployeeQuery());
			statement.setInt(1, employee.getEmpId());
			statement.setString(2, employee.getEmpName());
			statement.setDouble(3, employee.getEmpSalary());
			statement.setString(4, employee.getEmpDesignation());
			rows=statement.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		connectionManager.closeConnection();
		if(rows>0)
		return true;
		else
		return false;
	}

	public boolean updateEmployeeSalaryById(int empId, double empSalary) {
		Connection connection=connectionManager.openConnection();
		int rows=0;
		try {
			PreparedStatement statement=connection.prepareStatement(employeeDBQuery.getUpdateEmployeeQuery());
			statement.setDouble(1, empSalary);
			statement.setInt(2, empId);
			
			rows=statement.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		connectionManager.closeConnection();
		if(rows>0)
		return true;
		else
		return false;	}

	public boolean deleteEmployee(int empId) {
		Connection connection=connectionManager.openConnection();
		int rows=0;
		try {
			PreparedStatement statement=connection.prepareStatement(employeeDBQuery.getDeleteEmployeeQuery());
			statement.setInt(1, empId);
			
			rows=statement.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		connectionManager.closeConnection();
		if(rows>0)
		return true;
		else
		return false;
	}

	public List<String> getEmployeeDesignations() {
		Connection connection=connectionManager.openConnection();
		List<String> designationList=new ArrayList<String>();
        try {
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery(employeeDBQuery.getSelectEmployeeDesignationQuery());
			while(resultSet.next()) {
				designationList.add(resultSet.getString(1));
			}
			  connectionManager.closeConnection();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return designationList;
	}

	public boolean checkEmpId(int empId) {
		Connection connection=connectionManager.openConnection();
		boolean result=false;
        try {
			PreparedStatement statement=connection.prepareStatement(employeeDBQuery.getCheckEmpIdQuery());
		    statement.setInt(1, empId);
		    ResultSet resultSet=statement.executeQuery();
		    while(resultSet.next()) {
		    	result=true;
		    }
			  connectionManager.closeConnection();

        } catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		Connection connection=connectionManager.openConnection();
		int rows=0;
        try {
			PreparedStatement statement=connection.prepareStatement(employeeDBQuery.getUpdateEmployeeEntityQuery());
		    statement.setString(1, employee.getEmpName());
		    statement.setDouble(2, employee.getEmpSalary());
		    statement.setString(3, employee.getEmpDesignation());
		    statement.setInt(4, employee.getEmpId());
		     rows=statement.executeUpdate();
		  connectionManager.closeConnection();
        } catch (SQLException e) {
			e.printStackTrace();
		}
        if(rows>0)
        	return true;
        else
        	return false;
		
	}

}
