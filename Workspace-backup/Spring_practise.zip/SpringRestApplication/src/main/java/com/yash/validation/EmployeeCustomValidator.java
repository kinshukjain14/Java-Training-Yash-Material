package com.yash.validation;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.yash.model.EmployeeRequest;
import com.yash.service.EmployeeService;

@Component("employeeCustomValidator")
public class EmployeeCustomValidator implements Validator{
	
	@Autowired
	private EmployeeService employeeService;

	@Override
	public boolean supports(Class<?> clazz) {
		return EmployeeRequest.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
     EmployeeRequest employeeRequest=(EmployeeRequest)target;
     int empId=employeeRequest.getEmpId();
     boolean result=employeeService.checkEmpId(empId);
     if(result) {
    	 errors.rejectValue("empId", "No error code","Employee Id already exists");
     }
     String empName=employeeRequest.getEmpName();
     if(empName.length()==0 || empName.length()>20) {
    	 errors.rejectValue("empName", "No error code","Employee Name not valid");

     }
     double empSalary=employeeRequest.getEmpSalary();
     if(empSalary<25000) {
    	 errors.rejectValue("empSalary", "No error code","Employee Salary not valid");

     }
		List<String> designationList=employeeService.getDesignations();
		String empDesignation=employeeRequest.getEmpDesignation();
		if(!designationList.contains(empDesignation)) {
	    	 errors.rejectValue("empDesignation", "No error code","Employee Designation not valid");

		}
	}

}
