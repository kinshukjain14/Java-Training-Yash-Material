package com.yash.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

import com.yash.configuration.DBConfiguration;
import com.yash.configuration.InMemorySecurityConfig;
import com.yash.configuration.JDBCSpringSecurityConfig;
import com.yash.configuration.ValidationConfiguration;

@SpringBootApplication(scanBasePackages = "com.yash.*")
@ImportResource("classpath:applicationContext.xml")
@Import({ValidationConfiguration.class,JDBCSpringSecurityConfig.class})
@PropertySource("classpath:db.properties")

public class SpringRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestApplication.class, args);
	}
	

}
