package com.yash.service;

import java.util.List;

import com.yash.model.EmployeeRequest;
import com.yash.model.EmployeeResponse;
import com.yash.model.EmployeeResponses;

public interface EmployeeService {
	
	public EmployeeResponses employeesRetrievalServicesXML();
	public List<EmployeeResponse> employeesRetrievalServicesJSON();
	public EmployeeResponse getEmployee(int empId);
	public boolean UpdateEntityEmployee(EmployeeRequest employeeRequest);
	public boolean persistEmployee(EmployeeRequest employeeRequest);
	public boolean updateEmployee(int empId,double empSalary);
	public boolean deleteEmployee(int empId);
	public boolean checkEmpId(int empId);
	public List<String> getDesignations();

}
