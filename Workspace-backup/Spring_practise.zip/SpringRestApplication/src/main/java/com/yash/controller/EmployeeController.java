package com.yash.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.bind.validation.ValidationErrors;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.MatrixVariable;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.yash.model.EmployeeError;
import com.yash.model.EmployeeRequest;
import com.yash.model.EmployeeResponse;
import com.yash.service.EmployeeService;
import com.yash.validation.EmpIdCustomValidator;
import com.yash.validation.EmployeeCustomValidator;

@RestController
@RequestMapping("api")
@CrossOrigin(origins = "*",allowCredentials = "true",allowedHeaders = "*",methods=RequestMethod.POST)
@EnableAspectJAutoProxy
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;
	
	@Autowired@Qualifier("employeeCustomValidator")
	private EmployeeCustomValidator employeevalidator;
	
	
	@Autowired@Qualifier("empIdCustomValidator")
	private EmpIdCustomValidator empIdvalidator;
	//@RequestMapping(value="employees",method = RequestMethod.GET)
	@GetMapping("employees")
	//@PreAuthorize(value = "hasAuthority('READ_PRIVILEGES')")
	@PreAuthorize(value = "hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
	public ResponseEntity<List<EmployeeResponse>> handleGetAllEmployeesJSON(){
		List<EmployeeResponse> employeeResponseList=employeeService.employeesRetrievalServicesJSON();
		ResponseEntity<List<EmployeeResponse>> response=null;
		if(!employeeResponseList.isEmpty()) {
		 response=new ResponseEntity<List<EmployeeResponse>>(employeeResponseList,HttpStatus.OK);
		}else {
			response=new ResponseEntity<List<EmployeeResponse>>(employeeResponseList,HttpStatus.EXPECTATION_FAILED);
		}
		return response;
	}
	
	@RequestMapping(value = "employeesjson/{empId}",
	        method = RequestMethod.GET,
	        produces = "application/json")
	public EmployeeResponse retrieveEmployeeByIdJSON(@PathVariable("empId")int empId) {
		EmployeeResponse employeeResponse=employeeService.getEmployee(empId);
		return employeeResponse;


	}
	@GetMapping("employees/{empId}")
	@PreAuthorize(value = "hasRole('ROLE_USER') or hasRole('ROLE_ADMIN')")
	public ResponseEntity<EmployeeResponse> retrieveEmployeeById(@PathVariable("empId")int empId){
		ResponseEntity<EmployeeResponse> response=null;
		EmployeeRequest employeeRequest=new EmployeeRequest();
		Errors errors=new BeanPropertyBindingResult(employeeRequest,"employeeRequest");
		employeeRequest.setEmpId(empId);
		ValidationUtils.invokeValidator(empIdvalidator, employeeRequest, errors);
	        if(errors.hasErrors()) {
	        	EmployeeError employeeError=new EmployeeError();
	        	employeeError.setErrorCode(999);
	        	List<ObjectError> listOfErrors=errors.getAllErrors();
	        	for(ObjectError objectError:listOfErrors) {
		        	employeeError.setErrorMessage(objectError.getDefaultMessage());

	        	}
	        	EmployeeResponse employeeResponse=new EmployeeResponse();
	        	employeeResponse.setEmployeeError(employeeError);
				response=new ResponseEntity<EmployeeResponse>(employeeResponse,HttpStatus.BAD_REQUEST);
	        }else {
		EmployeeResponse employeeResponse=employeeService.getEmployee(empId);
		if(employeeResponse.getEmpId()!=0) {
			response=new ResponseEntity<EmployeeResponse>(employeeResponse,HttpStatus.FOUND);
		}else {
			response=new ResponseEntity<EmployeeResponse>(employeeResponse,HttpStatus.NOT_FOUND);

		}
	        }
		return response;
	}
	@GetMapping("employeesreq")
	public ResponseEntity<EmployeeResponse> retrieveEmployeeByIdRequest(@RequestParam("empId")int empId){
		EmployeeResponse employeeResponse=employeeService.getEmployee(empId);
		ResponseEntity<EmployeeResponse> response=null;
		if(employeeResponse.getEmpId()==empId) {
			response=new ResponseEntity<EmployeeResponse>(employeeResponse,HttpStatus.FOUND);
		}else {
			response=new ResponseEntity<EmployeeResponse>(employeeResponse,HttpStatus.NOT_FOUND);

		}
		return response;
	}
	@GetMapping("employeesmatrix/{employee}")
	public ResponseEntity<EmployeeResponse> retrieveEmployeeByIdMatrix(@MatrixVariable int empId){
		EmployeeResponse employeeResponse=employeeService.getEmployee(empId);
		ResponseEntity<EmployeeResponse> response=null;
		if(employeeResponse.getEmpId()!=0) {
			response=new ResponseEntity<EmployeeResponse>(employeeResponse,HttpStatus.FOUND);
		}else {
			response=new ResponseEntity<EmployeeResponse>(employeeResponse,HttpStatus.NOT_FOUND);

		}
		return response;
	}
	@PostMapping("employees")
	//@PreAuthorize(value = "hasAuthority('WRITE_PRIVILEGES')")
	//@PreAuthorize(value = "hasRole('ROLE_ADMIN')")
	public ResponseEntity<EmployeeResponse> persistEmployee(@RequestBody EmployeeRequest employeeRequest,Errors errors){
		ResponseEntity<EmployeeResponse> response=null;

	        ValidationUtils.invokeValidator(employeevalidator, employeeRequest, errors);	
	        if(errors.hasErrors()) {
	        	EmployeeError employeeError=new EmployeeError();
	        	employeeError.setErrorCode(999);
	        	List<ObjectError> listOfErrors=errors.getAllErrors();
	        	for(ObjectError objectError:listOfErrors) {
		        	employeeError.setErrorMessage(objectError.getDefaultMessage());

	        	}
	        	EmployeeResponse employeeResponse=new EmployeeResponse();
	        	employeeResponse.setEmpId(0);
	        	employeeResponse.setEmployeeError(employeeError);
				response=new ResponseEntity<EmployeeResponse>(employeeResponse,HttpStatus.CONFLICT);

	        }
	        else {
		boolean result=employeeService.persistEmployee(employeeRequest);
		if(result) {
			EmployeeResponse employeeResponse=new EmployeeResponse();
			employeeResponse.setEmpId(employeeRequest.getEmpId());
			employeeResponse.setEmpName(employeeRequest.getEmpName());
			employeeResponse.setEmpSalary(employeeRequest.getEmpSalary());
			employeeResponse.setEmpDesignation(employeeRequest.getEmpDesignation());
			response=new ResponseEntity<EmployeeResponse>(employeeResponse,HttpStatus.CREATED);
		}else {
			EmployeeResponse employeeResponse=new EmployeeResponse();
        	employeeResponse.setEmpId(0);
			response=new ResponseEntity<EmployeeResponse>(employeeResponse,HttpStatus.CONFLICT);

		}
	        }
		return response;
		
	}
	
	@PostMapping("employeesannotation")
	public ResponseEntity<EmployeeResponse> persistEmployeeAnnotation(@Valid @RequestBody EmployeeRequest employeeRequest){
		ResponseEntity<EmployeeResponse> response=null;

	        
		boolean result=employeeService.persistEmployee(employeeRequest);
		if(result) {
			EmployeeResponse employeeResponse=new EmployeeResponse();
			employeeResponse.setEmpId(employeeRequest.getEmpId());
			employeeResponse.setEmpName(employeeRequest.getEmpName());
			employeeResponse.setEmpSalary(employeeRequest.getEmpSalary());
			employeeResponse.setEmpDesignation(employeeRequest.getEmpDesignation());
			response=new ResponseEntity<EmployeeResponse>(employeeResponse,HttpStatus.CREATED);
		}else {
			response=new ResponseEntity<EmployeeResponse>(HttpStatus.CONFLICT);

		}
	        
		return response;
		
	}

	@PutMapping("employees")
	public ResponseEntity<String> updateEmployee(@RequestBody EmployeeRequest employeeRequest){
		
		boolean result=employeeService.UpdateEntityEmployee(employeeRequest);
		ResponseEntity<String> response=null;
		if(result) {
			response=new ResponseEntity<String>("Employee Successfully updated",HttpStatus.ACCEPTED);
		}else {
			response=new ResponseEntity<String>("Employee updation failed",HttpStatus.NOT_MODIFIED);

		}
		return response;
	}
	
	@PatchMapping("employees/{empId}/{empSalary}")
	public ResponseEntity<Void> updateEmployeeSalary(@PathVariable("empId")int empId,@PathVariable("empSalary")double empSalary){
		boolean result=employeeService.updateEmployee(empId, empSalary);
		ResponseEntity<Void> response=null;
		if(result) {
			response=new ResponseEntity<Void>(HttpStatus.ACCEPTED);
		}else {
			response=new ResponseEntity<Void>(HttpStatus.NOT_MODIFIED);
		}
		return response;
	}
	@DeleteMapping("employees/{empId}")
	public ResponseEntity<Void> deleteEmployee(@PathVariable("empId")int empId){
		boolean result=employeeService.deleteEmployee(empId);
		ResponseEntity<Void> response=null;
		if(result) {
			response=new ResponseEntity<Void>(HttpStatus.OK);
		}else {
			response=new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
		return response;
	}
}
