package com.yash.dao;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;


public interface UserDAO {
	
	public UserDetails getUserDetails(String userName);

}
