package com.yash.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.yash.entity.Employee;
import com.yash.entity.Project;

public class PersistEmployee {

	public static void main(String[] args) {

		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		Project project=new Project();
		project.setProjectId(1);
		project.setProjectName("SalesApp");
		project.setClientName("John Deere");
		
		Employee e1=new Employee();
		e1.setEmpId(1001);
		e1.setEmpName("Sabbir");
		e1.setEmpSalary(34000);
		e1.setEmpDesignation("Programmer");
		
		e1.setProject(project);
		
		Transaction transaction=session.getTransaction();
		transaction.begin();
		session.persist(e1);
		transaction.commit();
		
		session.close();
	}

}
