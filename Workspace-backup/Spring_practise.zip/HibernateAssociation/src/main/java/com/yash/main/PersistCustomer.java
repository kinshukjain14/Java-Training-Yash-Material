package com.yash.main;

import java.util.ArrayList;
import java.util.List;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.yash.entity.Customer;
import com.yash.entity.Item;
import com.yash.entity.Order;

public class PersistCustomer {

	public static void main(String[] args) {
		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		List<Item> itemsList1=new ArrayList<Item>();
		
		Item item11=new Item();
		item11.setItemCode("I11");
		item11.setItemDescription("Non electronic item");
		item11.setItemPrice(200);
		item11.setItemQuantity(3);
		
		
		Item item12=new Item();
		item12.setItemCode("I12");
		item12.setItemDescription("electronic item");
		item12.setItemPrice(2000);
		item12.setItemQuantity(1);
		
		itemsList1.add(item11);
		itemsList1.add(item12);
		
        List<Item> itemsList2=new ArrayList<Item>();
		
		Item item21=new Item();
		item21.setItemCode("I21");
		item21.setItemDescription("Food items");
		item21.setItemPrice(500);
		item21.setItemQuantity(1);
		
		
		Item item22=new Item();
		item22.setItemCode("I22");
		item22.setItemDescription("Household item");
		item22.setItemPrice(3000);
		item22.setItemQuantity(6);
		
		itemsList2.add(item21);
		itemsList2.add(item22);
		
		Order order1=new Order();
		order1.setOrderCode("ODR01");
		order1.setOrderDescription("ORDER 01");
		order1.setItems(itemsList1);
		
		Order order2=new Order();
		order2.setOrderCode("ODR02");
		order2.setOrderDescription("ORDER 02");
		order2.setItems(itemsList2);
		
		List<Order> orderList=new ArrayList<Order>();
		orderList.add(order1);
		orderList.add(order2);
		
		Customer customer=new Customer();
		customer.setCustomerId(1001);
		customer.setCustomerName("Sabbir");
		customer.setCustomerAddress("ABC XYZ");
		customer.setCustomePhoneNumber("122222");
		
		customer.setOrders(orderList);
		
		Transaction transaction=session.getTransaction();
		transaction.begin();
		session.persist(customer);
		transaction.commit();
		session.close();
		
	}

}
