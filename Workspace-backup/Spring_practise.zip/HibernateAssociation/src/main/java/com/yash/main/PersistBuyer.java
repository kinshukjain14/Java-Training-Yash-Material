package com.yash.main;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.yash.entity.Buyer;
import com.yash.entity.Product;

public class PersistBuyer {

	public static void main(String[] args) {
		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		
		List<Buyer> buyerList=new ArrayList<Buyer>();
		
		Buyer buyer1=new Buyer();
		buyer1.setBuyerId(1);
		buyer1.setBuyerName("Buyer1");
		
		Buyer buyer2=new Buyer();
		buyer2.setBuyerId(2);
		buyer2.setBuyerName("Buyer2");
		
		buyerList.add(buyer1);
		buyerList.add(buyer2);
		
		Product product1=new Product();
		product1.setProductCode(1001);
		product1.setProductName("Product 1");
		
		Product product2=new Product();
		product2.setProductCode(1002);
		product2.setProductName("Product 2");
		
		product1.setBuyers(buyerList);
		product2.setBuyers(buyerList);
		
		
		List<Product> productList=new ArrayList<Product>();
		productList.add(product1);
		productList.add(product2);
		
		buyer1.setProducts(productList);
		buyer2.setProducts(productList);
		
		Transaction transaction=session.getTransaction();
		transaction.begin();
		session.persist(buyer1);
		session.persist(buyer2);
		transaction.commit();
		session.close();
		
		

	}

}
