package com.yash.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import com.yash.entity.Customer;
import com.yash.entity.Employee;

public class RetrieveCustomer {
	
	public static void main(String args[]) {
		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		Customer c=(Customer)session.load(Customer.class, 1001);
		System.out.println(c);
		session.close();
	}

}
