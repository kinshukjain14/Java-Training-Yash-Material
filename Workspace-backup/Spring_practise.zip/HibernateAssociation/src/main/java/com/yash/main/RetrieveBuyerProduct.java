package com.yash.main;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

import com.yash.entity.Buyer;
import com.yash.entity.Product;

public class RetrieveBuyerProduct {

	public static void main(String[] args) {

		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		Buyer buyer=(Buyer)session.load(Buyer.class, 1);
		System.out.println("Buyer Id:"+buyer.getBuyerId());
		System.out.println("Buyer Name:"+buyer.getBuyerName());
		List<Product> productList=buyer.getProducts();
		for(Product product:productList) {
			System.out.println("Product Code:"+product.getProductCode());
			System.out.println("Product Name:"+product.getProductName());

		}
		session.close();
		
	}

}
