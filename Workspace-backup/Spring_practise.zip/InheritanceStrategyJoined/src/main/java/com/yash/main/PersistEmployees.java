package com.yash.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.yash.entity.Programmer;
import com.yash.entity.SalesExecutive;

public class PersistEmployees {

	public static void main(String[] args) {
		Programmer programmer=new Programmer();
		programmer.setEmpId(1002);
		programmer.setEmpName("Amit");
		programmer.setEmpSalary(21000);
		programmer.setProjectCode("P01");
		programmer.setProjectName("JD");
		
		SalesExecutive salesExecutive=new SalesExecutive();
		salesExecutive.setEmpId(1003);
		salesExecutive.setEmpName("Chirag");
		salesExecutive.setEmpSalary(9000);
		salesExecutive.setCommissionPCT(0.2);
		
		AnnotationConfiguration configuration=new AnnotationConfiguration();
		configuration.configure();
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.getTransaction();
		transaction.begin();
		session.persist(programmer);
		session.persist(salesExecutive);
		transaction.commit();
		session.close();		
	}

}
