package com.yash.entity;

import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.AttributeOverride;
@Entity
@AttributeOverrides({
		
		@AttributeOverride(name="empId",column=@Column(name="emp_id")),
		@AttributeOverride(name="empName",column=@Column(name="emp_Name")),
		@AttributeOverride(name="empSalary",column=@Column(name="emp_Salary"))		
})
@Table(name="Programmer_table")
public class Programmer extends Employee {
	
	public Programmer() {}
	
	@Column(name="project_code")
	private String projectCode;
	
	@Column(name="project_name")
	private String projectName;

	public String getProjectCode() {
		return projectCode;
	}

	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	@Override
	public String toString() {
		return "Programmer [projectCode=" + projectCode + ", projectName=" + projectName + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((projectCode == null) ? 0 : projectCode.hashCode());
		result = prime * result + ((projectName == null) ? 0 : projectName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Programmer other = (Programmer) obj;
		if (projectCode == null) {
			if (other.projectCode != null)
				return false;
		} else if (!projectCode.equals(other.projectCode))
			return false;
		if (projectName == null) {
			if (other.projectName != null)
				return false;
		} else if (!projectName.equals(other.projectName))
			return false;
		return true;
	}
	
	

}
