package com.yash.controller;

import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.MatrixVariable;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.yash.model.EmployeeError;
import com.yash.model.EmployeeRequest;
import com.yash.model.EmployeeResponse;
import com.yash.service.EmployeeService;

@RestController
@RequestMapping("api")
@CrossOrigin(origins = "*")
@EnableAspectJAutoProxy
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;

	@Autowired
	@Qualifier("employeeCustomValidator")
	private Validator validator;

	@Autowired
	@Qualifier("empIdValidator")
	private Validator empIdValidator;

//	@RequestMapping(value = "employees",method = RequestMethod.GET)
//	@PreAuthorize(value = "hasAuthority('READ_PRIVILEGES')")
	@GetMapping("employees")
	@PreAuthorize(value = "hasAurhority('ROLE_ADMIN')")
	public ResponseEntity<List<EmployeeResponse>> handleRequest() {
		List<EmployeeResponse> employeeResponseList = employeeService.employeesRetrievalServicesJSON();
		ResponseEntity<List<EmployeeResponse>> response = null;
		if (!employeeResponseList.isEmpty()) {
			response = new ResponseEntity<>(employeeResponseList, HttpStatus.OK);
		} else {
			response = new ResponseEntity<List<EmployeeResponse>>(employeeResponseList, HttpStatus.EXPECTATION_FAILED);
		}

		return response;
	}

	@GetMapping("employees/{empId}")
	public ResponseEntity<EmployeeResponse> retrieveEmployeeById(@PathVariable("empId") int empId) {
		ResponseEntity<EmployeeResponse> responseEntity = null;
		EmployeeRequest request = new EmployeeRequest();
		Errors errors = new BeanPropertyBindingResult(request,"request");
		request.setEmpId(empId);
		ValidationUtils.invokeValidator(empIdValidator, request, errors);
		if (errors.hasErrors()) {
			EmployeeError employeeError = new EmployeeError();
			employeeError.setErrorCode(999);
			List<ObjectError> allErrors = errors.getAllErrors();
			for (ObjectError objectError : allErrors) {
				employeeError.setErrorMessage(objectError.getDefaultMessage());
			}
			EmployeeResponse employeeResponse = new EmployeeResponse();
			employeeResponse.setEmployeeError(employeeError);
			responseEntity = new ResponseEntity<EmployeeResponse>(employeeResponse, HttpStatus.BAD_REQUEST);
		} else {

			EmployeeResponse employeeResponse = employeeService.getEmployee(empId);

			if (employeeResponse.getEmpId() != 0) {
				responseEntity = new ResponseEntity<EmployeeResponse>(employeeResponse, HttpStatus.FOUND);
			} else {
				responseEntity = new ResponseEntity<EmployeeResponse>(employeeResponse, HttpStatus.NOT_FOUND);
			}

		}

		return responseEntity;
	}

	@GetMapping("employeesreq")
	public ResponseEntity<EmployeeResponse> retrieveEmployeeByIdRequest(@RequestParam("empId") int empId) {
		EmployeeResponse employeeResponse = employeeService.getEmployee(empId);
		ResponseEntity<EmployeeResponse> responseEntity = null;
		if (employeeResponse.getEmpId() != 0) {
			responseEntity = new ResponseEntity<EmployeeResponse>(employeeResponse, HttpStatus.FOUND);
		} else {
			responseEntity = new ResponseEntity<EmployeeResponse>(employeeResponse, HttpStatus.NOT_FOUND);
		}
		return responseEntity;
	}

	@GetMapping("employeesmatrix/{employee}")
	public ResponseEntity<EmployeeResponse> retrieveEmployeeByIdMatrix(@MatrixVariable Integer empId) {
		EmployeeResponse employeeResponse = employeeService.getEmployee(empId);
		ResponseEntity<EmployeeResponse> responseEntity = null;
		if (employeeResponse.getEmpId() != 0) {
			responseEntity = new ResponseEntity<EmployeeResponse>(employeeResponse, HttpStatus.FOUND);
		} else {
			responseEntity = new ResponseEntity<EmployeeResponse>(employeeResponse, HttpStatus.NOT_FOUND);
		}
		return responseEntity;
	}

	@PostMapping("employees")
//	@PreAuthorize(value = "hasAuthority('WRITE_PRIVILEGES')")
	@PreAuthorize(value = "hasAuthority('ROLE_ADMIN')")
	public ResponseEntity<EmployeeResponse> persistEmployee(@RequestBody EmployeeRequest employeeRequest,
			Errors errors) 
	{
		ResponseEntity<EmployeeResponse> response = null;

		ValidationUtils.invokeValidator(validator, employeeRequest, errors);
		if (errors.hasErrors()) {
			EmployeeError employeeError = new EmployeeError();
			employeeError.setErrorCode(999);
			List<ObjectError> allErrors = errors.getAllErrors();
			for (ObjectError objectError : allErrors) {
				employeeError.setErrorMessage(objectError.getDefaultMessage());
			}
			EmployeeResponse employeeResponse = new EmployeeResponse();
			employeeResponse.setEmployeeError(employeeError);
			response = new ResponseEntity<EmployeeResponse>(employeeResponse, HttpStatus.BAD_REQUEST);
		} else {
			boolean result = employeeService.persistEmployee(employeeRequest);
			if (result) {
				EmployeeResponse employeeResponse = new EmployeeResponse();
				employeeResponse.setEmpId(employeeRequest.getEmpId());
				employeeResponse.setEmpName(employeeRequest.getEmpName());
				employeeResponse.setEmpSalary(employeeRequest.getEmpSalary());
				employeeResponse.setEmpDesignation(employeeRequest.getEmpDesignation());
				response = new ResponseEntity<EmployeeResponse>(employeeResponse, HttpStatus.CREATED);
			} else {
				response = new ResponseEntity<EmployeeResponse>(HttpStatus.CONFLICT);
			}
		}

		return response;
	}
	
	@PostMapping("employeesannotation")
	public ResponseEntity<EmployeeResponse> persistEmployeeAnnotation(@Valid @RequestBody EmployeeRequest employeeRequest) {
		ResponseEntity<EmployeeResponse> response = null;
			boolean result = employeeService.persistEmployee(employeeRequest);
			if (result) {
				EmployeeResponse employeeResponse = new EmployeeResponse();
				employeeResponse.setEmpId(employeeRequest.getEmpId());
				employeeResponse.setEmpName(employeeRequest.getEmpName());
				employeeResponse.setEmpSalary(employeeRequest.getEmpSalary());
				employeeResponse.setEmpDesignation(employeeRequest.getEmpDesignation());
				response = new ResponseEntity<EmployeeResponse>(employeeResponse, HttpStatus.CREATED);
			} else {
				response = new ResponseEntity<EmployeeResponse>(HttpStatus.CONFLICT);
			}
		return response;
	}

	@PatchMapping("employees/{empId}/{empSalary}")
	public ResponseEntity<Void> updateEmployeeSalary(@PathVariable("empId") int empId,
			@PathVariable("empSalary") double empSalary) {
		boolean result = employeeService.updateEmployee(empSalary, empId);
		ResponseEntity<Void> responseEntity = null;
		if (result) {
			responseEntity = new ResponseEntity<Void>(HttpStatus.ACCEPTED);
		} else {
			responseEntity = new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
		return responseEntity;
	}

	@PutMapping("employees")
	public ResponseEntity<String> updateEmployee(@RequestBody EmployeeRequest employeeRequest){
		boolean result = employeeService.updateEntityEmployee(employeeRequest);
		ResponseEntity<String> response = null;
		if(result) {
			response = new ResponseEntity<String>("Employee successfully updated",HttpStatus.ACCEPTED);
		}
		else {
			response = new ResponseEntity<String>("Employee updation failed",HttpStatus.NOT_MODIFIED);
		}
		return response;
	}
	
	@DeleteMapping("employees/{empId}")
	public ResponseEntity<Void> deleteEmployee(@PathVariable("empId") int empId) {
		boolean result = employeeService.deleteEmployee(empId);
		ResponseEntity<Void> responseEntity = null;
		if (result) {
			responseEntity = new ResponseEntity<Void>(HttpStatus.OK);
		} else {
			responseEntity = new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
		return responseEntity;
	}

}
