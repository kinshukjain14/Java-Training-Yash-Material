package com.yash.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.dao.EmployeeDAO;
import com.yash.entity.Employee;
import com.yash.model.EmployeeRequest;
import com.yash.model.EmployeeResponse;
import com.yash.model.EmployeeResponses;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDAO employeeDAO;
	
	public EmployeeResponses employeesRetrievalServicesXML() {

		List<Employee> employeeList=employeeDAO.getAllEmployees();
		List<EmployeeResponse> employeeResponseList=new ArrayList<EmployeeResponse>();
		for(Employee employee:employeeList) {
			EmployeeResponse employeeResponse=new EmployeeResponse();
			employeeResponse.setEmpId(employee.getEmpId());
			employeeResponse.setEmpName(employee.getEmpName());
			employeeResponse.setEmpSalary(employee.getEmpSalary());
			employeeResponse.setEmpDesignation(employee.getEmpDesignation());
			employeeResponseList.add(employeeResponse);
		}
		EmployeeResponses employeeResponses=new EmployeeResponses();
		employeeResponses.setEmployeeResponse(employeeResponseList);
		return employeeResponses;
	}

	public List<EmployeeResponse> employeesRetrievalServicesJSON() {
		List<Employee> employeeList=employeeDAO.getAllEmployees();
		List<EmployeeResponse> employeeResponseList=new ArrayList<EmployeeResponse>();
		for(Employee employee:employeeList) {
			EmployeeResponse employeeResponse=new EmployeeResponse();
			employeeResponse.setEmpId(employee.getEmpId());
			employeeResponse.setEmpName(employee.getEmpName());
			employeeResponse.setEmpSalary(employee.getEmpSalary());
			employeeResponse.setEmpDesignation(employee.getEmpDesignation());
			employeeResponseList.add(employeeResponse);
		}

		return employeeResponseList;
	}

	public EmployeeResponse getEmployee(int empId) {
			Employee employee=employeeDAO.getEmployeeById(empId);
			EmployeeResponse employeeResponse=new EmployeeResponse();
			employeeResponse.setEmpId(employee.getEmpId());
			employeeResponse.setEmpName(employee.getEmpName());
			employeeResponse.setEmpSalary(employee.getEmpSalary());
			employeeResponse.setEmpDesignation(employee.getEmpDesignation());
		return employeeResponse;
	}

	public boolean persistEmployee(EmployeeRequest employeeRequest) {
        Employee employee=new Employee();
        employee.setEmpId(employeeRequest.getEmpId());
        employee.setEmpName(employeeRequest.getEmpName());
        employee.setEmpSalary(employeeRequest.getEmpSalary());
        employee.setEmpDesignation(employeeRequest.getEmpDesignation());
        return employeeDAO.persistEmployee(employee);
	}

	public boolean updateEmployee(double empSalary, int empId) {
		return employeeDAO.updateEmployeeSalaryById(empId, empSalary);
	}

	public boolean deleteEmployee(int empId) {
		return employeeDAO.deleteEmployee(empId);
	}

	@Override
	public boolean checkEmpId(int empId) {
		return employeeDAO.checkEmpId(empId);
	}

	@Override
	public List<String> getDesignations() {
		List<String> designations = employeeDAO.getEmployeeDesignations();
		return designations;
	}

	@Override
	public boolean updateEntityEmployee(EmployeeRequest employeeRequest) {
		Employee employee = new Employee();
		employee.setEmpId(employeeRequest.getEmpId());
		employee.setEmpName(employeeRequest.getEmpName());
		employee.setEmpSalary(employeeRequest.getEmpSalary());
		employee.setEmpDesignation(employeeRequest.getEmpDesignation());
		boolean result = employeeDAO.updateEmployee(employee);
		return result;
	}
}
