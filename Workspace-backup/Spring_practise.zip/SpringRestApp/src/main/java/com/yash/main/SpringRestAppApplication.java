package com.yash.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;

import com.yash.configuration.DBConfiguration;
import com.yash.configuration.JDBCSpringSecurityConfig;
import com.yash.configuration.ValidationConfiguration;

@SpringBootApplication(scanBasePackages = "com.yash.*")
@ImportResource("classpath:applicationContext.xml")
@Import({ValidationConfiguration.class,DBConfiguration.class,JDBCSpringSecurityConfig.class})
@PropertySource("classpath:db.properties")
public class SpringRestAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestAppApplication.class, args);
	}
	
//	
//	@Bean("someobject")
//	public String getObject() {
//		return "someobject";
//	}
}
