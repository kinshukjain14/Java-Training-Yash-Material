package com.yash.entity;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "SalesExecutiveData")
public class SalesExecutive extends Employee{
	
	@Column(name="commission_pct")
	private double commissionPCT;

	public double getCommissionPCT() {
		return commissionPCT;
	}

	public void setCommissionPCT(double commissionPCT) {
		this.commissionPCT = commissionPCT;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		long temp;
		temp = Double.doubleToLongBits(commissionPCT);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		SalesExecutive other = (SalesExecutive) obj;
		if (Double.doubleToLongBits(commissionPCT) != Double.doubleToLongBits(other.commissionPCT))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SalesExecutive [commissionPCT=" + commissionPCT + "]";
	}

	
}
