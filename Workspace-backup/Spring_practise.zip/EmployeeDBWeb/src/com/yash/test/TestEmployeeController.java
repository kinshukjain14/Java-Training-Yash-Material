package com.yash.test;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.ModelAndView;
import com.yash.configuration.WebSpringConfig;
import com.yash.controller.EmployeeController;
import com.yash.model.AllEmployeesModel;
import com.yash.model.EmployeesModel;
import com.yash.service.EmployeesService;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {WebSpringConfig.class})
class TestEmployeeController {
	 private MockMvc mockMvc;
	 @Mock 
	 private EmployeesService employeesService;
	 @InjectMocks
	 private EmployeeController employeeController;
	   @BeforeEach
	    public void init(){
	        MockitoAnnotations.initMocks(this);
	        mockMvc = MockMvcBuilders
	                .standaloneSetup(employeeController)
	                .build();
	    }

	@AfterEach
	void tearDown() throws Exception {
	}
	@Test
	void testRetrieveEmployeesPositive() {
		List<EmployeesModel> employeesModelList=new ArrayList<>();
		EmployeesModel employeesModel=new EmployeesModel();
		employeesModel.setEmployeeId(1001);
		employeesModel.setFullName("sabbir poonawala");
		employeesModel.setTotalSalary(45000);				
		employeesModel.setContactDetails("Ph No:"+7777777+","+"Email:"+"xyz@abc.com");
		employeesModel.setEmail("xyz@abc.com");
		employeesModelList.add(employeesModel);
        when(employeesService.retrieveEmployees()).thenReturn(employeesModelList);
		//ModelAndView mv=employeeController.retrieveEmployees();
		//assertEquals("employeedetails",mv.getViewName());	    
	}
	@Test
	void testRetrieveEmployeesNegative() {
		List<AllEmployeesModel> allemployeesModelList=new ArrayList<>();
		when(employeesService.retrieveAllEmployees()).thenReturn(allemployeesModelList);
		// mv=employeeController.retrieveEmployees();
		//assertEquals("noemployeedetails",mv.getViewName());	    
	}
}
