package com.yash.service;
import java.util.List;
import com.yash.model.DepartmentsModel;
public interface DepartmentsService {
	public List<DepartmentsModel> retrieveDepartments();
}
