package com.yash.helper;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class IOCContainer {
	
	public static ApplicationContext createIOContainer(String configFile) {
		ApplicationContext ioc=new ClassPathXmlApplicationContext(configFile);
		return ioc;
	}

}
