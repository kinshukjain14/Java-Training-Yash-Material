package com.yash.main;

import org.springframework.context.ApplicationContext;

import com.yash.controller.EmployeeController;
import com.yash.helper.IOCContainer;

public class RetrieveAllEmployeeModel {

	public static void main(String[] args) {
		ApplicationContext ioc=IOCContainer.createIOContainer("applicationContext.xml");
		EmployeeController controller=(EmployeeController)ioc.getBean("employeeController");
		String modelsList=controller.handleGetAllEmployeeModels();
		System.out.println(modelsList);
	}

}
