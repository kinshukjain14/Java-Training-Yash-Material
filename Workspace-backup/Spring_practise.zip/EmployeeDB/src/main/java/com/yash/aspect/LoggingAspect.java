package com.yash.aspect;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class LoggingAspect {
	Logger logger = Logger.getLogger("LoggingAspect");
	//.* any class .*(..) any method
	//.* all sub-packages .* all classes .*(..) all methods with any parameters
//	@Before(value = "execution(* com.yash.controller.*.*(..))")
	@Before(value = "execution(* com.yash.*.*.*(..))")
	public void beforeAdvice(JoinPoint joinPoint) {
		logger.log(Level.INFO,"Before Advice applied -- "+joinPoint.getSignature().getName());
	}
	
	@After(value = "execution(* com.yash.*.*.*(..))")
	public void afterAdvice(JoinPoint joinPoint) {
		logger.log(Level.INFO,"After Advice applied -- "+joinPoint.getSignature().getName());
	}

	@AfterReturning(pointcut = "within(com.yash.controller.*)",returning = "result")
	public void afterReturningAdvice(JoinPoint joinPoint,Object result) {
		logger.log(Level.INFO,"After returning aspect -- "+joinPoint.getSignature().getName()+" Returns :- "+result);
	}
	
	@AfterThrowing(pointcut = "execution(* com.yash.*.*.*(..))",throwing = "error")
	public void afterThrowing(JoinPoint joinPoint,Throwable error) {
		logger.log(Level.INFO,"After throwing aspect -- "+joinPoint.getSignature().getName()+" Error :- "+error);		
	}
	
	@Pointcut(value = "execution(* com.yash.controller.EmployeeController.handleGetAllEmployeeModels(..))")
	public void getPointCut() {
		
	}
	
	@Around(value = "getPointCut()")
	public Object aroundAdvice(ProceedingJoinPoint joinPoint) {
		logger.log(Level.INFO,"Around advice applied -- "+joinPoint.getSignature().getName());
		Object proceed=null;
		try {
		 proceed = joinPoint.proceed();
			
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String methodReturned = (String) proceed;
		return methodReturned.toUpperCase();
	}
}
