package com.yash.main;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;

import com.yash.controller.EmployeeController;
import com.yash.helper.IOCContainer;

public class DeleteEmployeeModel {

	public static void main(String[] args) {

		ApplicationContext ioc=IOCContainer.createIOContainer("applicationContext.xml");
		EmployeeController controller=(EmployeeController)ioc.getBean("employeeController");
		Scanner scanner=new Scanner(System.in);
		System.out.print("Employee Id:");
		int empId=0;
		if(scanner.hasNextInt()) {
			empId=scanner.nextInt();
		}

       String result=controller.handleDeleteEmployeeModel(empId);
       System.out.println("Result:"+result);
	
	}

}
