package com.yash.main;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.yash.controller.EmployeeController;
import com.yash.helper.IOCContainer;
import com.yash.model.EmployeeModel;

public class PersistEmployeeModel {

	public static void main(String[] args) {


		ApplicationContext ioc=IOCContainer.createIOContainer("applicationContext.xml");
		EmployeeController controller=(EmployeeController)ioc.getBean("employeeController");
		Scanner scanner=new Scanner(System.in);
		System.out.print("Employee Id:");
		int empId=0;
		if(scanner.hasNextInt()) {
			empId=scanner.nextInt();
		}
		System.out.print("Employee Name:");
		String empName=null;
		if(scanner.hasNext()) {
			empName=scanner.next();
		}
		System.out.print("Employee Salary:");
		double empSalary=0;
		if(scanner.hasNextDouble()) {
			empSalary=scanner.nextDouble();
		}
		System.out.print("Employee Designation:");
		String empDesignation=null;
		if(scanner.hasNext()) {
			empDesignation=scanner.next();
		}
		
		EmployeeModel model=new EmployeeModel();
		model.setEmpId(empId);
		model.setEmpName(empName);
		model.setEmpSalary(empSalary);
		model.setEmpDesignation(empDesignation);
		
		ObjectMapper mapper=new ObjectMapper();
		
		try {
			String result=controller.handlePersistEmployeeModel(mapper.writeValueAsString(model));
			System.out.println("Result:"+result);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
