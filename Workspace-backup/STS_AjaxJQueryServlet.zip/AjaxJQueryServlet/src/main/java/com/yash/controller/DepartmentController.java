package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.factory.DepartmentFactory;
import com.yash.model.DepartmentsModel;
import com.yash.service.DepartmentsService;

/**
 * Servlet implementation class DepartmentController
 */
public class DepartmentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DepartmentController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		int departmentId=Integer.parseInt(request.getParameter("departmentId"));
		String departmentName=request.getParameter("departmentName");
		int managerId=Integer.parseInt(request.getParameter("managerId"));
		int locationId=Integer.parseInt(request.getParameter("locationId"));
		
		
		DepartmentsModel departmentsModel=new DepartmentsModel();
		departmentsModel.setDepartmentId(departmentId);
		departmentsModel.setDepartmentName(departmentName);
		departmentsModel.setManagerId(managerId);
		departmentsModel.setLocationId(locationId);
		
		DepartmentsService departmentsService=DepartmentFactory.createDepartmentsService();
		boolean isDepartmentRegistered=departmentsService.storeDepartments(departmentsModel);
		PrintWriter pw=response.getWriter();
		if(isDepartmentRegistered) {
			pw.println("Department successfully registered");
		}else {
			pw.println("Department registeration failed");

		}
	}

}
