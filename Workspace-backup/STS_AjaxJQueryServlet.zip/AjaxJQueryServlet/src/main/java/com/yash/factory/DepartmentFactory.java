package com.yash.factory;

import com.yash.dao.DepartmentsDAO;
import com.yash.dao.JDBCDepartmentsDAOImpl;
import com.yash.service.DepartmentsService;
import com.yash.service.DepartmentsServiceImpl;

public class DepartmentFactory {
	
	public static DepartmentsDAO createDepartmentDAO() {
		DepartmentsDAO departmentsDAO=new JDBCDepartmentsDAOImpl();
		return departmentsDAO;
	}

	public static DepartmentsService createDepartmentsService() {
		DepartmentsService departmentsService=new DepartmentsServiceImpl();
		return departmentsService;
	}
}
