package com.yash.service;

import java.util.List;

import com.yash.entities.Employees;

public interface EmployeeService {

	public List<Employees> getAllEmployees();
}
