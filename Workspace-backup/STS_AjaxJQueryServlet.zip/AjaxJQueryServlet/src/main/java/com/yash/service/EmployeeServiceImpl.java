package com.yash.service;

import java.util.List;

import com.yash.dao.EmployeesDAO;
import com.yash.entities.Employees;
import com.yash.exception.DAOException;
import com.yash.factory.EmployeeFactory;

public class EmployeeServiceImpl implements EmployeeService {

	public List<Employees> getAllEmployees() {
		EmployeesDAO employeesDAO=EmployeeFactory.createEmployeeDAO();
		List<Employees> employeesList=null;
		try {
			employeesList=employeesDAO.getAllEmployees();
		} catch (DAOException e) {
			e.printStackTrace();
		}
		return employeesList;
	}

}
