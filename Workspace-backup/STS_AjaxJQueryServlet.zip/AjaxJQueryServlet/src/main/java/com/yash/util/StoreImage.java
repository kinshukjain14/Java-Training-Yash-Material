package com.yash.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.yash.helper.ConnectionManager;

public class StoreImage {

	public static void main(String[] args) throws FileNotFoundException {

		File file=new File("d:\\javainductionio\\image\\logo.jpg");
		InputStream is=new FileInputStream(file);
		
		ConnectionManager manager=new ConnectionManager();
		try {
			Connection connection=manager.openConnection();
			PreparedStatement statement=connection.prepareStatement("insert into ImageTable values(?,?)");
			statement.setInt(1, 1);
			statement.setBlob(2, is);
			int rows=statement.executeUpdate();
			System.out.println("Image inserted:"+rows);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
