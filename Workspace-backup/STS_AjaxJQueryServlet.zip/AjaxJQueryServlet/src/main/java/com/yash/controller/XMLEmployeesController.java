package com.yash.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.yash.entities.Company;
import com.yash.entities.Employees;
import com.yash.factory.EmployeeFactory;
import com.yash.service.EmployeeService;

/**
 * Servlet implementation class XMLEmployeesController
 */
public class XMLEmployeesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public XMLEmployeesController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("application/xml");
		Company company=new Company();
		company.setCompanyName("Yash Technologies");
		company.setLocation("Pune");
		
		EmployeeService employeeService=EmployeeFactory.createEmployeeService();
		List<Employees> employee=employeeService.getAllEmployees();
		company.setEmployee(employee);
		
		try {
			JAXBContext context=JAXBContext.newInstance(Company.class);
			Marshaller marshaller=context.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			ServletOutputStream sos=response.getOutputStream();
			marshaller.marshal(company, sos);
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		
		
	}

}
