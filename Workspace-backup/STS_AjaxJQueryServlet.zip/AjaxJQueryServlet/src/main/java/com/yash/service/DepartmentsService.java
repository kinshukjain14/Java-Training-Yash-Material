package com.yash.service;

import com.yash.model.DepartmentsModel;

public interface DepartmentsService {
	
	public boolean storeDepartments(DepartmentsModel departmentsModel);

}
