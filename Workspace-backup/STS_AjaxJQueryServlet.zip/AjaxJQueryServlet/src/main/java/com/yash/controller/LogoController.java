package com.yash.controller;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.helper.ConnectionManager;

/**
 * Servlet implementation class LogoController
 */
public class LogoController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogoController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		response.setContentType("image/jpg");
		
		ConnectionManager manager=new ConnectionManager();
		try {
			Connection connection=manager.openConnection();
			PreparedStatement statement=connection.prepareStatement("select image_data from ImageTable where image_id=?");
		    statement.setInt(1, 1);
		    ResultSet resultSet=statement.executeQuery();
		    InputStream is=null;
		    while(resultSet.next()) {
		    	is=resultSet.getBinaryStream(1);
		    }
		    
		    ServletOutputStream sos=response.getOutputStream();
		    int k=0;
		    while((k=is.read())!=-1) {
		    	sos.write(k);
		    }
		    sos.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
