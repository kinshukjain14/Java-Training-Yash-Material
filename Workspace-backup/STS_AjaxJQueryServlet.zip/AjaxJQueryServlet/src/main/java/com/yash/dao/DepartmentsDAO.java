package com.yash.dao;

import com.yash.entities.Departments;
import com.yash.exception.DAOException;

public interface DepartmentsDAO {
	
	public boolean storeDepartment(Departments departments) throws DAOException;

}
