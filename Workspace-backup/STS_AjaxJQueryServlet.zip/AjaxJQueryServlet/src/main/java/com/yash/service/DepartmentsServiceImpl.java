package com.yash.service;

import com.yash.dao.DepartmentsDAO;
import com.yash.entities.Departments;
import com.yash.exception.DAOException;
import com.yash.factory.DepartmentFactory;
import com.yash.model.DepartmentsModel;

public class DepartmentsServiceImpl implements DepartmentsService {

	public boolean storeDepartments(DepartmentsModel departmentsModel) {
		DepartmentsDAO departmentDAO=DepartmentFactory.createDepartmentDAO();
		Departments departments=new Departments();
		departments.setDepartmentId(departmentsModel.getDepartmentId());
		departments.setDepartmentName(departmentsModel.getDepartmentName());
		departments.setLocationId(departmentsModel.getLocationId());
		departments.setManagerId(departmentsModel.getManagerId());
		boolean isDepartmentStored=false;
		try {
			isDepartmentStored=departmentDAO.storeDepartment(departments);
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return isDepartmentStored;
	}

}
