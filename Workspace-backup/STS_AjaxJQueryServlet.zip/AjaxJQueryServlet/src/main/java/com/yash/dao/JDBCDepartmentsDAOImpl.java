package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.yash.entities.Departments;
import com.yash.exception.DAOException;
import com.yash.helper.ConnectionManager;

public class JDBCDepartmentsDAOImpl implements DepartmentsDAO {
	private ConnectionManager manager=new ConnectionManager();

	public boolean storeDepartment(Departments departments) throws DAOException {
		int rows=0;
		try {
			Connection connection=manager.openConnection();
			PreparedStatement statement=connection.prepareStatement("insert into departments values(?,?,?,?)");
			statement.setInt(1, departments.getDepartmentId());
			statement.setString(2, departments.getDepartmentName());
			statement.setInt(3,departments.getManagerId());
			statement.setInt(4, departments.getLocationId());
			rows=statement.executeUpdate();
			manager.closeConnection();
		} catch (ClassNotFoundException e) {
			throw new DAOException(e,"DAO Exception");
		} catch (SQLException e) {
			throw new DAOException(e,"DAO Exception");
		}
		if(rows>0)
		return true;
		else
	    return false;
	}

}
