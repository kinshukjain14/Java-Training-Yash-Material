package com.yash.collection;

public class AutoboxingAutoUnboxingDemo {
	public static void main(String[] args) {
		int i=10;
		//boxing
		Integer o = new Integer(i);
		//unboxing
		i=o.intValue();
		// Java 5
		int j=10;
		//Auto boxing
		Integer o1=j;
		//Autounboxing
		j=o1;
	}
}
