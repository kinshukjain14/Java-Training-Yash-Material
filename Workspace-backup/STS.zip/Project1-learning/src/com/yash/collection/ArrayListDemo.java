package com.yash.collection;

import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo {
	public static void main(String[] args) {
		//heterogenous collection
		List list = new ArrayList();
		
	}
}
