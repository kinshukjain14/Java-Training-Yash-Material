package com.yash.collection;

import java.util.Arrays;

public class ArrayCopy {
	public static void main(String[] args) {
		char[] oldArray = {'a','e','i'};
		char[] newArray = new char[oldArray.length+1];
		System.out.println(oldArray);
		System.arraycopy(oldArray, 0, newArray, 0, newArray.length-1);
		newArray[3]='o';
		System.out.println(newArray);
		char[] newArray1 = Arrays.copyOf(oldArray, oldArray.length+1);
		newArray1[3]='w';
		System.out.println(newArray1);
	}
}
