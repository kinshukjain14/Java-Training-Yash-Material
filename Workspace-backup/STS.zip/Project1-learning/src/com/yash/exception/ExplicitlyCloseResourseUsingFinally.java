package com.yash.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExplicitlyCloseResourseUsingFinally {
	public static void main(String[] args) {
		Scanner scanner = null;
		try {
			 scanner  = new Scanner(System.in);
			int age=0;
//			if(scanner.hasNextInt()) {
//				age=scanner.nextInt();
//			}
			age=scanner.nextInt();
			System.out.println("Age : "+age);
		}
		catch(InputMismatchException e) {
			System.err.println("Age entered is not appropriate");
		}
		finally {
//			scanner.close();
		}
		
	}
}
