package com.yash.exception;

public class DataOperationFailedException extends Exception{
	String message ;

	public DataOperationFailedException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}
	
}
