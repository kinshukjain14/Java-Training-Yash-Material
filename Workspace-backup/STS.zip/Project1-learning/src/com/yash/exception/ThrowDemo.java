package com.yash.exception;

public class ThrowDemo {
	public static void main(String[] args) {
		String str = null;
		
		if(str != null) {
			str.toUpperCase();
		}
		else {
			throw new RuntimeException("Discontinue execution because condition was not fulfiled");
		}
		
		}
}
