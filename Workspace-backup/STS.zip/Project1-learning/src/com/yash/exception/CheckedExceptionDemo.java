package com.yash.exception;

import java.io.FileNotFoundException;
import java.io.IOException;

public class CheckedExceptionDemo {
	
	public Object createObject(String className) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		
		class SuperClass{
			void x() throws IOException{
				
			}
		}
		
		class SubClass extends SuperClass{
			@Override
			void x() throws FileNotFoundException {
				
			}
		}
		
//		try {
//			Class classData = Class.forName(className);
//			try {
//				return classData.newInstance();
//			} catch (InstantiationException | IllegalAccessException e) {
//				return new Object();
//			}
//		} catch (ClassNotFoundException e) {
//			return new Object();}
	
		Class classData = Class.forName(className);
		return classData.newInstance();
	}
	public static void main(String[] args) {
		CheckedExceptionDemo c = new CheckedExceptionDemo();
		MyClass myClass =null;
		try {
			myClass = (MyClass) c.createObject("com.yash.exception.MyClass1");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
		myClass.x();
	}
}
