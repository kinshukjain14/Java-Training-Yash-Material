package com.yash.exception;

public class WrapperException extends RuntimeException {

	public WrapperException(String message,Throwable t) {
		super(message,t);
	}
	
}
