package com.yash.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TryWithResourseDemo {
	public static void main(String[] args) {
		try(Scanner sc = new Scanner(System.in);){
			System.out.println("Enter age : ");
			int age = sc.nextInt();
			int doubleAge = age*2;
			System.out.println("Double of age : "+doubleAge);
		} 
		catch(InputMismatchException e) {
			System.out.println(e);
			Throwable[] allExceptions = e.getSuppressed();
			for (Throwable throwable : allExceptions) {
				System.out.println(throwable);
			}
		}
		
	}
}
		