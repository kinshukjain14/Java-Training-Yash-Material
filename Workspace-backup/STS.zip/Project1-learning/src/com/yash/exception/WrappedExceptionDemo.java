package com.yash.exception;

public class WrappedExceptionDemo {
	public Object createObject(String className) throws WrapperException {
		Class classData=null;
		Object retObject=null;
		try {
			classData = Class.forName(className);
			retObject = classData.newInstance();
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			throw new WrapperException("Exception Wrapped", e);
			
		}
		return retObject;
	}
	
	public static void main(String[] args)
	{
		WrappedExceptionDemo o = new WrappedExceptionDemo();
		try {
			
			MyClass myClass = (MyClass) o.createObject("com.yash.exception.MyClass1");
			myClass.x();
		}
		catch(WrapperException e) {
			System.err.println(e.getMessage());
			System.err.println(e.getCause());
		}
		System.out.println("--executed--");
	}
}
