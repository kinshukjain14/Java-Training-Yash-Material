package com.yash.exception;

public class FinallyDemo {
	public static void main(String[] args) {
		try {
			int a=1,b=1;
			System.out.println("--Before Exception--");
			int c = a/b;
			System.out.println("--After Exception--");
		}
//		catch(ArithmeticException e) {
//			System.out.println("Handling Exception");
//		}
		finally {
			System.out.println("--Finally Executed--");
		}
	}
}
