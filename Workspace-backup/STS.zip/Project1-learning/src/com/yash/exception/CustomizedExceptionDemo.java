package com.yash.exception;

public class CustomizedExceptionDemo {
	public static void main(String[] args){
		double withdraw = 5000;
		double balance = 2000;
		if(withdraw>balance) {
			try {
			throw new InsufficientFundException("Insuffecient balance");
			}
			catch(InsufficientFundException e) {
				System.err.println(e.getMessage());
			}
		}
		
		boolean flag = false;
		if(!flag) {
			try {
				throw new DataOperationFailedException("Data operation failed");
			}
			catch (DataOperationFailedException e) {
				System.err.println(e.getMessage());
			}
		}
	}
}
