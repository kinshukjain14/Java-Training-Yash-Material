package com.yash.exception;

public class TryCatch {

	public static void main(String[] args) {
		
	}

}
