package com.yash.exception;

import java.util.Scanner;

public class AssertionDemo {
	public static void main(String[] args) {
		try(Scanner sc = new Scanner(System.in)){
			System.out.println("Enter Age :");
			int age = sc.nextInt();
			assert age>0:"Age cannot be negative";
			age++;
			System.out.println("Age : "+age);
		}
		
		int noOFAdults = 2;
		int noOfChild = 3;
		int totalTickets = noOFAdults+noOfChild;
		int []tickets = new int[totalTickets];
		
		int pass = 1;
		for (int i = 0; i < tickets.length-1; i++) {
			tickets[i]=pass;
			pass++;
		}
		
		int n=0;
		while(n<tickets.length) {
			assert tickets[n]!=0 : "Pass not issues";
			n++;
		}
				
	}
}
