package com.yash.exception;

public class MyClass {
	public void x() {
		System.out.println("--x()--");
	}
}
