package com.yash.generics;

public class CacheAny <T> {
	private T data;
	
	public void add(T data) {
		this.data=data;
	}
	
	public T get() {
		return data;
	}
}
