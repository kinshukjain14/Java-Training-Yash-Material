package com.yash.generics;

import java.util.List;

public class GeneralizedMethods {
	public static void print(List<?> list) {
		for (Object o : list) {
			System.out.println(o);
		}
	}
}
