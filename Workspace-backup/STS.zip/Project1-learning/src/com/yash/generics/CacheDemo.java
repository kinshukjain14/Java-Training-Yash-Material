package com.yash.generics;

import java.util.ArrayList;
import java.util.List;

public class CacheDemo {
	public static void main(String[] args) {
		String data = "user_data";
		CacheString c=new CacheString();
		c.add(data);
		
		//later for retreval
		String databack = c.get();
		
		CacheAny<Integer> cacheInteger = new CacheAny<>();
		cacheInteger.add(12);
		
		List<String> list = new ArrayList<>();
		list.add("sd");
		
		List<Integer> list1 = new ArrayList<>();
		list1.add(1);
		
		GeneralizedMethods.print(list);
		GeneralizedMethods.print(list1);
		
		//List can contain all the object of type Number or all the objects of classes which are subclass of Number
		List<? super Number> generalizedListNumber = new ArrayList<>();
		generalizedListNumber.add(12);
		generalizedListNumber.add(10f);
		//generalizedListNumber.add("String"); compile time error
		
		GeneralizedMethods.print(generalizedListNumber);
		
		
//		List<? extends Number> generalizedListObject = new ArrayList<>();
//		generalizedListObject.add("ww");
	}
}
 