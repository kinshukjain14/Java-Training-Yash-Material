package com.yash.service;

public class CalculatorService {

	public int add(int no1, int no2) {
		if(no1>999 || no2>999) {
			throw new ArithmeticException("No1 or No2 cannot have four digits");
		}
		int sum=no1+no2;
		return sum;
	}

	public int div(int no1, int no2) {
		// TODO Auto-generated method stub
		return no1/no2;
	}

}
