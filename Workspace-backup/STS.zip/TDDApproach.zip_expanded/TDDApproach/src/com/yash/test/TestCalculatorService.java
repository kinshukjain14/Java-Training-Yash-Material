package com.yash.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.yash.service.CalculatorService;

public class TestCalculatorService {

	private CalculatorService calculatorService=null;
	
	@Before
	public void setUp() {
	    calculatorService=new CalculatorService();
	}
	@Test
	public void testAdd_positive() {
		//test data
		int no1=10;
		int no2=5;
		int expected=15;
		try {
		int actual=calculatorService.add(no1,no2);
		assertEquals(expected,actual);
		}catch(ArithmeticException e) {
			assertTrue(false);
		}
	}
	
	@Test
	public void testAdd_negativeWhenNo1isGreaterThan999() {
		//test data
		int no1=1000;
		int no2=5;
		try {
		calculatorService.add(no1,no2);
		assertTrue(false);
		}catch(ArithmeticException e) {
			assertTrue(true);
		}
	}
	
	@Test
	public void testAdd_negativeWhenNo2isGreaterThan999() {
		//test data
		int no1=10;
		int no2=1000;
		try {
		calculatorService.add(no1,no2);
		assertTrue(false);
		}catch(ArithmeticException e) {
			assertTrue(true);
		}
	}
	@Test
	public void testAdd_negativeWhenNo1orNo2isGreaterThan999ExceptionObjectShouldHaveMessage() {
		//test data
		int no1=1000;
		int no2=1000;
		try {
		calculatorService.add(no1,no2);
		assertTrue(false);
		}catch(ArithmeticException e) {
			assertTrue(true);
			assertEquals("No1 or No2 cannot have four digits",e.getMessage());
			
		}
	}
	@Test(expected = ArithmeticException.class)
	public void testDiv_ExceptionIsThrownwhenNo2isZero() {
		int no1=4;
		int no2=0;
		calculatorService.div(no1,no2);
	}
	
	@After
	public void tearDown() {
		calculatorService=null;
	}

}
