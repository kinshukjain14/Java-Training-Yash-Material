package com.yash.factory;

import com.yash.dao.AuthUserDAO;
import com.yash.dao.MemoryAuthUserDAOImpl;

public class FactoryAuthUserDAO {
	public static AuthUserDAO getInstance() {
		AuthUserDAO authUserDAO=new MemoryAuthUserDAOImpl();
		return authUserDAO;
	}
}
