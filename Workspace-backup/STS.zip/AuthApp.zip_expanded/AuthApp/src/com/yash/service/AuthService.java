package com.yash.service;

import com.yash.exception.AuthenticationException;
import com.yash.model.UserModel;

public interface AuthService {
	
	public UserModel authService(UserModel userModel) throws AuthenticationException;

}
