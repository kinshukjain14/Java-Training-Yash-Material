package com.yash.service;

import com.yash.dao.AuthUserDAO;
import com.yash.exception.AuthenticationException;
import com.yash.factory.FactoryAuthUserDAO;
import com.yash.model.UserModel;

public class AuthServiceImpl implements AuthService {

	private AuthUserDAO authUserDAO;
	public AuthServiceImpl() {
		this.authUserDAO=FactoryAuthUserDAO.getInstance();
	}
	@Override
	public UserModel authService(UserModel userModel) throws AuthenticationException {	
		boolean authenticated=authUserDAO.authUser(userModel.getUserName(), userModel.getPassword());
		if(authenticated) {
			userModel.setAuthenticated(true);
			return userModel;
		}else {
			throw new AuthenticationException("username or password do not match in records..");
		}
		
	}

}
