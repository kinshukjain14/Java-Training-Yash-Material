package com.yash.dao;

public interface AuthUserDAO {

	public boolean authUser(String userName,String password);
}
