package com.yash.dao;

import java.util.Map;

import com.yash.entity.User;
import com.yash.repository.UserRepository;

public class MemoryAuthUserDAOImpl implements AuthUserDAO {

	private Map<String,User> userDetails;
	public MemoryAuthUserDAOImpl() {
		this.userDetails=UserRepository.loadUserInfo();
	}
	
	@Override
	public boolean authUser(String userName, String password) {

		User user=userDetails.get(userName);
		if(user!=null) {
			String passwordFromUserDetails=user.getPassword();
			if(passwordFromUserDetails.equals(password)) {
				return true;
			}else {
				return false;
			}
		}else {
		return false;
		}
	}

}
