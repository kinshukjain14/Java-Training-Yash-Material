package com.yash.view;

import com.yash.model.UserModel;

public class WelcomeView {
	public void welcomeUser(UserModel user) {
		System.out.println("Welcome,"+user.getUserName());
	}

}
