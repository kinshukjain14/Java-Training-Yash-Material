package com.yash.view;

public class ErrorView {

	public void authError() {

		System.err.println("Either username or password is incorrect");
	}

}
