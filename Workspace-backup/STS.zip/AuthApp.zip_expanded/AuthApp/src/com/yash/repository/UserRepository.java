package com.yash.repository;

import java.util.HashMap;
import java.util.Map;

import com.yash.entity.User;

public class UserRepository {
	
	private static Map<String,User> userInfo=new HashMap<>();
	
	public static Map<String,User> loadUserInfo(){
		userInfo.put("sabbirp", new User("sabbirp","sabbirp","sabbir","poonawala"));
		userInfo.put("amitk", new User("amitk","amitk","amit","kumar"));
		userInfo.put("rajeshp", new User("rajesh","patel","rajesh","patel"));
		return userInfo;
	}

}
