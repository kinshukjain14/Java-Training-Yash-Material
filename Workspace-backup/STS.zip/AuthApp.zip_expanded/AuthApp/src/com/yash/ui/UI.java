package com.yash.ui;
import com.yash.view.LoginView;
public class UI {
	public static void main(String[] args) {
		LoginView loginView=new LoginView();
		loginView.login();
	}

}
