package com.yash.controller;

import com.yash.exception.AuthenticationException;
import com.yash.factory.FactoryAuthService;
import com.yash.model.UserModel;
import com.yash.service.AuthService;
import com.yash.view.ErrorView;
import com.yash.view.WelcomeView;

public class AuthenticationController {

	private AuthService authService;
	public AuthenticationController() {
		this.authService=FactoryAuthService.getInstance();
	}
	public void authUser(UserModel userModel) {
		try {
			UserModel user=authService.authService(userModel);
			WelcomeView welcomeView=new WelcomeView();
			welcomeView.welcomeUser(user);
			
		} catch (AuthenticationException e) {

			ErrorView errorView=new ErrorView();
			errorView.authError();
		}
	}
}
