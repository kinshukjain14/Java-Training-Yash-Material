package com.yash.service;

import java.util.Arrays;

public class ArrayOperations {

	public int[] sortArray(int[] arrTestData) {
		if(arrTestData.length == 0) {
			throw new ArrayIndexOutOfBoundsException("Array size cannot be 0");
		}
		Arrays.sort(arrTestData);
		return arrTestData;
	}

}
