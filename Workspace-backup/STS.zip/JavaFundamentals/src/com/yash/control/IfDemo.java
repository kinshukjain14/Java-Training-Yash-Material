package com.yash.control;

public class IfDemo {

	public static void main(String[] args)
	{
		int age = 18;
		if(age>=18) 
		{
			System.out.println("Age is 18");
		}
		else if(age<18) 
		{
			
		}
		else if(age<14) {
			
		}
		else {
			
		}
		
		
		boolean b=false;
		if(b) 
		{
			System.out.println("Executed");
		}
		
	}
	

}
