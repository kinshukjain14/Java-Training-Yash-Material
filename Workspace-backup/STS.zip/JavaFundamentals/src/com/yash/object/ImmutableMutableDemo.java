package com.yash.object;

public class ImmutableMutableDemo {
	public static void main(String[] args) {
		Employee e = new Employee(1001,"Kinshuk",21100,"Trainee");
		System.out.println("Emp id : "+e.getEmpId());
//		e.empId=1001;
		System.out.println("Emp id : "+e.getEmpId());
	}
}
