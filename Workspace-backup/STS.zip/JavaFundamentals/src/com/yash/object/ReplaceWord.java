package com.yash.object;

public class ReplaceWord
{
	public static void main(String[] args) {
		
	}
}
