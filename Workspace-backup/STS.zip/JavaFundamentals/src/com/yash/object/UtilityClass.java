package com.yash.object;

public class UtilityClass {
	public float price() {
		return 10.0f; 
	}
}
