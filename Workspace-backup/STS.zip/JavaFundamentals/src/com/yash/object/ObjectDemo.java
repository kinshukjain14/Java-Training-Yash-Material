package com.yash.object;

public class ObjectDemo {

	public static void main(String[] args) {

	}

}
