package com.yash.sax;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

public class QueryXML {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {

		 Scanner scanner=new Scanner(System.in);
	     System.out.print("Roll No:");
	     String rollNo=scanner.next();
	     
	     InputStream is=ClassLoader.getSystemResourceAsStream("students.xml");
	     File xmlFile=new File("D:\\javainductionio\\sax\\students.xml");
	     SAXParserFactory saxParserFactory=SAXParserFactory.newInstance();
	     SAXParser saxParser=saxParserFactory.newSAXParser();
	     //saxParser.parse(is, new StudentHandler());
	     saxParser.parse(xmlFile, new StudentQueryHandler(rollNo));
	     scanner.close();
	}

}
