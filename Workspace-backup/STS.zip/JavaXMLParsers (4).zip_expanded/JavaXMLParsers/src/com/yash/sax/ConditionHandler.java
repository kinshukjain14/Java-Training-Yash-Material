package com.yash.sax;

//import org.apache.commons.text.StringEscapeUtils;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ConditionHandler extends DefaultHandler {

	boolean bTest=false;
	StringBuilder builder=new StringBuilder();
	
	 @Override
	   public void startElement(String uri, 
	   String localName, String qName, Attributes attributes) throws SAXException {

	      if (qName.equalsIgnoreCase("condition")) {
	         //String id = attributes.getValue("id");
	         //System.out.println("Id : " + id);
	      } else if (qName.equalsIgnoreCase("test")) {
	    	  bTest = true;
	      } 
	     
	   }
	   @Override
	   public void endElement(String uri, 
	   String localName, String qName) throws SAXException {
	      if (qName.equalsIgnoreCase("condition")) {
	         System.out.println("End Element :" + qName);
	      }
	   }
	   
	   
	   @Override
	   public void characters(char ch[], int start, int length) throws SAXException {
	     
	      if (bTest) {
			  builder.append(ch,start,length);
	         System.out.println("Test: " 
	            + builder.toString());
	         bTest = false;
	      } 
	   }
	   
}
