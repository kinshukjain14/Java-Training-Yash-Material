package com.yash.sax;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.charset.StandardCharsets;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

//import org.apache.commons.lang3.StringEscapeUtils;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

public class ConditionSAXParser {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
   	 //InputStream is= ClassLoader.getSystemResourceAsStream("conditions.xml");
		Reader is=new FileReader("D:\\javainductionio\\sax\\condition.xml");
   	SAXParserFactory factory = SAXParserFactory.newInstance();
    SAXParser saxParser = factory.newSAXParser();

    XMLReader xmlReader=saxParser.getXMLReader();
    ConditionHandler conditionHandler = new ConditionHandler();
    xmlReader.setContentHandler(conditionHandler);
    
    InputSource inputSource=new InputSource(is);
  
    inputSource.setEncoding(StandardCharsets.UTF_8.displayName());

    xmlReader.parse(inputSource);
	}

}
