package com.yash.sax;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

public class CreateXMLSpecialCharacters {

	public static void main(String[] args) throws FileNotFoundException, XMLStreamException {

		FileOutputStream fileOutputStream = new FileOutputStream("D:\\javainductionio\\sax\\condition.xml");
		XMLOutputFactory output = XMLOutputFactory.newInstance();

        XMLStreamWriter xmlWriter = output.createXMLStreamWriter(fileOutputStream);

        
        xmlWriter.writeStartElement("condition");
        
        xmlWriter.writeStartElement("test");
        xmlWriter.writeCData("4>3");
        xmlWriter.writeEndElement();
        
        xmlWriter.writeEndElement();

        xmlWriter.writeEndDocument();

        xmlWriter.flush();
        xmlWriter.close();
	}

}
