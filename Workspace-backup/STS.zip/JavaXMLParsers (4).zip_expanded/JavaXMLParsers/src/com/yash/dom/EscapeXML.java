package com.yash.dom;

import org.apache.commons.text.StringEscapeUtils;

public class EscapeXML {

	public static void main(String[] args) {

		String data=StringEscapeUtils.unescapeXml("<![CDATA[4 &gt; 3]]");
		System.out.println(data);
		
		String data1=StringEscapeUtils.escapeXml10("<![CDATA[4 > 3]]");
		System.out.println(data1);
	}
	

}
