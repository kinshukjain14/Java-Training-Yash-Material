package com.yash.dom;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

public class CreateXMLDocument {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, TransformerException {

		File xmlFile=new File("D:\\javainductionio\\dom\\departments.xml");
		
		DocumentBuilderFactory documentBuilderFactory=DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder=documentBuilderFactory.newDocumentBuilder();
		Document document=documentBuilder.newDocument();
		
		Element rootElement=document.createElement("company");
		rootElement.setAttribute("companyName", "Yash Technologies");
		document.appendChild(rootElement);
		
		Element departmentElement=document.createElement("department");
		rootElement.appendChild(departmentElement);
		
		Attr departmentNameAttribute=document.createAttribute("departmentName");
		departmentNameAttribute.setValue("IT");
		departmentElement.setAttributeNode(departmentNameAttribute);
		
		Element employee1Element=document.createElement("employee");
		Attr attrEmpId1=document.createAttribute("empId");
		attrEmpId1.setValue("1001");
		employee1Element.setAttributeNode(attrEmpId1);
		departmentElement.appendChild(employee1Element);
		
		Element employee2Element=document.createElement("employee");
		Attr attrEmpId2=document.createAttribute("empId");
		attrEmpId2.setValue("1002");
		employee2Element.setAttributeNode(attrEmpId2);
		departmentElement.appendChild(employee2Element);
		
		Element employee3Element=document.createElement("employee");
		Attr attrEmpId3=document.createAttribute("empId");
		attrEmpId3.setValue("1003");
		employee3Element.setAttributeNode(attrEmpId3);
		departmentElement.appendChild(employee3Element);
		
		
		TransformerFactory transformerFactory=TransformerFactory.newInstance();
		Transformer transformer=transformerFactory.newTransformer();
		
		DOMSource domSource=new DOMSource(document);
		
		StreamResult streamResult=new StreamResult(xmlFile);
		
		transformer.transform(domSource, streamResult);
		
		
		
	}

}
