package com.yash.dom;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class QueryEmployeeDataXML {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		
		
		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter Department Name:");
		String deptName=scanner.next();
		
        File xmlFile=new File("D:\\javainductionio\\dom\\company.xml");
		InputStream is=ClassLoader.getSystemResourceAsStream("company.xml");
		
		DocumentBuilderFactory documentBuilderFactory=DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder=documentBuilderFactory.newDocumentBuilder();
		//Document document=documentBuilder.parse(xmlFile);
		Document document=documentBuilder.parse(is);
		document.getDocumentElement().normalize();
		String rootElement=document.getDocumentElement().getNodeName();
		System.out.println("Root Element:"+rootElement);
		
		System.out.println(document.getDocumentElement().getNodeName());
		
		NodeList nodeList=document.getElementsByTagName("department");
		for(int i=0;i<nodeList.getLength();i++) {
			
			Node node=nodeList.item(i);
			System.out.println(node.getNodeName());
			
			if(node.getNodeType()==Node.ELEMENT_NODE) {
				Element element=(Element)node;
				String departmentName=element.getAttribute("departmentName");
				if(deptName.equals(departmentName)) {
				System.out.println("Department Name:"+element.getAttribute("departmentName"));
				NodeList empList=element.getElementsByTagName("employee");
				
				
				for(int j=0;j<empList.getLength();j++) {
					Node empNode=empList.item(j);
					if(empNode.getNodeType()==Node.ELEMENT_NODE) {
						Element empElement=(Element)empNode;
						System.out.println("Employee Id:"+empElement.getAttribute("empId"));
						System.out.println("Employee Name:"+empElement.getTextContent());
					}
				}
				}
			}
			
		}
		
	}

}
