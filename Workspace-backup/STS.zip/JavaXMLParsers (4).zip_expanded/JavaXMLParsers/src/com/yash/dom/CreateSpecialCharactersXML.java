package com.yash.dom;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.apache.commons.lang3.CharSet;
import org.apache.commons.text.StringEscapeUtils;

public class CreateSpecialCharactersXML {

	public static void main(String[] args) throws ParserConfigurationException, TransformerException, IOException {
File xmlFile=new File("D:\\javainductionio\\dom\\conditions.xml");
		
		DocumentBuilderFactory documentBuilderFactory=DocumentBuilderFactory.newInstance();
	    documentBuilderFactory.setCoalescing(true);
		DocumentBuilder documentBuilder=documentBuilderFactory.newDocumentBuilder();
		Document document=documentBuilder.newDocument();
		
		Element rootElement=document.createElement("condition");
		rootElement.setAttribute("id", "1");
		document.appendChild(rootElement);
		
		
		Element testElement=document.createElement("test");
		
		CDATASection cd=document.createCDATASection("<![CDATA[4 > 3]]");
		String data=StringEscapeUtils.escapeXml11("<![CDATA[4 &#62; 3]]");
		testElement.setTextContent(data);
		rootElement.appendChild(testElement);
		
		
		
	
		TransformerFactory transformerFactory=TransformerFactory.newInstance();
		Transformer transformer=transformerFactory.newTransformer();
		
	
		DOMSource domSource=new DOMSource(document);

		StreamResult streamResult=new StreamResult();
		OutputStream os=new FileOutputStream(xmlFile);
		
		OutputStreamWriter outputStreamWriter=new OutputStreamWriter(os,"UTF-8");
		
		streamResult.setWriter(new PrintWriter(xmlFile,"UTF-8"));
		
		transformer.transform(domSource, streamResult);
	}

}
