package com.yash.sax;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class StudentQueryHandler extends DefaultHandler{

	private String rollNoGiven=null;
	
	boolean bFirstName=false;
	boolean bLastName=false;
	boolean bSemester1Marks=false;
	boolean bSemester2Marks=false;
	boolean bSemester3Marks=false;
	boolean bSemester4Marks=false;
	boolean bSemester5Marks=false;
	boolean bSemester6Marks=false;
	
	String rollNo=null;
	
	public StudentQueryHandler(String rollNoGiven) {
		this.rollNoGiven=rollNoGiven;
	}
	
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		
		if(qName.equalsIgnoreCase("student")) {
			rollNo = attributes.getValue("rollNo");
			if(rollNo.equalsIgnoreCase(this.rollNoGiven) && qName.equalsIgnoreCase("student")) {
				System.out.println("Roll No :" + rollNo);				
			}
		}else if(qName.equalsIgnoreCase("firstname") && rollNo.equalsIgnoreCase(this.rollNoGiven)  ){
			bFirstName=true;
		}else if(qName.equalsIgnoreCase("lastname") && rollNo.equalsIgnoreCase(this.rollNoGiven)){
			bLastName=true;
		}else if(qName.equalsIgnoreCase("semester1Marks") && rollNo.equalsIgnoreCase(this.rollNoGiven)){
			bSemester1Marks=true;
		}else if(qName.equalsIgnoreCase("semester2Marks") && rollNo.equalsIgnoreCase(this.rollNoGiven)){
			bSemester2Marks=true;
		}else if(qName.equalsIgnoreCase("semester3Marks") && rollNo.equalsIgnoreCase(this.rollNoGiven)){
			bSemester3Marks=true;
		}else if(qName.equalsIgnoreCase("semester4Marks") && rollNo.equalsIgnoreCase(this.rollNoGiven)){
			bSemester4Marks=true;
		}else if(qName.equalsIgnoreCase("semester5Marks") && rollNo.equalsIgnoreCase(this.rollNoGiven)){
			bSemester5Marks=true;
		}else if(qName.equalsIgnoreCase("semester6Marks") && rollNo.equalsIgnoreCase(this.rollNoGiven)){
			bSemester6Marks=true;
		}
		
	}
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {

		if(bFirstName && rollNo.equalsIgnoreCase(rollNoGiven)) {
			System.out.println("First Name:"+new String(ch,start,length));
			bFirstName=false;
		}else if(bLastName && rollNo.equalsIgnoreCase(rollNoGiven)) {
			System.out.println("Last Name:"+new String(ch,start,length));
			bLastName=false;
		}
		else if(bSemester1Marks && rollNo.equalsIgnoreCase(rollNoGiven)) {
			System.out.println("Semester 1 Marks:"+new String(ch,start,length));
			bSemester1Marks=false;
		}
		else if(bSemester2Marks && rollNo.equalsIgnoreCase(rollNoGiven)) {
			System.out.println("Semester 2 Marks:"+new String(ch,start,length));
			bSemester2Marks=false;
		}
		else if(bSemester3Marks && rollNo.equalsIgnoreCase(rollNoGiven)) {
			System.out.println("Semester 3 Marks:"+new String(ch,start,length));
			bSemester3Marks=false;
		}
		else if(bSemester4Marks && rollNo.equalsIgnoreCase(rollNoGiven)) {
			System.out.println("Semester 4 Marks:"+new String(ch,start,length));
			bSemester4Marks=false;
		}
		else if(bSemester5Marks && rollNo.equalsIgnoreCase(rollNoGiven)) {
			System.out.println("Semester 5 Marks:"+new String(ch,start,length));
			bSemester5Marks=false;
		}else if(bSemester6Marks && rollNo.equalsIgnoreCase(rollNoGiven)) {
			System.out.println("Semester 6 Marks:"+new String(ch,start,length));
			bSemester6Marks=false;
		}
	}
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
     if(rollNo.equalsIgnoreCase(rollNoGiven) && qName.equalsIgnoreCase("student")) {
    	 System.out.println("End element:"+qName);
     }
    	 
	}
}
