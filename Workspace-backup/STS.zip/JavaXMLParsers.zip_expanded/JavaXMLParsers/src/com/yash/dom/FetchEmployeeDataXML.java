package com.yash.dom;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class FetchEmployeeDataXML {
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {

		File xmlFile=new File("D:\\fileHandling\\employees.xml");
		//InputStream is=ClassLoader.getSystemResourceAsStream("employees.xml");
		
		DocumentBuilderFactory documentBuilderFactory=DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder=documentBuilderFactory.newDocumentBuilder();
		Document document=documentBuilder.parse(xmlFile);
		//Document document=documentBuilder.parse(is);
		document.getDocumentElement().normalize();
		String rootElement=document.getDocumentElement().getNodeName();
		System.out.println("Root Element:"+rootElement);	
		
		NodeList nodeList=document.getElementsByTagName("employee");
		for(int i=0;i<nodeList.getLength();i++) {
			Node node=nodeList.item(i);
			System.out.println("Node Name:"+node.getNodeName());
			if(node.getNodeType()==Node.ELEMENT_NODE) {
				Element element=(Element)node;
				System.out.println("Emp Id:"+element.getAttribute("empId"));
				
			    System.out.println("Emp Name:"+element.getElementsByTagName("empName").item(0).getTextContent());
				System.out.println("Emp Salary"+element.getElementsByTagName("empSalary").item(0).getTextContent());
				System.out.println("Emp Designation:"+element.getElementsByTagName("empDesignation").item(0).getTextContent());
			}
			
		}
		
		
		
		
		
	}

}
