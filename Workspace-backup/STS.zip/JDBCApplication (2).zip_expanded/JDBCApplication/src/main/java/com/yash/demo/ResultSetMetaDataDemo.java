package com.yash.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.yash.entities.Employees;

public class ResultSetMetaDataDemo {

	public static void main(String[] args) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Connection con=null;
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hrDB","root","root");
			Statement statement=con.createStatement();
			ResultSet resultSet=statement.executeQuery("select * from employees");
			ResultSetMetaData resultSetMetaData=resultSet.getMetaData();
			int columnCount=resultSetMetaData.getColumnCount();
			for(int i=1;i<=columnCount;i++) {
				System.out.println("Column Name:"+resultSetMetaData.getColumnLabel(i));
				System.out.println("Column Data Type:"+resultSetMetaData.getColumnTypeName(i));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}

}
