package com.yash.demo;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class DateConverter {
	
	public static LocalDate convertLocalDate(String date,String delim) {
		
		LocalDate localDate=null;
		StringTokenizer stringTokens=new StringTokenizer(date,delim);
		List<String> tokenList=new ArrayList<>();
		while(stringTokens.hasMoreTokens()) {
			tokenList.add(stringTokens.nextToken());
		}
		int year=Integer.parseInt(tokenList.get(0));
		int month=Integer.parseInt(tokenList.get(1));
		int dayOfMonth=Integer.parseInt(tokenList.get(2));
		
		if(month==1) {
			localDate=LocalDate.of(year, Month.JANUARY, dayOfMonth);
		}
		if(month==2) {
			localDate=LocalDate.of(year, Month.FEBRUARY, dayOfMonth);
		}
		if(month==3) {
			localDate=LocalDate.of(year, Month.MARCH, dayOfMonth);
		}
		if(month==4) {
			localDate=LocalDate.of(year, Month.APRIL, dayOfMonth);
		}
		if(month==5) {
			localDate=LocalDate.of(year, Month.MAY, dayOfMonth);
		}
		if(month==6) {
			localDate=LocalDate.of(year, Month.JUNE, dayOfMonth);
		}
		if(month==7) {
			localDate=LocalDate.of(year, Month.JULY, dayOfMonth);
		}
		if(month==8) {
			localDate=LocalDate.of(year, Month.AUGUST, dayOfMonth);
		}
		if(month==9) {
			localDate=LocalDate.of(year, Month.SEPTEMBER, dayOfMonth);
		}
		if(month==10) {
			localDate=LocalDate.of(year, Month.OCTOBER, dayOfMonth);
		}
		if(month==11) {
			localDate=LocalDate.of(year, Month.NOVEMBER, dayOfMonth);
		}
		if(month==12) {
			localDate=LocalDate.of(year, Month.DECEMBER, dayOfMonth);
		}
		return localDate;
	}

}
