package com.yash.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.yash.entities.Employees;

public class RetrieveEmployeeByEmployeeId {

	public static void main(String[] args) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Employees employee=new Employees();
		try(
				Scanner scanner=new Scanner(System.in);
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hrDB","root","root");
				
			){
			
			System.out.print("Employee Id:");
			int employeeId=0;
			if(scanner.hasNextInt()) {
				employeeId=scanner.nextInt();
			}
			PreparedStatement statement=con.prepareStatement("select * from employees where employee_id=?");
			statement.setInt(1, employeeId);
			ResultSet resultSet=statement.executeQuery();
			while(resultSet.next()) {
				employee.setEmployeeId(resultSet.getInt("employee_id"));
				employee.setFirstName(resultSet.getString("first_name"));
				employee.setLastName(resultSet.getString("last_name"));
				employee.setEmail(resultSet.getString("email"));
				employee.setPhoneNumber(resultSet.getString("phone_number"));
				employee.setHireDate(resultSet.getDate("hire_date").toLocalDate());
				employee.setJobId(resultSet.getString("job_id"));
				employee.setSalary(resultSet.getDouble("salary"));
				employee.setCommissionPCT(resultSet.getDouble("commission_pct"));
				employee.setManagerId(resultSet.getInt("manager_id"));
				employee.setDepartmentId(resultSet.getInt("department_id"));
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		System.out.println(employee);
	}

}
