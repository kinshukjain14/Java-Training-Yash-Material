package com.yash.demo;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class DatabaseMetaDataDemo {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		try(
				Scanner scanner=new Scanner(System.in);
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hrDB","root","root");
				
			){
			
			DatabaseMetaData databaseMetaData=con.getMetaData();
			System.out.println("Database product Name:"+databaseMetaData.getDatabaseProductName());
			System.out.println("Database Major version:"+databaseMetaData.getDatabaseMajorVersion());
			System.out.println("Database Minor version:"+databaseMetaData.getDatabaseMinorVersion());
			System.out.println("Driver:"+databaseMetaData.getDriverName());


		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

}
