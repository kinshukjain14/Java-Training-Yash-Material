package com.yash.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Properties;
import java.util.Scanner;

import com.yash.entities.Employees;

public class StoreEmployeeDetails {

	public static void main(String[] args) throws ClassNotFoundException {

		File file=new File("D:\\javainductionio\\databaseconfig\\db.properties");
		Properties properties=new Properties();
		try(
			InputStream inStream=new FileInputStream(file);	
			){
			properties.load(inStream);
		}catch(IOException e) {
			e.printStackTrace();
		}
		Class.forName(properties.getProperty("driver"));
		Employees employee=new Employees();
		int rows=0;
		try(
		Scanner scanner=new Scanner(System.in);
		Connection con=DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("username"),properties.getProperty("password"));
		 ){
			System.out.print("Employee Id:");
			if(scanner.hasNextInt()) {
				employee.setEmployeeId(scanner.nextInt());
			}
			System.out.print("First Name:");
			if(scanner.hasNext()) {
				employee.setFirstName(scanner.next());
			}
			System.out.print("Last Name:");
			if(scanner.hasNext()) {
				employee.setLastName(scanner.next());
			}
			System.out.print("Email:");
			if(scanner.hasNext()) {
				employee.setEmail(scanner.next());
			}
			System.out.print("PhoneNumber(ISD-STD-NUMBER):");
			if(scanner.hasNext()) {
				employee.setPhoneNumber(scanner.next());
			}
			
			System.out.print("Hire Date(YYYY-MM-DD):");
			if(scanner.hasNext()) {
				String hireDate=scanner.next();
				employee.setHireDate(DateConverter.convertLocalDate(hireDate, "-"));
			}
			System.out.print("JOB ID:");
			if(scanner.hasNext()) {
				employee.setJobId(scanner.next());
			}
			
			System.out.print("Salary:");
			if(scanner.hasNextDouble()) {
				employee.setSalary(scanner.nextDouble());
			}
			System.out.print("Commission Percentage:");
			if(scanner.hasNextDouble()) {
				employee.setCommissionPCT(scanner.nextDouble());
			}
			System.out.print("Manager Id:");
			if(scanner.hasNextInt()) {
				employee.setManagerId(scanner.nextInt());
			}
			System.out.print("Department Id:");
			if(scanner.hasNextInt()) {
				employee.setDepartmentId(scanner.nextInt());
			}
			
			PreparedStatement statement=
					con.prepareStatement("insert into employees values(?,?,?,?,?,?,?,?,?,?,?)");
			statement.setInt(1, employee.getEmployeeId());
			statement.setString(2, employee.getFirstName());
			statement.setString(3, employee.getLastName());
			statement.setString(4, employee.getEmail());
			statement.setString(5,employee.getPhoneNumber());
			LocalDate localDate=employee.getHireDate();
			statement.setDate(6, java.sql.Date.valueOf(localDate));
			statement.setString(7,employee.getJobId());
			statement.setDouble(8, employee.getSalary());
			statement.setDouble(9, employee.getCommissionPCT());
			statement.setInt(10, employee.getManagerId());
			statement.setInt(11, employee.getDepartmentId());
			rows=statement.executeUpdate();
		}catch(InputMismatchException | SQLException e) {
			e.printStackTrace();
		}
		if(rows>0) {
			System.out.println("Insert was successful");
		}
	}

}
