package com.yash.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.ResourceBundle;
import java.util.Scanner;

import com.yash.entities.Countries;
import com.yash.entities.Departments;
import com.yash.entities.Employees;
import com.yash.entities.Jobs;
import com.yash.entities.Locations;
import com.yash.entities.Regions;

public class RetrieveEmployeeDetails {

	public static void main(String[] args) {

		ResourceBundle resourceBundle=ResourceBundle.getBundle("db");
		String driver=resourceBundle.getString("driver");
		String url=resourceBundle.getString("url");
		String username=resourceBundle.getString("username");
		String password=resourceBundle.getString("password");
		
		String queryEmployeeDeptInfo="select e.first_name,e.last_name,d.department_id,d.department_name,l.location_id,l.street_address,l.postal_code,c.country_name\r\n" + 
				",l.city,l.state_province,r.region_name,c.country_id,r.region_id\r\n" + 
				"from employees e\r\n" + 
				"join\r\n" + 
				"departments d\r\n" + 
				"on(e.department_id=d.department_id)\r\n" + 
				"join\r\n" + 
				"locations l\r\n" + 
				"on(d.location_id=l.location_id)\r\n" + 
				"join\r\n" + 
				"countries c\r\n" + 
				"on(l.country_id=c.country_id)\r\n" + 
				"join\r\n" + 
				"regions r\r\n" + 
				"on(c.region_id=r.region_id)\r\n" + 
				"where employee_id=?;\r\n";
		
		String queryEmployeeJobsInfo="select j.job_title,j.job_id\r\n" + 
				"from employees e\r\n" + 
				"join jobs j\r\n" + 
				"on(e.job_id=j.job_id)\r\n" + 
				"where employee_id=?";

		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Employees employee=new Employees();
		Departments department=new Departments();
		Locations locations=new Locations();
		Countries countries=new Countries();
		Regions regions=new Regions();
		Jobs jobs=new Jobs();
		try(
		  Scanner scanner=new Scanner(System.in);
		  Connection con=DriverManager.getConnection(url,username,password);
		  ){
			
			System.out.print("Employee Id:");
			int employeeId=0;
			if(scanner.hasNextInt()) {
				employeeId=scanner.nextInt();
			}
			PreparedStatement empDeptInfoStmt=con.prepareStatement(queryEmployeeDeptInfo);
			empDeptInfoStmt.setInt(1, employeeId);
			ResultSet resultSetEmpDeptInfo=empDeptInfoStmt.executeQuery();
			while(resultSetEmpDeptInfo.next()) {
				employee.setFirstName(resultSetEmpDeptInfo.getString("first_name"));
				employee.setLastName(resultSetEmpDeptInfo.getString("last_name"));
				department.setDepartmentId(resultSetEmpDeptInfo.getInt("department_id"));
				department.setDepartmentName(resultSetEmpDeptInfo.getString("department_name"));
				locations.setLocationId(resultSetEmpDeptInfo.getInt("location_id"));
				locations.setStreetAddress(resultSetEmpDeptInfo.getString("street_address"));
				locations.setPostalCode(resultSetEmpDeptInfo.getString("postal_code"));
				locations.setCity(resultSetEmpDeptInfo.getString("city"));
				locations.setStateProvince(resultSetEmpDeptInfo.getString("state_province"));
				countries.setCountryId(resultSetEmpDeptInfo.getString("country_name"));
				countries.setCountryName(resultSetEmpDeptInfo.getString("country_name"));
				regions.setRegionId(resultSetEmpDeptInfo.getInt("region_id"));
				regions.setRegionName(resultSetEmpDeptInfo.getString("region_name"));
			
			}
			countries.setRegions(regions);
			locations.setCountries(countries);
			department.setLocations(locations);
			employee.setDepartments(department);
			
			PreparedStatement empJobInfoStmt=con.prepareStatement(queryEmployeeJobsInfo);
			empJobInfoStmt.setInt(1, employeeId);
			ResultSet resultSetJobs=empJobInfoStmt.executeQuery();
			
			while(resultSetJobs.next()) {
				jobs.setJobTitle(resultSetJobs.getString("job_title"));
				jobs.setJobId(resultSetJobs.getString("job_id"));
			}
			
			employee.setJobs(jobs);
		}catch(InputMismatchException | SQLException e) {
			
		}
		StringBuilder builder=new StringBuilder();
		builder.append("First Name:"+employee.getFirstName()+"\n");
		builder.append("Last Name:"+employee.getLastName()+"\n");
		builder.append("Job Title"+employee.getJobs().getJobTitle()+"\n");
		builder.append("Department Name:"+employee.getDepartments().getDepartmentName()+"\n");
		builder.append("City:"+employee.getDepartments().getLocations().getCity()+"\n");
		builder.append("Street Address:"+employee.getDepartments().getLocations().getStreetAddress()+"\n");
		builder.append("State Province:"+employee.getDepartments().getLocations().getStateProvince()+"\n");
		builder.append("Country Name:"+employee.getDepartments().getLocations().getCountries().getCountryName()+"\n");
		builder.append("Region:"+employee.getDepartments().getLocations().getCountries().getRegions().getRegionName()+"\n");
		System.out.println(builder);
	}

}
