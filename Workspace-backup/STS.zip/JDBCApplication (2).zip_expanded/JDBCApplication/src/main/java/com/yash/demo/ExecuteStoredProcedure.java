package com.yash.demo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.InputMismatchException;
import java.util.ResourceBundle;
import java.util.Scanner;

public class ExecuteStoredProcedure {

	public static void main(String[] args) {
		ResourceBundle resourceBundle=ResourceBundle.getBundle("db");
		String driver=resourceBundle.getString("driver");
		String url=resourceBundle.getString("url");
		String username=resourceBundle.getString("username");
		String password=resourceBundle.getString("password");
		
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		try(
				Scanner scanner=new Scanner(System.in);
				Connection con=DriverManager.getConnection(url,username,password);
				
			){
			
			System.out.print("Employee Id:");
			int employeeId=0;
			if(scanner.hasNextInt()) {
				employeeId=scanner.nextInt();
			}

			CallableStatement statement=con.prepareCall("{call getAnnualSalary(?,?)}");
			statement.setInt(1, employeeId);
			statement.registerOutParameter(2,Types.DOUBLE);
			statement.execute();
			double annualSalary=statement.getDouble(2);
			System.out.println("Annual Salary:"+annualSalary);
			
		}catch(InputMismatchException | SQLException e) {
			e.printStackTrace();
		}

	}
	}


