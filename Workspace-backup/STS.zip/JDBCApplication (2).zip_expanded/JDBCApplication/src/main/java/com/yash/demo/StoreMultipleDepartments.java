package com.yash.demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Properties;
import java.util.Scanner;

import com.yash.entities.Employees;

public class StoreMultipleDepartments {

	public static void main(String[] args) {

		File file=new File("D:\\javainductionio\\databaseconfig\\db.properties");
		Properties properties=new Properties();
		try(
			InputStream inStream=new FileInputStream(file);	
			){
			properties.load(inStream);
		}catch(IOException e) {
			e.printStackTrace();
		}
		try {
			Class.forName(properties.getProperty("driver"));
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
		}
		Employees employee=new Employees();
		int[] rows=null;
		Connection con=null;
		 int count=0;
		try
		 {
			Scanner scanner=new Scanner(System.in);
			con=DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("username"),properties.getProperty("password"));
			con.setAutoCommit(false);
			Statement statement=con.createStatement();
			for(int i=1;i<=3;i++) {
			System.out.println("=============Record"+i+"=============");
			 System.out.print("Department Id:");
			 int departmentId=0;
			 if(scanner.hasNextInt()) {
				departmentId= scanner.nextInt();
			 }
			 System.out.print("Department Name:");
			 String departmentName="";
			 if(scanner.hasNext()) {
				departmentName= scanner.next();
			 }
			 System.out.print("Manager Id:");
			 int managerId=0;
			 if(scanner.hasNextInt()) {
				managerId= scanner.nextInt();
			 }
			 System.out.print("Location Id:");
			 int locationId=0;
			 if(scanner.hasNextInt()) {
				 locationId= scanner.nextInt();
			 }
			 statement.addBatch("insert into departments values("+departmentId+","+"'"+departmentName+"'"+","+managerId+","+locationId+")");
			 System.out.println("==========================");
			}
			 rows=statement.executeBatch();
			 count=0;
			 
			 for(int row:rows) {
			  if(row>0)
				 count++;
			 }
			con.commit();
		}catch(InputMismatchException | SQLException e) {
          try {
			con.rollback();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		}finally {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			System.out.println("Number of records inserted:"+count);
		
	}

	}

}
