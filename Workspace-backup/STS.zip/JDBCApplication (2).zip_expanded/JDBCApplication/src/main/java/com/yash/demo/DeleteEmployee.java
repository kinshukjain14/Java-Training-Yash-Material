package com.yash.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.ResourceBundle;
import java.util.Scanner;

public class DeleteEmployee {

	public static void main(String[] args) {
		ResourceBundle resourceBundle=ResourceBundle.getBundle("db");
		String driver=resourceBundle.getString("driver");
		String url=resourceBundle.getString("url");
		String username=resourceBundle.getString("username");
		String password=resourceBundle.getString("password");
		
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		int rows=0;
		try(
				Scanner scanner=new Scanner(System.in);
				Connection con=DriverManager.getConnection(url,username,password);
				
			){
			
			System.out.print("Employee Id:");
			int employeeId=0;
			if(scanner.hasNextInt()) {
				employeeId=scanner.nextInt();
			}
			PreparedStatement statement=
					con.prepareStatement("delete from employees where employee_id=?");
			statement.setInt(1, employeeId);
			rows=statement.executeUpdate();

		}catch(InputMismatchException | SQLException e) {
			e.printStackTrace();
		}
		if(rows>0)
			System.out.println("Employee successfully deleted");
		else
			System.err.println("Error in deleting employee");
	}


	}


