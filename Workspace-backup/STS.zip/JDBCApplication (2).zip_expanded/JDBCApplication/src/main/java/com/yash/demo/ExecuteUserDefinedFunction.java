package com.yash.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;


public class ExecuteUserDefinedFunction {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		try(
				Scanner scanner=new Scanner(System.in);
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hrDB","root","root");
				
			){
			
			System.out.print("Employee Id:");
			int employeeId=0;
			if(scanner.hasNextInt()) {
				employeeId=scanner.nextInt();
			}
			PreparedStatement statement=con.prepareStatement("select taxOnSalary(salary) from employees where employee_id=?");
			statement.setInt(1, employeeId);
			ResultSet resultSet=statement.executeQuery();
			double tax=0.0;
			while(resultSet.next()) {
				tax=resultSet.getDouble(1);
			}
			System.out.println("Tax is:"+tax);
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	}


