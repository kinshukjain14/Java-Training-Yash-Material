package com.yash.service;

public class DepartmentsServiceImpl implements DepartmentsService {

	public String getDepartmentName() {
		return "Actual department Name";
	}

}
