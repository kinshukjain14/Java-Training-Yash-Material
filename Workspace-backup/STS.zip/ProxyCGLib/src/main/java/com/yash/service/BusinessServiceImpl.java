package com.yash.service;

public class BusinessServiceImpl implements BusinessService {
	public void businessMethod() {
		System.out.println("---actual business logic implementation--");
	}
}
