package com.yash.ui;

import com.yash.service.DepartmentsService;
import com.yash.service.DepartmentsServiceImpl;

import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.FixedValue;

public class CGLIBDemo {

	public static void main(String[] args) {
		//DepartmentsService departmentsService=null;
		//departmentsService.getDepartmentName();
		
		Enhancer enhancer=new Enhancer();
		enhancer.setSuperclass(DepartmentsService.class);
		/*
		 * class ProxyClass implements DepartmentsService{
		 * 
		 * @Override
		 * public String getDepartmentName(){
		 * mock->return null;
		 *spy->return new DepartmentsServiceImpl().getDepartmentName();
		 * }
		 * 
		 * }
		 */
		enhancer.setCallback(new FixedValue() {
			public Object loadObject() throws Exception {
				return "dummy department name";
			}
			
		});
		
		//to create proxied object
		
		DepartmentsService proxiedObject=(DepartmentsService)enhancer.create();
		String departmentName=proxiedObject.getDepartmentName();
		System.out.println("Department Name:"+departmentName);
		
		
		//real object
		
		DepartmentsService actualObject=new DepartmentsServiceImpl();
		String departmentNameActual=actualObject.getDepartmentName();
		System.out.println("Actual department name:"+departmentNameActual);
	}

}
