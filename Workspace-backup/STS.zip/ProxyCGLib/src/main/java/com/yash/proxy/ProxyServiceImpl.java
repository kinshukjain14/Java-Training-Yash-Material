package com.yash.proxy;

import com.yash.service.BusinessService;
import com.yash.service.BusinessServiceImpl;

public class ProxyServiceImpl implements BusinessService {

	public void businessMethod() {
//when actual implementation is not available
		//System.out.println("--dummy implementation--");
		
		//when actual implementation is available
	      BusinessService businessService=new BusinessServiceImpl();
	      businessService.businessMethod();

	}

}
