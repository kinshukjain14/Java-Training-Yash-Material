package com.yash.service;

public interface DepartmentsService {
	public String getDepartmentName();
}
