package com.yash.ui;

import com.yash.proxy.ProxyServiceImpl;
import com.yash.service.BusinessService;

public class UI {

	public static void main(String[] args) {

		BusinessService businessService=new ProxyServiceImpl();
		businessService.businessMethod();
	}

}
