package com.yash.service;

public interface BusinessService {
	public void businessMethod();
}
