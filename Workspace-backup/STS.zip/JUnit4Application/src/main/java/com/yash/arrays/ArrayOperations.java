package com.yash.arrays;

import java.util.Arrays;

public class ArrayOperations {

	public int[] sortArray(int[] testArray) {
		Arrays.sort(testArray);
		return testArray;
	}

}
