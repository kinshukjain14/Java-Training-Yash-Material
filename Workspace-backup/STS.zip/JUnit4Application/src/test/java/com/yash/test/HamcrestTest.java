package com.yash.test;

import static org.hamcrest.Matchers.*;

import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import com.yash.entity.Employee;

import static org.hamcrest.MatcherAssert.*;
public class HamcrestTest {

	@Test
	public void testStringIgnoreCase() {
		String expected="SABBIR";
		String actual="sabbir";
		assertThat(expected,equalToIgnoringCase(actual));
	}
	@Test
	public void testtoString() {
		
		Employee e=new Employee();
		e.setEmpId(101);
		e.setEmpName("sabbir");
		e.setEmpSalary(34000);
		e.setEmpDesignation("Trainer");
		String stringOfEmployee=e.toString();
		assertThat(e,hasToString(stringOfEmployee));
	}
	@Test
	public void testHasAProperty() {
		
		Employee e=new Employee();
		e.setEmpId(101);
		e.setEmpName("sabbir");
		e.setEmpSalary(34000);
		e.setEmpDesignation("Trainer");
		assertThat(e,hasProperty("empName"));
	}
	@Test
	public void testHasAPropertyValue() {
		
		Employee e=new Employee();
		e.setEmpId(101);
		e.setEmpName("sabbir");
		e.setEmpSalary(34000);
		e.setEmpDesignation("Trainer");
		assertThat(e,hasProperty("empName",equalTo("sabbir")));
	}

	@Test
	public void testCollectionisEmpty() {
		List<String> listString=new ArrayList<String>();
		assertThat(listString,empty());
		
	}
	@Test
	public void testCollectionisSize() {
		List<String> listString=new ArrayList<String>();
		listString.add("Pune");
		assertThat(listString,hasSize(1));
		
	}
	@Test
	public void testCollectionisInOrder() {
		List<String> listString=new ArrayList<String>();
		listString.add("Pune");
		listString.add("Mumbai");
		assertThat(listString,containsInAnyOrder("Mumbai","Pune"));
		
	}
	@Test
	public void testInteger() {
		int no=2;
		assertThat(no,greaterThan(0));
	}
}
