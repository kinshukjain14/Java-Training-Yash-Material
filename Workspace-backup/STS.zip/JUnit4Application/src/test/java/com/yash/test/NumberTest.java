package com.yash.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class NumberTest {
	
	private int number;

	@Before
	public void setUp() throws Exception {
		number=10;
	}

	@After
	public void tearDown() throws Exception {
		number=0;
	}

	@Test
	public void testNumber() {
    assertTrue("number should be greater than 5",number>5);
	}

}
