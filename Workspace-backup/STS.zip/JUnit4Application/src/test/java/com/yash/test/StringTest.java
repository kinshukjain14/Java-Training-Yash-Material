package com.yash.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class StringTest {
	
	private String str;
	@Before
	public void init() {
		str="sabbir";
	}
	@After
	public void destroy() {
		str=null;
	}

	@Test
	public void testStrLength() {
		int actual=str.length();
       assertTrue("length must be greater than 2",actual>2);
	}

}
