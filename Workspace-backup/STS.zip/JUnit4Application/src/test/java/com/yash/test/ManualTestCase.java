package com.yash.test;

import junit.framework.TestCase;

public class ManualTestCase extends TestCase {

	protected int no1;
	protected int no2;
	
	protected void setUp() {
		no1=3;
		no2=5;
	}
	protected void tearDown() {
		no1=0;
		no2=0;
	}
	public void testAdd_1() {
		int actual=no1+no2;
		assertTrue("Condition is met",actual==8);
	}
	public void testAdd_2() {
		int actual=no1+no2;
		assertTrue("Condition is not met",actual>no1);
	}
}
