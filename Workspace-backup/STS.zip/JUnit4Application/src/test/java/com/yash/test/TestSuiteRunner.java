package com.yash.test;

import junit.framework.TestResult;
import junit.framework.TestSuite;

public class TestSuiteRunner {

	public static void main(String[] args) {

		TestSuite testSuite=new TestSuite(NumberTest.class,StringTest.class);
		TestResult result=new TestResult();
		testSuite.run(result);
		
		System.out.println("Number of test cases:"+result.runCount());
	}

}
