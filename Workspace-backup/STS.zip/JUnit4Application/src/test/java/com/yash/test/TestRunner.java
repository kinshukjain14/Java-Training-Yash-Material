package com.yash.test;


import java.util.List;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

public class TestRunner {

	public static void main(String[] args) {

		Result result=JUnitCore.runClasses(ManualTestCase.class);
		List<Failure> failuresList=result.getFailures();
		for(Failure failure:failuresList) {
			System.out.println(failure.toString());
		}
		System.out.println("Test successful?:"+result.wasSuccessful());
		
	}

}
