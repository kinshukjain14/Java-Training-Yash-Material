package com.yash.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class JUnit4Annotations {

	@BeforeClass
	public static void setUpBeforeClass() {
		System.out.println("--executed once before class--");
	}
	@AfterClass
	public static void tearDownAfterClass() {
		System.out.println("--executed after class--");
	}
	@Before
	public void setUp() {
		System.out.println("--before test condition--");
	}
	@Test
	public void testNumber() {
     int expected=10;
     int actual=7;
     assertEquals(expected,actual,3);
	}
	@Ignore
	@Test
	public void testString() {
		String str="sabbir";
		assertTrue(str.length()>3);
	}
	@Test(timeout=1000)
	public void testTime() {
		while(true) {}
	}
	@Test
	public void testIsNull() {
		String str=null;
		assertNull(str);
	}
	@After
	public void tearDown() {
		System.out.println("--after every test condition ---");
	}
	

}
