package com.yash.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.yash.arrays.ArrayOperations;

public class TestArrayOperations {
	
	private ArrayOperations arrayOperations;
	
	@Before
	public void setUp() {
		arrayOperations=new ArrayOperations();
	}

	@After
	public void tearDown() {
		arrayOperations=null;
	}
	@Test
	public void testarraySort_PositiveFirstIndexPosition() {
     
		int[] testArray=new int[] {9,6,7,3,4,1};
		int[] expected= {1,3,4,6,7,9};
		
		int[] actual=arrayOperations.sortArray(testArray);
		assertSame(expected[1],actual[1]);
	}

}
