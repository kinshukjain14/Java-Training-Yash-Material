package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.yash.dao.JDBCAuthUserDAOImpl;
import com.yash.exception.DAOException;
import com.yash.helper.ConnectionManager;

class TestJDBCAuthUserDAOImplIntegration {
	
	@Spy
	private ConnectionManager manager;
	
	@InjectMocks
	private JDBCAuthUserDAOImpl jdbcAuthUserDAOImpl;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testauthUser_positive() {

		String userName="sabbirp";
		String password="sabbirp";
		
		try {
			boolean actual=jdbcAuthUserDAOImpl.authUser(userName, password);
			assertTrue(actual);
		} catch (DAOException e) {
          assertFalse(true);
		}
	}

	@Test
	void testauthUser_negative() {

		String userName="sabbirp";
		String password="sabbir123";
		
		try {
			boolean actual=jdbcAuthUserDAOImpl.authUser(userName, password);
			assertFalse(actual);
		} catch (DAOException e) {
          assertFalse(true);
		}
	}
}
