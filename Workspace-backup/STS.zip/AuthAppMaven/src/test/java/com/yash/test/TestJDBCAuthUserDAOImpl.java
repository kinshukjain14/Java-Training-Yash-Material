package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.yash.dao.JDBCAuthUserDAOImpl;
import com.yash.exception.DAOException;
import com.yash.helper.ConnectionManager;

class TestJDBCAuthUserDAOImpl {

	@Mock
	private ConnectionManager manager;
	
	@Mock
	private Connection connection;
	
	@Mock
	private PreparedStatement statement;
	
	@Mock
	private ResultSet resultSet;
	
	@InjectMocks
	private JDBCAuthUserDAOImpl jdbcAuthUserDAOImpl;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testauthUser_positive() {
		String userName="sabbirp";
		String password="sabbirp";
		try {
		when(manager.openConnection()).thenReturn(connection);
		when(connection.prepareStatement(anyString())).thenReturn(statement);
		when(statement.executeQuery()).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
       boolean actual=jdbcAuthUserDAOImpl.authUser(userName, password);
       assertTrue(actual);
		}catch(ClassNotFoundException | SQLException | DAOException e) {
			assertFalse(true);
		}
	}
	
	@Test
	void testauthUser_negative() {
		String userName="sabbirp";
		String password="sabbirp1";
		try {
		when(manager.openConnection()).thenReturn(connection);
		when(connection.prepareStatement(anyString())).thenReturn(statement);
		when(statement.executeQuery()).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(false);
       boolean actual=jdbcAuthUserDAOImpl.authUser(userName, password);
       assertTrue(actual!=true);
		}catch(ClassNotFoundException | SQLException | DAOException e) {
			assertFalse(true);
		}
	}
	@Test
	void testauthUser_exception() {
		String userName="sabbirp";
		String password="sabbirp";
		try {
		when(manager.openConnection()).thenReturn(connection);
		when(connection.prepareStatement(anyString())).thenReturn(statement);
		when(statement.executeQuery()).thenThrow(SQLException.class);
       jdbcAuthUserDAOImpl.authUser(userName, password);
		}catch(ClassNotFoundException | SQLException | DAOException e) {
			assertTrue(true);
		}
	}
}
