package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.yash.helper.ConnectionManager;
import com.yash.helper.DataSource;

class TestConnectionManager {
	
	@InjectMocks
	private ConnectionManager manager;
	
	@Mock
	private DataSource dataSource;

	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testOpenConnection_Positive() {

	when(dataSource.getDriver()).thenAnswer(
			new Answer<String>() {
				@Override
				public String answer(InvocationOnMock invocation) throws Throwable {
					return "com.mysql.jdbc.Driver";
				}
			}	
		);
	when(dataSource.getUrl()).thenAnswer(
			new Answer<String>() {
				@Override
				public String answer(InvocationOnMock invocation) throws Throwable {
					return "jdbc:mysql://localhost:3306/hr_schema";
				}
			}	
		);
	
	when(dataSource.getUserName()).thenAnswer(
			new Answer<String>() {
				@Override
				public String answer(InvocationOnMock invocation) throws Throwable {
					return "root";
				}
			}	
		);
	when(dataSource.getPassword()).thenAnswer(
			new Answer<String>() {
				@Override
				public String answer(InvocationOnMock invocation) throws Throwable {
					return "root";
				}
			}	
		);
	try {
		Connection connection=manager.openConnection();
		assertTrue(connection!=null);
	} catch (ClassNotFoundException | SQLException e) {
		assertTrue(false);
	}
	
	}
	
	@Test
	void testOpenConnection_negative() {
	when(dataSource.getDriver()).thenAnswer(
			new Answer<String>() {
				@Override
				public String answer(InvocationOnMock invocation) throws Throwable {
					return "com.mysql1.Driver";
				}
			}	
		);
	when(dataSource.getUrl()).thenAnswer(
			new Answer<String>() {
				@Override
				public String answer(InvocationOnMock invocation) throws Throwable {
					return "jdbc:mysql://localhost:3306/hr_schema";
				}
			}	
		);
	
	when(dataSource.getUserName()).thenAnswer(
			new Answer<String>() {
				@Override
				public String answer(InvocationOnMock invocation) throws Throwable {
					return "root";
				}
			}	
		);
	when(dataSource.getPassword()).thenAnswer(
			new Answer<String>() {
				@Override
				public String answer(InvocationOnMock invocation) throws Throwable {
					return "root";
				}
			}	
		);
	try {
		manager.openConnection();
		assertTrue(false);
	} catch (ClassNotFoundException | SQLException e) {
		assertTrue(true);
	}
	}

}
