package com.yash.factory;

import com.yash.dao.AuthUserDAO;
import com.yash.dao.JDBCAuthUserDAOImpl;

public class FactoryAuthUserDAO {
	public static AuthUserDAO getInstance() {
		AuthUserDAO authUserDAO=new JDBCAuthUserDAOImpl();
		return authUserDAO;
	}
}
