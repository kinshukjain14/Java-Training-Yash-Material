package com.yash.annotation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
@Repeatable(Hints.class)
@Retention(RUNTIME)
@Target(TYPE)
public @interface Hint {

	String value();
}
