package com.yash.annotation;

public class AnnotationProcessing {

	public static void main(String[] args) 
	{
		Hint[] hints=MyClass.class.getAnnotationsByType(Hint.class);
		for(Hint hint:hints) {
			System.out.println(hint.value());
		}
	}

}
