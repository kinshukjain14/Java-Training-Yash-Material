package com.yash.annotation;

@Hint(value="Hint for method x1")
@Hint(value="Hint for method x2")
public class MyClass {
	public void x1() {}
	public void x2() {}
	public void x3() {}
}
