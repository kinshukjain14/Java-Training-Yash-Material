package com.yash.methodreference;

public interface EmployeeFactory<E extends Employee> {
	
	public Employee create(int empId,String empName,double empSalary,String empDesignation);

}
