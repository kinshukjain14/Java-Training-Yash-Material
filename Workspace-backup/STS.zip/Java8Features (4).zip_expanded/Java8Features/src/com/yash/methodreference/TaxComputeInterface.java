package com.yash.methodreference;

public interface TaxComputeInterface<T,R> {
	public  R compute(T amount);
}
