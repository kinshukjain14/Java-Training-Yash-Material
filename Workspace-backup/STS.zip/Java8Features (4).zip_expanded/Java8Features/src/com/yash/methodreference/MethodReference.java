package com.yash.methodreference;

public class MethodReference {

	public static void main(String[] args) {

		Employee e=new Employee();
		e.setEmpId(1001);
		e.setEmpName("sabbir");
		e.setEmpSalary(34000);
		e.setEmpDesignation("Trainer");
		
		Converter<String,String> converter=e::empNameToUpperCase;
		System.out.println("Emp Name:"+converter.convert(e.getEmpName()));
		
		TaxComputeInterface<Double,Double> taxComputeInterface=Employee::computeTax;
		System.out.println("Tax is:"+taxComputeInterface.compute(e.getEmpSalary()));
		
		EmployeeFactory<Employee> employeeFactory=Employee::new;
		Employee newEmployee=employeeFactory.create(1001, "Mohit", 23000, "Trainer");
		System.out.println(newEmployee);
		
		
	}

}
