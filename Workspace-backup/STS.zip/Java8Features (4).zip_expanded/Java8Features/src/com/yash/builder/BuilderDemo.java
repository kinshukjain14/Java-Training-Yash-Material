package com.yash.builder;

import java.util.List;

public class BuilderDemo {

	public static void main(String[] args) {

		List<Interns> internList=Interns.createInternsList();
		internList.forEach(System.out::println);
		
	}

}
