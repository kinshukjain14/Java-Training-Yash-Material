package com.yash.lambdainternal;
@FunctionalInterface
public interface ComputeInterface {
	int compute(int...n);
}
