package com.yash.lambdainternal;

import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaConversionException;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;

public class LambdaInternalDemo {

	
	private static int computeVal(int...n) {
		int sum=0;
		for(int i:n) {
			sum+=i;
			
		}
		return sum;
	}
	
	public static void main(String[] args) throws Throwable {

		ComputeInterface lambdaExpression=(n)->{
			int sum=0;
			for(int i:n) {
				sum+=i;
			}
			return sum;
		};
		
		System.out.println("Implicit implementation of compute:"+lambdaExpression.compute(10,20,30));
		
		//Explict invocation of static method by binding it will object of function
		
		MethodHandles.Lookup caller=MethodHandles.lookup();
		MethodType methodType=MethodType.methodType(int.class,int[].class);
		
		MethodType invokedType=MethodType.methodType(ComputeInterface.class);
		
		CallSite site=
				LambdaMetafactory.metafactory
				(caller
						, "compute"
						, invokedType, methodType
						, caller.findStatic(LambdaInternalDemo.class, "computeVal", MethodType.methodType(int.class,int[].class))
						, methodType);
		
		MethodHandle factory=site.getTarget();
		ComputeInterface computeInterface=(ComputeInterface)factory.invoke();
		System.out.println("Dynamic invocation of static method on invoking method on reference of function object:"
		+computeInterface.compute(10,20,30));
	}

}
