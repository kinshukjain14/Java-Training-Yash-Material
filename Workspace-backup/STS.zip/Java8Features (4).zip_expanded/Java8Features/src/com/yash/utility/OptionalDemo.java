package com.yash.utility;

import java.util.Optional;

public class OptionalDemo {

	public int sum(Integer o1,Integer o2) {	
		return o1+o2;
	}
	public int sum(Optional<Integer> o1,Optional<Integer> o2) {	
		return o1.orElse(0)+o2.orElse(0);
	}
	public static void main(String[] args) {

		Optional<Integer> o1=Optional.ofNullable(null);
		Optional<Integer> o2=Optional.of(10);
		
		OptionalDemo o=new OptionalDemo();
		System.out.println("Sum:"+o.sum(o1, o2));
		
		Optional<String> optionalString=Optional.of("Sabbir");
		if(optionalString.isPresent()) {
			System.out.println("--contains a value--");
		}
		Optional<String> optionalOfNull=Optional.ofNullable(null);
		if(optionalOfNull.isPresent()) {
			System.out.println("--contains a valid value--");
		}
	}

}
