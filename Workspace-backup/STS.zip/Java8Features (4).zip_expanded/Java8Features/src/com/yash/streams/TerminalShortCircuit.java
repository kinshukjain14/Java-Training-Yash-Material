package com.yash.streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class TerminalShortCircuit {

	public static void main(String[] args) {

		List<String> names=Arrays.asList("sabbir","rohit","rakesh","sabbir","chirag","purohit");
		//List<String> names=new ArrayList<>();
		Optional<String> optionalFirst=names
		.stream()
		.findFirst();
		if(optionalFirst.isPresent()) {
		System.out.println("First:"+optionalFirst.get());
		}
		System.out.println(optionalFirst.orElse("No First Name found"));
		
		Optional<String> optionalNameStartsWithS=names
		.stream()
		.findFirst()
		.filter((name)->name.startsWith("m"));
		
		System.out.println(optionalNameStartsWithS.orElse("No name starting with given character"));
		
		
		boolean doesStartWithS=names
		.stream()
		.allMatch((name)->name.startsWith("s"));
		
		System.out.println("All names start with S:"+doesStartWithS);
		
		boolean anyStartWithS=names
				.stream()
				.anyMatch((name)->name.startsWith("s"));
				
				System.out.println("Any name start with S:"+anyStartWithS);
				
				System.out.println("**********without distinct****************");

				names.stream().filter((name)->name.startsWith("s")).forEach(System.out::println);
				
				System.out.println("**********distinct****************");
				names.stream().filter((name)->name.startsWith("s")).distinct().forEach(System.out::println);
	}

}
