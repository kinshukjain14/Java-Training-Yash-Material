package com.yash.streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.yash.builder.Interns;

public class MapDemo {

	public static void main(String[] args) {

		List<String> namesList=Arrays.asList("sabbir","amit","sumeet","rohit","pankaj");
		
		List<String> namesInUpperCaseList=namesList
		.stream()
		.map(String::toUpperCase)
		.collect(Collectors.toList());
		System.out.println("*******original list**********");
		namesList.forEach(System.out::println);
		System.out.println("*******upper case list**********");
		namesInUpperCaseList.forEach(System.out::println);
		

		List<Interns> internList=Interns.createInternsList();
		System.out.println("*******upper case firstname list**********");

		List<String> internsFirstNameUpperCaseList=internList
		.stream()
		.map(Interns::getInternFirstName)
		.map(String::toUpperCase)
		.collect(Collectors.toList());
		
		internsFirstNameUpperCaseList.forEach(System.out::println);
		System.out.println("*****************");

		String stringFormat=internList
		.stream()
		.map(Interns::toString)
		.collect(Collectors.joining("**"));
		
		System.out.println("String Format:"+stringFormat);
		
		
		
	}

}
