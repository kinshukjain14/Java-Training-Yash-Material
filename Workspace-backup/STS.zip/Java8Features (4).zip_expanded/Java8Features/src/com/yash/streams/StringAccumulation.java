package com.yash.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class StringAccumulation {

	public static void main(String[] args) {

		List<String> words=new ArrayList<>();
		words.add("Java");
		words.add("is");
		words.add("object");
		words.add("oriented");
		words.add("programming");
		words.add("language");
		
		Optional<String> sentence=words
		.stream()
		.reduce((word1,word2)->word1.concat(" "+word2));
		System.out.println(sentence.get());
		
	}

}
