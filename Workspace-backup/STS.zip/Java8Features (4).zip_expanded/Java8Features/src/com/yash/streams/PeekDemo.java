package com.yash.streams;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class PeekDemo {

	public static void main(String[] args) {

		List<String> names=Arrays.asList("rohit","sumeet","sachin","chirag");
	
		names
		.stream()
		.map(String::toUpperCase)
		.peek((name)->System.out.println(name))
		.collect(Collectors.toList());
	}

}
