package com.yash.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.Spliterator;
import java.util.function.Consumer;
import java.util.stream.Stream;

public class StreamsCreationDemo {

	public static void main(String[] args) {

		Stream<Object> streamByBuilder=Stream
				.builder()
				.add(10)
				.add(20)
				.add(30)
				.add(40)
				.build();

	
		Stream<Integer> usingOf=Stream.of(10,20,30);
		long count=usingOf
				.filter((n)->n>20)
				.count();
		System.out.println("Count:"+count);
		
		List<Integer> integerList=new ArrayList<>();
		integerList.add(10);
		integerList.add(20);
		integerList.add(30);
		integerList.add(40);
		
		Stream<Integer> usingCollection=integerList.stream();
		
		Spliterator<Integer> splitIterator=usingCollection.spliterator();
		
		Consumer<Integer> consumer=(source)->{
			System.out.println(source);
		};
		
		splitIterator.forEachRemaining(consumer);;
		
		
	}

}
