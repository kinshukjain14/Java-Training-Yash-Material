package com.yash.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import com.yash.builder.Interns;

public class FilterDemo {

	public static void main(String[] args) {

		List<Integer> integerList=new ArrayList<>();
		integerList.add(3);
		integerList.add(9);
		integerList.add(7);
		integerList.add(2);
		integerList.add(1);
		integerList.add(6);
		int countVar=0;
		for(Integer o:integerList) {
			if(o>5) {
				countVar++;
			}
		}
		System.out.println("Count using java 5:"+countVar);
		long count=integerList
		.stream()
		.filter((n)->n>5)
		.count();
		System.out.println("Count:"+count);
		System.out.println("*******************");
		
		integerList
		.stream()
		.filter((n)->n%2==0)
		.forEach((n)->{
			//put n in a file
			//put n in a logfile
			System.out.println(n);
		});
		
		System.out.println("*******************");

		integerList
		.stream()
		.filter((n)->n%2==0)
		.forEach(System.out::println);
		
		List<String> names=new ArrayList<>();
		names.add("sumeet");
		names.add("sabbir");
		names.add("sachin");
		names.add("rohit");
		names.add("rajesh");
		names.add("sai");

		System.out.println("*******************");

		names
		.stream()
		.filter((name)->name.startsWith("s") && name.length()>5)
		.forEach(System.out::println);
		
		System.out.println("*******************");

		Predicate<String> startsWithS=name->name.startsWith("s");
		Predicate<String> lengthGreaterThan5=name->name.length()>5;
		
		names
		.stream()
		.filter(startsWithS.and(lengthGreaterThan5))
		.forEach(System.out::println);
		
		
		/*
		names
		.stream()
		.filter((name)->name.startsWith("s").and((name)->name.length()>5))
		.forEach(System.out::println);
*/
		
		System.out.println("*******************");

		List<Interns> internList=Interns.createInternsList();
		internList
		.stream()
		.filter((intern)->intern.getInternAge()>25)
		.forEach(System.out::println);
		System.out.println("*******************");

		
		internList
		.stream()
		.filter((intern)->intern.getId()>1001)
		.filter((intern)->intern.getInternAge()>25)
		.forEach(System.out::println);
	}

}
