package com.yash.streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.yash.builder.Interns;

public class CollectDemo {

	public static void main(String[] args) {

		List<Integer> integerList=new ArrayList<>();
		integerList.add(3);
		integerList.add(9);
		integerList.add(7);
		integerList.add(2);
		integerList.add(1);
		integerList.add(6);
	
		List<Integer> GreaterThan5List=integerList
		.stream()
		.filter((n)->n>5)
		.collect(Collectors.toList());
		
		GreaterThan5List.forEach(System.out::println);
		System.out.println("*******************");
		
		System.out.println("*******************");

		List<Integer> EvenNumbers=integerList
		.stream()
		.filter((n)->n%2==0)
		.collect(Collectors.toList());
		
		EvenNumbers.forEach(System.out::println);

		
		List<String> names=new ArrayList<>();
		names.add("sumeet");
		names.add("sabbir");
		names.add("sachin");
		names.add("rohit");
		names.add("rajesh");
		names.add("sai");

		System.out.println("*******************");

		List<String> startsWithSLengthGreaterThan5List=names
		.stream()
		.filter((name)->name.startsWith("s") && name.length()>5)
		.collect(Collectors.toList());
		
		startsWithSLengthGreaterThan5List.forEach(System.out::println);
		System.out.println("*******************");

		Predicate<String> startsWithS=name->name.startsWith("s");
		Predicate<String> lengthGreaterThan5=name->name.length()>5;
		
		List<String> startsWithSLengthGreaterThan5PredicateChainingList=
		names
		.stream()
		.filter(startsWithS.and(lengthGreaterThan5))
        .collect(Collectors.toList());
		
		startsWithSLengthGreaterThan5PredicateChainingList.forEach(System.out::println);
		
		/*
		names
		.stream()
		.filter((name)->name.startsWith("s").and((name)->name.length()>5))
		.forEach(System.out::println);
*/
		
		System.out.println("*******************");

		List<Interns> internList=Interns.createInternsList();
		
		List<Interns> internsAgeGreaterThan25List=internList
		.stream()
		.filter((intern)->intern.getInternAge()>25)
		.collect(Collectors.toList());
		
		internsAgeGreaterThan25List.forEach(System.out::println);
		System.out.println("*******************");

		
		List<Interns> internsIdGreaterThan1001AgeGreaterthan25=internList
		.stream()
		.filter((intern)->intern.getId()>1001)
		.filter((intern)->intern.getInternAge()>25)
		.collect(Collectors.toList());
		
		internsIdGreaterThan1001AgeGreaterthan25.forEach(System.out::println);
		System.out.println("*******************");

		List<Integer> numbers=Arrays.asList(10,67,80,90,101);
		
		int sumOfNumbers=numbers
		.stream()
		.collect(Collectors.summingInt((n)->n));
		
		System.out.println("SumOfNumbers:"+sumOfNumbers);
		
		System.out.println("*******************");

		DoubleSummaryStatistics statistics=numbers
		.stream()
		.collect(Collectors.summarizingDouble((n)->n));
		
		System.out.println(statistics);
		
		
		
		
	}
	}


