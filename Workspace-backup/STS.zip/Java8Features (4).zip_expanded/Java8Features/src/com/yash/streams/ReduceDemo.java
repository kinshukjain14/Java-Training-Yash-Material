package com.yash.streams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class ReduceDemo {

	public static void main(String[] args) {

		List<Integer> numbers=Arrays.asList(8,7,6,2,11,23);
		Optional<Integer> optionalOfSum=numbers
		.stream()
		.reduce((subtotal,n)->subtotal+n);
		
		System.out.println("Sum:"+optionalOfSum.get());
		
		List<Integer> hugeDataSet=new ArrayList<>();
		for(int i=1;i<=100000;i++) {
			hugeDataSet.add(i);
		}
		
		long beforeSequential=System.currentTimeMillis();
		hugeDataSet
		.stream()
		.reduce((subtotal,n)->subtotal+n);
		long afterSequential=System.currentTimeMillis();
		
		System.out.println("Time Sequential:"+(afterSequential-beforeSequential));
		
		long beforeParallel=System.currentTimeMillis();
		hugeDataSet
		.parallelStream()
		.reduce((subtotal,n)->subtotal+n);
		long afterParallel=System.currentTimeMillis();
		
		System.out.println("Time Parallel:"+(afterParallel-beforeParallel));

		
		
	}

}
