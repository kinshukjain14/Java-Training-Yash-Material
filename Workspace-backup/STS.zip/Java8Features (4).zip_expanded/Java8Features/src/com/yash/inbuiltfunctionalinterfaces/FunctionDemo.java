package com.yash.inbuiltfunctionalinterfaces;

import java.util.function.Function;

public class FunctionDemo {

	public static void main(String[] args) {

		Function<String,Integer> function1=(s)->{
			return Integer.parseInt(s);
		};
		
		int i=function1.apply("20");
		System.out.println(++i);
		
		Function<String,Integer> function2=Integer::valueOf;
		int j=function2.apply("20");
		System.out.println(++j);
		
	}

}
