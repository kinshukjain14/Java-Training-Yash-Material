package com.yash.inbuiltfunctionalinterfaces;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

import com.yash.methodreference.Employee;

public class ConsumerDemo<T> {

	public static void print(String s) {
		System.out.println(s);
	}
	
	public static void printAccordingToConsumer(Consumer<String>consumer,String object) {
		consumer.accept(object);
	}
	
	Consumer<String> stringConsumer1=(s)->{
		System.out.println(s);
	};
	
	Consumer<String> printStar=(s)->{
		System.out.println("******************");
		System.out.println(s);
	};
	Consumer<String> printPlus=(s)->{
		System.out.println("++++++++++++++++++");
		System.out.println(s);
	};
	
	
	Consumer<T> generalized=(arg)->{
		System.out.println("***********Generalized consumer***********"+arg);
	};
	Consumer<Employee> displayEmployee=(e)->{
		StringBuilder builder=new StringBuilder();
		builder.append("Employee Id:"+"\t"+e.getEmpId()+"\n");
		builder.append("Employee Name:"+"\t"+e.getEmpName()+"\n");
		builder.append("Employee Salary:"+"\t"+e.getEmpSalary()+"\n");
		builder.append("Employee Designation:"+"\t"+e.getEmpDesignation()+"\n");
		System.out.println(builder.toString());
	};
	public static void main(String[] args) {

		String ob1="sabbir";
		String ob2="amit";
		String ob3="chirag";
		String ob4="ganesh";
		
		System.out.println(ob1);
		System.out.println(ob2);
		System.out.println(ob3);
		System.out.println(ob4);
		
		print(ob1);
		print(ob2);
		print(ob3);
		
	
		ConsumerDemo o=new ConsumerDemo();
		o.stringConsumer1.accept(ob1);
		o.stringConsumer1.accept(ob2);
		o.stringConsumer1.accept(ob3);
		
		printAccordingToConsumer(o.printStar,"Yash Technologies");
		printAccordingToConsumer(o.printPlus,"Yash Technologies");
		
		printAccordingToConsumer(o.printStar,"Oracle");

		Employee e1=new Employee();
		e1.setEmpId(1001);
		e1.setEmpName("sabbir");
		e1.setEmpSalary(34000);
		e1.setEmpDesignation("Trainer");
		
		
		Employee e2=new Employee();
		e2.setEmpId(1002);
		e2.setEmpName("amit");
		e2.setEmpSalary(84000);
		e2.setEmpDesignation("Developer");
		
		o.displayEmployee.accept(e1);
		o.displayEmployee.accept(e2);
		
		ConsumerDemo<String> stringConsumerDemo=new ConsumerDemo<>();
		stringConsumerDemo.generalized.accept("generalized 1");
		
		
		ConsumerDemo<Integer> integerConsumerDemo=new ConsumerDemo<>();
		integerConsumerDemo.generalized.accept(100);
		
		BiConsumer<String,String> biConsumer=(s1,s2)->{
			System.out.println(s1.concat(s2).toUpperCase());
		};
		biConsumer.accept("Hello", "World");
	
		
	}

}
