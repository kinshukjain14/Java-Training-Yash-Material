package com.yash.inbuiltfunctionalinterfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

public class PredicateDemo {
	
	public static void print(Predicate<Integer> predicate,List<Integer> list) {
		for(Integer o:list) {
			boolean result=predicate.test(o);
			if(result) {
				System.out.println(o);
			}
		}
	}

	public static void main(String[] args) {

		Predicate<String> predicateString1=(str)->str.length()>6;
		
		boolean result=predicateString1.test("shabbir");
		System.out.println("Result:"+result);
		
		Predicate<String> predicateString2=(str)->str.startsWith("S") || str.endsWith("r");
		boolean resultPredicateString2=predicateString2.test("Shabbir");
		
		System.out.println("Result:"+resultPredicateString2);
		
		Predicate<String> predicateString3=String::isEmpty;
		System.out.println("Result:"+predicateString3.test(""));
		
		Predicate<Object> predicateObject=Objects::isNull;
		Boolean b=new Boolean(false);
		System.out.println("is Null?:"+predicateObject.test(b));
		
		List<Integer> listInteger=new ArrayList<>();
		listInteger.add(3);
		listInteger.add(5);
		listInteger.add(7);
		listInteger.add(9);
		listInteger.add(11);
		listInteger.add(14);
		listInteger.add(18);
		
		Predicate<Integer> condition1=(e)->e%2==0;
		Predicate<Integer> condition2=(e)->e>=5;
		
		print(condition1,listInteger);
		System.out.println("***************");
		print(condition2,listInteger);
		

		
		
		
	}

}
