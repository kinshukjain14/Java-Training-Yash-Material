package com.yash.inbuiltfunctionalinterfaces;

public class UserOfConsumerSupplier {

	public static void main(String[] args) {

		ConsumerDemo<String> o=new ConsumerDemo<String>();
		o.stringConsumer1.accept("data");
		
		SupplierDemo sd=new SupplierDemo();
		System.out.println(sd.supplierOfString.get());
		
	}

}
