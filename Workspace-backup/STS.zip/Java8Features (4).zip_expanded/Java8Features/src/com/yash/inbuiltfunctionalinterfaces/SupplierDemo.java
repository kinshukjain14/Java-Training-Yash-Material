package com.yash.inbuiltfunctionalinterfaces;

import java.util.function.Supplier;

import com.yash.methodreference.Employee;

public class SupplierDemo<T> {

	Supplier<String> supplierOfString=()->"Yash Technologies";
	
	Supplier<Integer> supplierOfSum=()->{
		int no1=10;
		int no2=20;
		return no1+no2;
	};
	
	Supplier<Employee> supplierOfEmployee=Employee::new;
	
	Supplier<Employee> supplierOfEmployee1=()->{
		return new Employee();
	};
	
	
	Supplier<Employee> supplierOfEmployee2=()->{
	    Employee e=new Employee();
	    e.setEmpId(1001);
	    e.setEmpName("chirag");
	    e.setEmpSalary(34000);
	    e.setEmpDesignation("Programmer");
	    return e;
	};
	
	
	public static void main(String[] args) {

		SupplierDemo o=new SupplierDemo();
		
		System.out.println("Data from supplier:"+o.supplierOfString.get());
		
		System.out.println(o.supplierOfSum.get());
		
		System.out.println(o.supplierOfEmployee.get());
		
		System.out.println(o.supplierOfEmployee1.get());
		
		System.out.println(o.supplierOfEmployee2.get());
		
		
	}

}
