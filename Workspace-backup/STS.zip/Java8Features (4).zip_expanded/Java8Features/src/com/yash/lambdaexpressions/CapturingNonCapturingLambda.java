package com.yash.lambdaexpressions;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.StringTokenizer;

public class CapturingNonCapturingLambda {

    
    public static void main(String args[]) {
        Scanner scanner=new Scanner("This is capturing lambda");
    	StringOperation strOperationCapturingLambda=(delimeter)->{
    		
    		List<String> list=new ArrayList<>();
    		scanner.useDelimiter(delimeter);
    		while(scanner.hasNext()) {
        		list.add(scanner.next());

    		}
    		scanner.close();
    		return list;
    	};
    	
    	List<String> output1=strOperationCapturingLambda.search(" ");
        System.out.println(output1);
        
         StringOperation strOperationNonCapturingLambda=(delimeter)->{
    		Scanner internalScanner=new Scanner("This,is,non,capturing,lambda");
    		List<String> list=new ArrayList<>();
    		internalScanner.useDelimiter(delimeter);
    		while(internalScanner.hasNext()) {
        		list.add(internalScanner.next());

    		}
    		internalScanner.close();
    		return list;
    	};
        List<String> output2=strOperationNonCapturingLambda.search(",");
        System.out.println(output2);
    }
}
