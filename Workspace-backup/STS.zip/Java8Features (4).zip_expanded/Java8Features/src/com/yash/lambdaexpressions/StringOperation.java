package com.yash.lambdaexpressions;

import java.util.List;
@FunctionalInterface
public interface StringOperation {
	
	public List<String> search(String delimeter);

}
