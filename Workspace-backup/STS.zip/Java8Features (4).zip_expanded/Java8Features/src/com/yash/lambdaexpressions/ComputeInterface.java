package com.yash.lambdaexpressions;
@FunctionalInterface
public interface ComputeInterface {
	public int compute(int no1,int no2);

}
