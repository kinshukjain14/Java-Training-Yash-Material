package com.yash.lambdaexpressions;

public class LambdaExpression implements ComputeInterface {


	@Override
	public int compute(int no1, int no2) {
		return no1+no2;
	}
	
	class InnerComputeInterface1 implements ComputeInterface{

		@Override
		public int compute(int no1, int no2) {
			return no1+no2;
		}
		
	
		
	}


	
	public static void main(String[] args) {

		LambdaExpression impl1=new LambdaExpression();
		int impl1Output=impl1.compute(10, 20);
		
		LambdaExpression.InnerComputeInterface1 impl2=impl1.new InnerComputeInterface1();
		impl2.compute(90, 70);
		
		ComputeInterface impl3=new ComputeInterface() {
			@Override
			public int compute(int no1, int no2) {
				return no1*no2;
			}
		};
		impl3.compute(67,90);
		
		ComputeInterface lambdaImpl1=(a,b)->a+b;
		lambdaImpl1.compute(11, 14);
		
		ComputeInterface lambdaImpl2=(a,b)->a*b;
		lambdaImpl2.compute(90, 80);
		
		ComputeInterface lambdaImpl3=(a,b)->{
			a=a*a;
			return a+b;
		};
		lambdaImpl3.compute(11, 14);
	}
	
	

	
}
