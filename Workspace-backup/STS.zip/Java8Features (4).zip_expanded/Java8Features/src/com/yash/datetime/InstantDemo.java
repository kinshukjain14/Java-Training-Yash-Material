package com.yash.datetime;

import java.time.Clock;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.util.Date;

public class InstantDemo {

	public static void main(String[] args) {

		Clock clock=Clock.systemDefaultZone();
		System.out.println(clock);
		
		Instant instant=clock.instant();
		System.out.println(instant);
		
		ZonedDateTime time=instant.atZone(clock.getZone());
		System.out.println(time);
		
		Date date=Date.from(instant);
		System.out.println(date);
	}

}
