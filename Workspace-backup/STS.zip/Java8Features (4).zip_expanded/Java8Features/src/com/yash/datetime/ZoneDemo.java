package com.yash.datetime;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Set;

public class ZoneDemo {

	public static void main(String[] args) {

		Set<String> availableZones=ZoneId.getAvailableZoneIds();
		for(String zoneId:availableZones) {
			System.out.println(zoneId);
		}
		
		ZoneId europeParis=ZoneId.of("Europe/Paris");
		
		LocalDateTime localDateTime=LocalDateTime.now();
		
		ZonedDateTime zonedDateTime=ZonedDateTime.of(localDateTime, europeParis);
		
		System.out.println(zonedDateTime);
	}

}
