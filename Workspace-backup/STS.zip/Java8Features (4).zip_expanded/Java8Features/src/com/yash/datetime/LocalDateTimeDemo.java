package com.yash.datetime;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class LocalDateTimeDemo {

	public static void main(String[] args) {

		LocalDateTime currentDateTime=LocalDateTime.now();
		System.out.println("Current Date Time:"+currentDateTime);
		
		
		LocalDate localDate=LocalDate.now();
		System.out.println("Local Date:"+localDate);
		
		LocalDate after4DaysDate=localDate.plusDays(4);
		System.out.println("After four days:"+after4DaysDate);
		
		LocalDate previousMonthSameDay=localDate.minus(1,ChronoUnit.MONTHS);
		System.out.println("Previous Month Same Day:"+previousMonthSameDay);
		
		DayOfWeek dayofWeek=LocalDate.parse("2016-06-12").getDayOfWeek();
		System.out.println("Day of Week on 2016-06-12"+dayofWeek);
		
		LocalDate d14Oct2015=LocalDate.of(2015, 10, 14);
		
		
		LocalTime localTime=LocalTime.now();
		System.out.println("Current time:"+localTime);
		
		System.out.println("Hour:"+localTime.getHour());
		
		LocalTime after30Minutes=localTime.plus(30,ChronoUnit.MINUTES);
		System.out.println("After 30 minutes:"+after30Minutes);
		
		LocalTime before1Hour=localTime.minus(1,ChronoUnit.HOURS);
		System.out.println("Before 1 hour:"+before1Hour);
		
		
		LocalDate August152019=LocalDate.of(2019, Month.AUGUST, 15);
		
		Period periodBetweenTwoDates=Period.between(LocalDate.now(), August152019);
		System.out.println("Period between two dates:"+periodBetweenTwoDates);

		LocalTime time1130=LocalTime.of(11, 30);
		Duration duration=Duration.between(LocalTime.now(), time1130);
		System.out.println("Duration between current time and 11:30"+duration);
		

	
	}
	
	

}
