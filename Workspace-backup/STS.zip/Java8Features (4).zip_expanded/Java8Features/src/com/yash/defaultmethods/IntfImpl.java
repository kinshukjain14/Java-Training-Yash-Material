package com.yash.defaultmethods;

public class IntfImpl implements Intf {
	
	@Override
	public void x() {
		System.out.println("--IntfImpl implementation--");
		Intf.super.x();
		
	}

	@Override
	public void y() {

		System.out.println("--y--");
	}

}
