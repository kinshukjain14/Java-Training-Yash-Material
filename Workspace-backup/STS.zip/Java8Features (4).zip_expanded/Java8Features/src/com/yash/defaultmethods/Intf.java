package com.yash.defaultmethods;
@FunctionalInterface
public interface Intf {
	
	public abstract void y();
	///public abstract void m();

	
	public default void x() {
	  System.out.println("--Intf default implementation--");	
	}
	
	public default void z() {
		  System.out.println("--Intf default implementation--");	
		}
	
	public static void main(String args[]) {
		System.out.println("--executing interface--");
	}

}
