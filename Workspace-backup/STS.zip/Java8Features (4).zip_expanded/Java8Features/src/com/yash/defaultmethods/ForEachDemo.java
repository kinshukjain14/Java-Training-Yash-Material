package com.yash.defaultmethods;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ForEachDemo {

	public static void main(String[] args) {

		List<String> names=new ArrayList<>();
		names.add("amit");
		names.add("sumeet");
		names.add("rohit");
		names.add("rohan");
		for(int i=0;i<names.size();i++) {
			System.out.println(names.get(i).toUpperCase());
		}
		for(String name:names) {
			System.out.println(name.toUpperCase());
		}
		names.forEach((name)->{
			System.out.println(name.toUpperCase());
		});
		
		names.forEach(System.out::println);
		
		
		Set<String> countryNames=new HashSet<>();
		countryNames.add("India");
		countryNames.add("China");
		countryNames.add("Russia");
		countryNames.add("Japan");
		
		countryNames.forEach(System.out::println);
		
		Map<Integer,String> mapUser=new HashMap<>();
		mapUser.put(1001, "Sabbir");
		mapUser.put(1002, "Amit");
		mapUser.put(1003, "Rohit");
		mapUser.put(1004, "Rakesh");
		
		mapUser.forEach((k,v)->{
			System.out.println("Key:"+k);
			System.out.println("Value:"+v);
		});
		
		
		
		
	}

}
