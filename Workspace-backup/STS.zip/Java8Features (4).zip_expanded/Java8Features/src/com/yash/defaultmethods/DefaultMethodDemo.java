package com.yash.defaultmethods;

public class DefaultMethodDemo {

	public static void main(String[] args) {

		Intf intf=new IntfImpl();
		intf.x();
	}

}
