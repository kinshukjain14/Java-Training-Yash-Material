package com.yash.nashorn;

import java.io.FileNotFoundException;
import java.io.FileReader;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class CallJavaScriptUsingNashornEngine {

	public static void main(String[] args) throws FileNotFoundException, ScriptException, NoSuchMethodException {

		ScriptEngineManager engineManager=new ScriptEngineManager();
		ScriptEngine scriptEngine=engineManager.getEngineByName("nashorn");
		Object target=scriptEngine.eval(new FileReader("D:\\javainductionio\\js\\Script.js"));
		Invocable invocable=(Invocable)scriptEngine;
		Object result=invocable.invokeFunction("greet", "Sabbir");
		System.out.println("Result:"+result);
	}

}
