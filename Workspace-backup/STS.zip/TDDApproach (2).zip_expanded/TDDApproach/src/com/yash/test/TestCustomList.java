package com.yash.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.yash.service.CustomList;


public class TestCustomList {
	private List<Object> list;
	@Before
	public void setUp() throws Exception {
		list=new CustomList<Object>();
	}

	@After
	public void tearDown() throws Exception {
		list=null;
	}

	@Test
	public void givenEmptyList_whenIsEmpty_thenTrueIsReturned() {
		assertTrue(list.isEmpty());
	}
	@Test
	public void givenNonEmptyList_whenIsEmpty_thenFalseIsReturned() {
		Object object=new Object();
		list.add(object);
		assertFalse(list.isEmpty());
	}

	@Test
	public void givenListWithAnElement_whenSize_thenOneIsReturned() {
		Object object=new Object();
		list.add(object);
		assertEquals(1,list.size());
	}
	@Test
	public void givenListWithAnElement_whenGet_thenThatElementIsReturned() {
        String name="Sabbir";
        list.add(name);
        String element=(String)list.get(0);
        
		assertEquals("Sabbir",element);
	}
	@Test
	public void givenListWithMultipleElement_whenGet_thenThatElementIsReturned() {
        String object1="Sabbir";
        String object2="Amit";
        list.add(object1);
        list.add(object2);
        String element=(String)list.get(1);        
		assertEquals("Amit",element);
	}
}
