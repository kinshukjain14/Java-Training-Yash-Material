package com.yash.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.yash.service.ArrayOperations;

public class TestArrayOperations {
	private ArrayOperations arrayOperations=null;
	
	@Before
	public void setUp() {
		arrayOperations=new ArrayOperations();
	}
	@After
	public void tearDown() {
		arrayOperations=null;
	}

	@Test
	public void testSortArray_ArraySortingPositive() {
		int[] arrayTestData= {5,4,3,2};
		int[] expected= {2,3,4,5};
		
	    int[] actual=arrayOperations.sortArray(arrayTestData);
	    assertArrayEquals(expected,actual);
		
	}
	@Test
	public void testSortArray_ArraySortingNegative() {
		int[] arrayTestData= {};
		try {
	    arrayOperations.sortArray(arrayTestData);
	    assertTrue(false);
		}catch(RuntimeException e) {
			assertTrue(true);
		}		
	}

}
