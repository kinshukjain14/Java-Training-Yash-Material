package com.yash.service;

import java.util.Arrays;

public class ArrayOperations {

	public int[] sortArray(int[] arrayTestData) {
		if(arrayTestData.length==0)
			throw new RuntimeException();
		Arrays.sort(arrayTestData);
		return arrayTestData;
	}

}
