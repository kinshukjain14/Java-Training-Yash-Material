package com.yash.service;

public class CalculatorService {

	public int add(int no1, int no2)
	{
		if(no1 > 999 || no2 > 999) 
		{
			throw new ArithmeticException("No1 or No2 cannot have four digits");
		}
		return no1+no2;
	}

	public double div(int no1, int no2) {
//		throw new NullPointerException();
		return no1/no2;
		
	}
	
}
