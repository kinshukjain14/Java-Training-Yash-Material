package com.yash.service;

import com.yash.dao.UserDAO;
import com.yash.exception.AuthenticationException;
import com.yash.helper.QuizFactory;

public class UserServiceImpl implements UserService {

	private UserDAO dao;
	public UserServiceImpl() {
		super();
		dao = QuizFactory.newUserDao();
	}

	@Override
	public boolean authenticateUser(String userName, String password) throws AuthenticationException {
		if(dao.checkUserCredentials(userName, password))
			return true;
		else
			throw new AuthenticationException("== Invalid username or password ==");
		
	}

}
