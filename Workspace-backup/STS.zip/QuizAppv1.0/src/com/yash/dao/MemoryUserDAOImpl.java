package com.yash.dao;

import java.util.List;

import com.yash.entity.User;
import com.yash.repository.UserRepo;

public class MemoryUserDAOImpl implements UserDAO{

	
	@Override
	public boolean checkUserCredentials(String userName, String password) {
		List<User> userData = UserRepo.loadUserData();
		for (User user : userData) {
			if(user.getUserName().equals(userName) && user.getPassword().equals(password)) {
				return true;
			}
		}
		return false;
	}

}
