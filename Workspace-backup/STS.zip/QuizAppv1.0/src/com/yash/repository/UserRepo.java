package com.yash.repository;

import java.util.ArrayList;
import java.util.List;

import com.yash.entity.User;

public class UserRepo 
{
	public static List<User> loadUserData() {
		List<User> userList = new ArrayList<User>();
		userList.add(new User("kinshuk.jain14","kinshu123"));
		userList.add(new User("admin","admin123"));
		userList.add(new User("ashutosh12","12345"));
		userList.add(new User("aishwary13","12345"));
		userList.add(new User("lokesh14","12345"));
		userList.add(new User("venkata15","12345"));
		return userList;
	}
}
