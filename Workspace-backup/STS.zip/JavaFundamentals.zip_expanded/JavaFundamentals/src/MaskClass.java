import java.io.Console;
import java.util.Arrays;
import java.util.Scanner;

public class MaskClass {
    
	public static void main(String[] args) {
//		Console console = System.console();
		
//		System.out.println(System.console());
//		char [] password = console.readPassword("Enter password: ");
//		System.out.println("Password was: " + Arrays.toString(password));
//		Arrays.fill(password,' ');
		
		
	}

}