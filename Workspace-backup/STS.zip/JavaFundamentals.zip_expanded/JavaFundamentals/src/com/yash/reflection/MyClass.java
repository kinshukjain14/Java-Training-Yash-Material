package com.yash.reflection;

public class MyClass {
	
	private int a;
	public int b;
	public int c;
	
	public MyClass() {}
	
	public MyClass(int a,int b,int c) {
		this.a=a;
		this.b=b;
		this.c=c;
	}
	
	public void display() {
		System.out.println("--display--");
	}
	
	
	
	public void someMethod(int a) {
		System.out.println("--someMethod---"+a);
	}
	
	public static void staticMethod() {
		System.out.println("--static Method---");
	}

}
