package com.yash.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class DynamicInitializationMethodInvocation {

	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, SecurityException, IllegalArgumentException, InvocationTargetException {

		Class classData=Class.forName("com.yash.reflection.SomeClass");
		
		//dynamic object initialization
		SomeClass someClassObject=(SomeClass)classData.newInstance();
		
		Method methodA=(Method)classData.getMethod("a",null);
		Method methodB=(Method)classData.getMethod("b",null);
		
		boolean flag=false;//based on some condition
		//dynamic method invocation
		if(flag) {
			methodA.invoke(someClassObject, null);
		}else {
			methodB.invoke(someClassObject, null);

		}
		Method methodC=(Method)classData.getDeclaredMethod("c",null);
		methodC.setAccessible(true);
		methodC.invoke(someClassObject, null);
		
		//4.
		
		Class someClassData=SomeClass.class;
		
		
		
		

		
	}

}
