package com.yash.reflection;

public class SomeClass {
	
	public void a() {
		System.out.println("--a--");
	}
	public void b() {
		System.out.println("--b--");
	}
	private void c() {
		System.out.println("--c--");
	}

}
