package com.yash.reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;


public class ReflectionDemo {

	public static void main(String[] args) throws ClassNotFoundException {


		//1. To Obtain Class reference that points to class meta data
		
		MyClass mc=new MyClass();
		Class classData1=mc.getClass();//java.lang.Class
		
		//2. To Obtain Class refernce that points to class meta data using ClassLoader
		
		ClassLoader loader=ClassLoader.getSystemClassLoader();
		Class classData2=loader.loadClass("com.yash.reflection.MyClass");
		
		//3. To obtain class reference using forName() in java.lang.Class
		Class classData3=Class.forName("com.yash.reflection.MyClass");
		
		
		Constructor[] constructors=classData3.getConstructors();
		for(Constructor constructor:constructors) {
			//System.out.println("Constructor Name:"+constructor.getName());
			//System.out.println("Number of parameter:"+constructor.getParameterCount());
			//System.out.println("Accessibility:"+constructor.getModifiers());
			System.out.println(constructor);
		}
		Method[] methods=classData3.getMethods();
		for(Method method:methods) {
			System.out.println(method);
		}
		Field[] fields=classData3.getFields();
		for(Field field:fields) {
			System.out.println(field);
		}
		Field[] privateFields=classData3.getDeclaredFields();
		
		for(Field field:privateFields) {
			System.out.println(field);
		}
                   Package pack=classData3.getPackage();
                   System.out.println(pack);
	}

}
