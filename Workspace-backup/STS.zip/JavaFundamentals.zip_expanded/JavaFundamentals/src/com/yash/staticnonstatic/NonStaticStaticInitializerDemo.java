package com.yash.staticnonstatic;

public class NonStaticStaticInitializerDemo {

	int i;
	static int j;
	
	{
		i=20;
		System.out.println("--non static intializer block 1--");
	}
	
	{
		System.out.println("--non static intializer block 2--");
	}
	
	static {
		j=50;
		System.out.println("--static block 1--");
	}
	static {
		
		System.out.println("--static block 2--");
	}
	
	public NonStaticStaticInitializerDemo(){
		System.out.println("--constructor--");
	}
	
	public void nonStaticMethod1() {
		System.out.println("--nonStaticMethod 1--");
	}
	public void nonStaticMethod2() {
		nonStaticMethod1();
		System.out.println("--nonStaticMethod 2--");
		staticMethod2();//without reference of the class
	}
	
	public static void staticMethod1() {
		System.out.println("--staticMethod 1--");

	}
	public static void staticMethod2() {

		staticMethod1();//direct access
		NonStaticStaticInitializerDemo o3=new NonStaticStaticInitializerDemo();
		o3.nonStaticMethod2();//accessible only via the object
	}
	public static void main(String[] args) {
		NonStaticStaticInitializerDemo o1=new NonStaticStaticInitializerDemo();
		System.out.println("Value of i for o1:"+o1.i);
		
		o1.i=40;
		
		System.out.println("Value of i for o1:"+o1.i);

		NonStaticStaticInitializerDemo o2=new NonStaticStaticInitializerDemo();
		System.out.println("Value of i for o2:"+o2.i);
		
		
		System.out.println("Value of j:"+NonStaticStaticInitializerDemo.j);
		
		NonStaticStaticInitializerDemo.j=70;
		
		System.out.println("Value of o2:"+NonStaticStaticInitializerDemo.j);
		
		o2.nonStaticMethod2();
	}

}
