package com.yash.staticnonstatic;
import static java.lang.Math.*;
public class StaticImportsDemo {

	public static void main(String[] args) {

		double result=sin(3.4)*cos(3.2)/PI;
	}

}
