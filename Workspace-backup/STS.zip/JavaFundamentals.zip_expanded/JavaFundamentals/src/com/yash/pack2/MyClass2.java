package com.yash.pack2;
//import com.yash.pack1.*;
import com.yash.pack1.MyClass1;
import java.util.*;
import java.sql.*;
public class MyClass2 {
	
	public void y() {
		MyClass1 myclass1Object=new MyClass1();
		myclass1Object.x();
		
		java.util.Date date=new java.util.Date();

	}

}
