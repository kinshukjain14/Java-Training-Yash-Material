package com.yash.generics;

public class C extends B {

}
