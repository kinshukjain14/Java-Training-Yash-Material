package com.yash.generics;

public class CacheString {
	
	private String data;
	
	public void add(String data) {
		this.data=data;
	}

	public String get() {
		return data;
	}
}
