package com.yash.generics;

import java.util.List;

public class GeneralizedMethods {
	
	//specialized methods
	public static void printString(List<String> list) {
		for(String o:list) {
			System.out.println(o);
		}
	}
	//specialized methods
    public static void printInteger(List<Integer> list) {
    	for(Integer o:list) {
			System.out.println(o);
		}
	}
	//specialized methods    
    public static void printObject(List<Object> list) {
    	for(Object o:list) {
			System.out.println(o);
		}
	}
    //Generalized method
    public static void print(List<?> list) {
    	for(Object o:list) {
			System.out.println(o);
		}
	}
    
    public static void printObjectOfAllthoseClassesWhichExtendsNumber(List<? extends Number> list) {
    	
    	for(Number o:list) {
    		System.out.println(o);
    	}
    }
    
public static void printObjectOfAllthoseClassesWhichareSuperClassOfNumber(List<? super Number> list) {
    	
    	for(Object o:list) {
    		System.out.println(o);
    	}
    }
public static void printObjectOfAllthoseClassesWhichareSuperClassOfC(List<? super C> list) {
	
	for(Object o:list) {
		System.out.println(o);
	}
}
    
    
    public static void invokeX(List<? extends Intf> list) {
    	for(Intf o:list) {
    		o.x();
    	}
    }

    
}
