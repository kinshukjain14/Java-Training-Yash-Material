package com.yash.generics;

public class B extends A {

}
