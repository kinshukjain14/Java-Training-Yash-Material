package com.yash.generics;

public class CacheInteger {

	private Integer data;
	
	public void add(Integer data) {
		this.data=data;
	}
	public Integer get() {
		return data;
	}
}
