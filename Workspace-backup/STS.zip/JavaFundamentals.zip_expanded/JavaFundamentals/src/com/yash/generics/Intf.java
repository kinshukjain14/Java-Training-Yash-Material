package com.yash.generics;

public interface Intf {

	public void x();
}
