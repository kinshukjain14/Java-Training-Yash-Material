package com.yash.generics;

public class D extends C{

}
