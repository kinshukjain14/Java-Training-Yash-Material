package com.yash.generics;

public class Impl1 implements Intf {

	@Override
	public void x() {

		System.out.println("--implementation 1--");
	}

}
