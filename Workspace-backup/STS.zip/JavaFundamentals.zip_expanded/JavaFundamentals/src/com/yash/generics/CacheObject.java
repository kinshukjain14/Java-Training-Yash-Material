package com.yash.generics;

public class CacheObject {

	private Object data;
	
	public void add(Object data) {
		this.data=data;
	}
	public Object get() {
		return data;
	}
}
