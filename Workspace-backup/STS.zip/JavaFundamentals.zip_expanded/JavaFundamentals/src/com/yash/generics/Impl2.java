package com.yash.generics;

public class Impl2 implements Intf {

	@Override
	public void x() {
		System.out.println("--implementation 2--");
	}

}
