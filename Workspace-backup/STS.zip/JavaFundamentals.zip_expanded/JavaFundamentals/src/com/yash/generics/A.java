package com.yash.generics;

public class A {

}
