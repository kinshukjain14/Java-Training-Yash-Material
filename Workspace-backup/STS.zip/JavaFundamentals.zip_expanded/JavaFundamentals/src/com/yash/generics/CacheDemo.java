package com.yash.generics;

import java.util.ArrayList;
import java.util.List;

public class CacheDemo {

	public static void main(String[] args) {

		//storage of an object
		String data="user input";
		CacheString cacheString=new CacheString();
		cacheString.add(data);
		
		
		//later for retrieval of object
		String dataBackString=cacheString.get();
		
		CacheInteger cacheInteger=new CacheInteger();
		cacheInteger.add(10);
		
		Integer dataBackInteger=cacheInteger.get();
		
		
		CacheObject cacheObjectString=new CacheObject();
		cacheObjectString.add("sabbir");
		
		//cacheObjectString.add(12.f);//no checks are being performed will allow any reference type unchecked
		
		CacheObject cacheObjectInteger=new CacheObject();
		cacheObjectInteger.add(100);
		
		Object object1=cacheObjectString.get();
		//String stringObjectBack=(String)object1;
		
		Object object2=cacheObjectString.get();
		//Integer integerObjectBack=(Integer)object2;
		
		CacheAny<String> cacheAnyString=new CacheAny<>();
		cacheAnyString.add("sabbir");
		//cacheAnyString.add(10);//checked operation
		
		String stringObjectBackGenerics=cacheAnyString.get();
		
		CacheAny<Integer> cacheAnyInteger=new CacheAny<>();
		cacheAnyInteger.add(10);
		//cacheAnyString.add(10);//checked operation
		
		int integerObjectBackGenerics=cacheAnyInteger.get();
		
		List<String> listString=new ArrayList<>();
		listString.add("sabbir");
		listString.add("amit");
		
		GeneralizedMethods.printString(listString);
		
		List<Integer> listInteger=new ArrayList<>();
		listInteger.add(10);
		listInteger.add(20);
		
		GeneralizedMethods.printInteger(listInteger);
		
		List<Object> listObject=new ArrayList<>();
		GeneralizedMethods.printObject(listObject);
		
		GeneralizedMethods.print(listString);
		GeneralizedMethods.print(listInteger);
		GeneralizedMethods.print(listObject);
		
        
        List<Intf> listOfIntf=new ArrayList<>();
        listOfIntf.add(new Impl1());
        listOfIntf.add(new Impl2());
        
        List<String> listOfString=new ArrayList<>();
        
        GeneralizedMethods.invokeX(listOfIntf);
        //GeneralizedMethods.invokeX(listOfString);
        
        List<Integer> integerList=new ArrayList<>();
        integerList.add(10);
        integerList.add(20);
        integerList.add(30);
        
        List<Float> floatList=new ArrayList<>();
        floatList.add(10.4f);
        floatList.add(20.2f);
        floatList.add(30.21f);
        
        GeneralizedMethods.printObjectOfAllthoseClassesWhichExtendsNumber(integerList);
        GeneralizedMethods.printObjectOfAllthoseClassesWhichExtendsNumber(floatList);
        
        List<String> stringList=new ArrayList<>();
        stringList.add("amit");
        stringList.add("sumeet");
        
        //error
        //GeneralizedMethods.printObjectOfAllthoseClassesWhichExtendsNumber(stringList);
        
        List<Object> listObject1=new ArrayList<>();
        
        GeneralizedMethods.printObjectOfAllthoseClassesWhichareSuperClassOfNumber(listObject1);
        
        List<A> aList=new ArrayList<>();
        List<B> blist=new ArrayList<>();
        List<C> clist=new ArrayList<>();

        List<D> dlist=new ArrayList<>();
        GeneralizedMethods.printObjectOfAllthoseClassesWhichareSuperClassOfC(aList);
        GeneralizedMethods.printObjectOfAllthoseClassesWhichareSuperClassOfC(blist);
        GeneralizedMethods.printObjectOfAllthoseClassesWhichareSuperClassOfC(clist);
        //error
        //GeneralizedMethods.printObjectOfAllthoseClassesWhichareSuperClassOfC(dlist);


        

        
        
        
        
        

        
        
        
      
        
 
        
        
		
		
		
	}

}
