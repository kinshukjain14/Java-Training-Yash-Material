package com.yash.multithreading;

public class MultithreadedApplication {
 
	class SumTask extends Thread{
		
		public int sum() {
			int sum=0;
			for(int i=1;i<=10;i++) {
				sum+=i;
				System.out.println(Thread.currentThread()+" doing "+"Sum done so far:"+sum);
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return sum;
		}
		@Override
		public void run() {
			int sum=sum();
			System.out.println("Sum is:"+sum);
		}
		
	}
	
	class ProductTask implements Runnable{

		public double product() {
			double product=1;
			for(int i=1;i<=10;i++) {
				product*=i;
				System.out.println(Thread.currentThread()+" product done so far: "+product);
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			return product;
		}
		
		@Override
		public void run() {
		
			double product=product();
			System.out.println("Product is:"+product);
		}
		
		
		
	}
	
	public static void main(String[] args) {

		while(true) {
		System.out.println("Main Thread:"+Thread.currentThread());
		
		Thread sumTask=new Thread(new MultithreadedApplication().new SumTask(),"Sum Worker");
		sumTask.start();
	
	    Thread productTask=new Thread(new MultithreadedApplication().new ProductTask(),"Product Worker");
	    productTask.start();
	    
	    Runnable divisionTask=new Runnable() {
	    	
	    	public double division() {
	    		double division=1;
	    		for(int i=1;i<=10;i++) {
	    			division/=i;
	    			System.out.println(Thread.currentThread()+" division done so far :"+division);
	    			try {
						Thread.sleep(200);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
	    		}
	    		return division;
	    	}
	    	@Override
	    	public void run() {
	    		double division=division();
	    		System.out.println("Division is:"+division);
	    	}
	    };
	    
	    Thread divTask=new Thread(divisionTask,"Division worker");
	    divTask.start();
	    
	    
	    Runnable lambdaRunnable=()->{
	    	System.out.println("Fourth worker thread");
	    };
	    
	    Thread fourthWorker=new Thread(lambdaRunnable);
	    fourthWorker.start();
	}
	}
}
