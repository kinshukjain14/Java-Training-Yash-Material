package com.yash.multithreading;

public class SingleThreadedApplication {

	public int sum() {
		int sum=0;
		for(int i=1;i<=10;i++) {
			sum+=i;
		}
		Thread currentThread=Thread.currentThread();
		System.out.println(currentThread);
		return sum;
	}
	
	public double product() {
		double product=1;
		for(int i=1;i<=10;i++) {
			product*=i;
		}
		Thread currentThread=Thread.currentThread();
		System.out.println(currentThread);
		return product;
	}
	public double division() {
		double div=1;
		for(int i=1;i<=10;i++) {
			div/=i;
		}
		Thread currentThread=Thread.currentThread();
		System.out.println(currentThread);
		return div;
	}
	public static void main(String[] args) {

		SingleThreadedApplication o=new SingleThreadedApplication();
		int sum=o.sum();
		System.out.println("Sum:"+sum);
		
		double product=o.product();
		System.out.println("Product:"+product);
		
		double division=o.division();
		System.out.println("Division:"+division);
		
		Thread currentThread=Thread.currentThread();
		System.out.println(currentThread);
		while(true) {}
		
	}

}
