package com.yash.concurrentcollection;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayListDemo {

	public static void main(String[] args) {

		CopyOnWriteArrayList<Integer> list=new CopyOnWriteArrayList<>(new Integer[] {1,2,3});
		Iterator<Integer> iterator=list.iterator();
		while(iterator.hasNext()) {
			list.remove(iterator.next());
		}
		list.add(40);
		System.out.println(list);
		
	}

}
