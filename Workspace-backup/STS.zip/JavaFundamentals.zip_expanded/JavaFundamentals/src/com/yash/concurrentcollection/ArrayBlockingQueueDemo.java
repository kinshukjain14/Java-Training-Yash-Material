package com.yash.concurrentcollection;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ArrayBlockingQueueDemo {

	public static void main(String[] args) {

		BlockingQueue<String> queue=new ArrayBlockingQueue<String>(4);
		try {
			queue.put("sabbir");
			queue.put("amit");
			queue.put("chetan");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			String first=queue.take();
			System.out.println(first);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
