package com.yash.concurrentcollection;

import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashhMapDemo {

	public static void main(String[] args) {

		ConcurrentHashMap<Integer,String> map=new ConcurrentHashMap<Integer,String>();
		map.put(1, "Sabbir");
		map.put(2, "Amit");
		
		System.out.println(map);
	}

}
