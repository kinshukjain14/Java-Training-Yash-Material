package com.yash.arrays;

public class MyClass {

}
