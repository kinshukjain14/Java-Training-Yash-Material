package com.yash.arrays;

public class SingleDimensionalArrayDemo {

	public static void main(String[] args) {

		//primitive data type
		int intArray[];
		int[] validIntArray;
		
		float floatArray[];
		float[] validFloatArray;
		
		//reference type
		
		String[] stringArray;
		Object[] objectArray;
		MyClass[] myclassArray;
		
		intArray=new int[5];
		intArray[0]=1;
		
		int[] combinedeclrinstantion=new int[5];
		
		int[] otherWay=new int[] {1,2,3,4};
		
		String[] stringArrayOtherWay=new String[] {"sabbir","amit"};
		for(int i=0;i<stringArrayOtherWay.length;i++) {
			System.out.println(stringArrayOtherWay[i]);
		}
		for(String element:stringArrayOtherWay) {
			System.out.println(element);
		}

		MyClass mc=new MyClass();
		
		/*
		 * Handler Pool(mc) =====>Object Pool()
		 */
		myclassArray=new MyClass[] {new MyClass(),new MyClass()};
		
		String[] stringArrayDecInitialization= {"sabbir","amit","rohit"};
		
		
		
	}

}
