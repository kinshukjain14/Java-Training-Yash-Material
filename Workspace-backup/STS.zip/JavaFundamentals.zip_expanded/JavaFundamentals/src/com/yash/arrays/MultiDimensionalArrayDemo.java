package com.yash.arrays;

public class MultiDimensionalArrayDemo {

	public static void main(String[] args) {

		int[][] int2Darray=new int[3][3];
		
		int[][][] int3Darray=new int[3][3][3];
		
		
		int int2DNewarray[][]= {{0,1,3},{0,2,1}};
		int n=1;
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				int2Darray[i][j]=n;
				n++;
			}
		}
		
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				System.out.print(int2Darray[i][j]+" ");
			}
			System.out.println();
		}
		
	}

}
