package com.yash.ui;


import com.yash.abstraction.CalcProfit;
import com.yash.abstraction.Figure;
import com.yash.abstraction.Rectangle;
import com.yash.abstraction.Square;
import com.yash.helper.FactoryCalcProfit;
import com.yash.helper.FactoryFigure;

public class UIClient {

	public static void main(String[] args) {

		Figure figRef=FactoryFigure.createFigure();
		System.out.println("Area:"+figRef.area());
		
		CalcProfit calcProfit=
				FactoryCalcProfit.createCalcProfit();
		System.out.println("Profit:"+calcProfit.calculateProfit());
		
	}

}
