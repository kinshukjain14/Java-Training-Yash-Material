package com.yash.utility;

import java.util.Locale;
import java.util.ResourceBundle;

public class ResourceBundleDemo {

	public static void main(String[] args) {
		ResourceBundle resourceBundle=ResourceBundle.getBundle("db");
		String driver=resourceBundle.getString("driver");
		String url=resourceBundle.getString("url");
		String username=resourceBundle.getString("username");
		String password=resourceBundle.getString("password");

		System.out.println("driver:"+driver);
		System.out.println("url:"+url);
		System.out.println("username:"+username);
		System.out.println("password:"+password);
		
		System.out.println("==========properties file picked up based on locale==========");
		ResourceBundle defaultResourceBundle=ResourceBundle.getBundle("UI");
		System.out.println("Button label:"+defaultResourceBundle.getString("buttonlabel"));
		
		System.out.println("==========properties file picked up based on locale french==========");
		ResourceBundle resourcebundleFrench=ResourceBundle.getBundle("UI",Locale.FRENCH);
		System.out.println("Button label:"+resourcebundleFrench.getString("buttonlabel"));
		
		System.out.println("==========properties file picked up based on locale german==========");
		ResourceBundle resourcebundleGerman=ResourceBundle.getBundle("UI",Locale.GERMAN);
		System.out.println("Button label:"+resourcebundleGerman.getString("buttonlabel"));
		
	}

}
