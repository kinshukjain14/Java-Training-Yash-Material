package com.yash.inheritance;

public class FacultyVisitor extends Visitor{
	/* Error
	@Override
	public boolean login() {
		return false;
	}*/

}
