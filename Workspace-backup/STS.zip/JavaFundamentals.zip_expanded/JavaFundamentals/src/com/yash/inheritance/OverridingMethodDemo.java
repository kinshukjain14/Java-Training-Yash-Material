package com.yash.inheritance;

public class OverridingMethodDemo {

	public static void main(String[] args) {

		Visitor visitor=new Visitor("ramesh","ramesh","ramesh","desai","27774","k@b.com",1001);
		System.out.println("Was login successful?:"+visitor.login());
		Admin admin=new Admin("admin1","admin1","brijesh","patel","88774","n@b.com",1);
		System.out.println("Was login successful?:"+admin.login());
		
		boolean visitorAuth=User.auth(visitor);
		System.out.println("Visitor was authorized?:"+visitorAuth);
		boolean adminAuth=User.auth(admin);
		System.out.println("Admin was authorized?:"+adminAuth);
		
		System.out.println(visitor);


	}

}
