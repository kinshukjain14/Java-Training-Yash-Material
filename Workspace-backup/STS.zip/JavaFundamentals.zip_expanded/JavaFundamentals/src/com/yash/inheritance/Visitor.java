package com.yash.inheritance;

public class Visitor extends User{

	private String userName;
	private int visitorId;
	
	public Visitor() {}
	
	public Visitor(String userName,String password,String firstName,String lastName,String phoneNumber,String emailAddress,int visitorId) {
		super(userName,password,firstName,lastName,phoneNumber,emailAddress);
		this.visitorId=visitorId;
	}

	public int getVisitorId() {
		return visitorId;
	}
	@Override
	public final boolean login() {
		if(super.login() && visitorId==1003) {
			return true;
		}
		return false;
	}
	@Override
	public String toString() {
		StringBuilder builder=new StringBuilder();
		builder.append("UserName:"+super.userName+"\n");
		builder.append("Password:"+password+"\n");
		builder.append("firstName:"+firstName+"\n");
		builder.append("lastName:"+lastName+"\n");
		builder.append("PhoneNumber:"+phoneNumber+"\n");
		builder.append("EmailAddress:"+emailAddress+"\n");
		builder.append("visitorId:"+visitorId+"\n");
		return builder.toString();
	}
	@Override
	public boolean equals(Object object) {
		if(object!=null && object instanceof Visitor) {
			Visitor visitor=(Visitor)object;
			if(this.userName.equals(visitor.userName)
					&& this.password.equals(visitor.password)
					&& this.firstName.equals(visitor.firstName) 
					&& this.lastName.equals(visitor.lastName)
					&& this.phoneNumber.equals(visitor.phoneNumber)
					&& this.emailAddress.equals(visitor.emailAddress)
					&& this.visitorId==visitor.visitorId
					) {
				return true;
			}
		}
    return false; 
	}
	@Override
	public int hashCode() {
		return userName.hashCode()^password.hashCode()^firstName.hashCode()
				^lastName.hashCode()^phoneNumber.hashCode()^emailAddress.hashCode()
				^visitorId;
	}
	
}
