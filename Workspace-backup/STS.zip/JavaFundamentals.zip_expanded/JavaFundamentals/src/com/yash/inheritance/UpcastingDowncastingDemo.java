package com.yash.inheritance;

public class UpcastingDowncastingDemo {

	public static void main(String[] args) {

		Visitor visitor=new Visitor("sabbir","sabbir123","sabbir","poonawala","23344","x@y.com",1001);
		System.out.println("User name of visitor:"+visitor.getUserName());
		System.out.println("Password of visitor:"+visitor.getPassword());
		System.out.println("Visitor id of visitor:"+visitor.getVisitorId());
		
		Admin admin=new Admin("admin","admin","amit","shah","244","admin@y.com",1);
		System.out.println("User name of admin:"+admin.getUserName());
		System.out.println("Password of admin:"+admin.getPassword());
		
		//Upward casting
		
		User user1=new Visitor("rohit","rohit123","rohit","shah","2331144","b@c.com",1002);
		System.out.println("User name of user1:"+user1.getUserName());
		System.out.println("Password of user1:"+user1.getPassword());
	//	System.out.println("Visitor id of user1:"+user1.getVisitorId()); Error
		
		User user2=new Admin("admin2","admin2","raj","shehkar","29931144","bnn@n.com",2);
		System.out.println("User name of user2:"+user1.getUserName());
		System.out.println("Password of user2:"+user2.getPassword());
	//	System.out.println("Visitor id of user1:"+user1.getVisitorId()); Error
		
		//downcasting
		User userRef1=new Visitor("Ramesh","ramesh123","ramesh","desai","27774","k@b.com",1003);
		Visitor visitorRef=(Visitor)userRef1;
		
		User userRef2=new Admin("admin1","admin123","brijesh","patel","88774","n@b.com",1);
		Admin adminRef=(Admin)userRef2;
		
		//casting not possible
		
		Visitor visitorRef1=new Visitor();
		//Admin adminRef1=(Admin)visitorRef1; Compile time error
		
		if(visitorRef1 instanceof Visitor)
			System.out.println("VisitorRef1 is of type Visitor");
		
		if(visitorRef1 instanceof User)
			System.out.println("visitorRef1 can be casted into type User");
		
		//if(visitorRef1 instanceof Admin) compile time error
		
		User userRefNull=null;
		Visitor visitorRefNull=(Visitor)userRefNull;
		visitorRefNull=new Visitor();
		Admin adminRefNull=(Admin)userRefNull;
		adminRefNull=new Admin();
		
	}

}
