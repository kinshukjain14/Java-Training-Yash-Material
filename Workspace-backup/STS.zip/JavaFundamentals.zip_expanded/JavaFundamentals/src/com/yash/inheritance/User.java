package com.yash.inheritance;

public class User {
	
	protected String userName;
	protected String password;
	
	protected String firstName;
	protected String lastName;
	protected String phoneNumber;
	protected String emailAddress;
	
	public User() {}
	
	public User(String userName, String password, String firstName, String lastName, String phoneNumber,
			String emailAddress) {
		super();
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.emailAddress = emailAddress;
	}
	
	public String getUserName() {
		return userName;
	}
	public String getPassword() {
		return password;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	
	public boolean login() {
		if(userName.equals(password)) {
			return true;
		}
		return false;
	}
	
	//Generalized Method
	public static boolean auth(User user) {
		boolean flag=false;
		if(user instanceof Visitor)
		{
			Visitor visitor=(Visitor)user;
			if(visitor.getUserName().equals(visitor.getPassword())&&visitor.getVisitorId()==1001) {
				flag= true;
			}
		}
		if(user instanceof Admin) {
			Admin admin=(Admin)user;
			if(admin.getUserName().equals(admin.getPassword())&&admin.getAdminId()==1) {
				flag= true;
			}
		}
		return flag;
	}

	@Override
	public String toString() {
		return "User [userName=" + userName + ", password=" + password + ", firstName=" + firstName + ", lastName="
				+ lastName + ", phoneNumber=" + phoneNumber + ", emailAddress=" + emailAddress + "]";
	}

	
	
}
