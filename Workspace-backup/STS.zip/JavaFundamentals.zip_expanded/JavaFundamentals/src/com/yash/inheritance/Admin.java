package com.yash.inheritance;

public class Admin extends User {
	private int adminId;
	
	public Admin() {}
	
	public Admin(String userName,String password,String firstName,String lastName,String phoneNumber,String emailAddress,int adminId) {
		super(userName,password,firstName,lastName,phoneNumber,emailAddress);
     this.adminId=adminId;
	}

	public int getAdminId() {
		return adminId;
	}
	public boolean login() {
		if(super.login() && adminId==1) {
			return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + "]";
	}
	
	
}
