package com.yash.inheritance;

/*error public class StudentVisitor extends Visitor {

}
*/