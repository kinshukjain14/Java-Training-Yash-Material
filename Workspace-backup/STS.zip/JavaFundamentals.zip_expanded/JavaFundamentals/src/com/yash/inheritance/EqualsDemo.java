package com.yash.inheritance;

import java.util.HashSet;

public class EqualsDemo {

	public static void main(String[] args) {

		
		int i=10;
		int j=10;
		
		if(i==j)
			System.out.println("i==j");
				
		String str1="hello";
		String str2="hello";
		
		if(str1==str2)
			System.out.println("str1==str2");
		
		String strObj1=new String("Hello");
		String strObj2=new String("Hello");
		
		if(strObj1==strObj2)
		   System.out.println("strObj1==strObj2");
		
		if(strObj1.equals(strObj2))
			System.out.println("strObj1.equals(strObj2)");
		
		
		Visitor visitor1=new Visitor("sabbirp","sabbir123","sabbir","poonawala","3400222","x@b.com",1009);
		Visitor visitor2=new Visitor("sabbir123","sabbirp","sabbir","poonawala","3400222","x@b.com",1009);
		
		if(visitor1==visitor2)
			System.out.println("visitor1==visitor2");
		
		if(visitor1.equals(visitor2))
			System.out.println("visitor1.equals(visitor2)");
		
		System.out.println("hashCode of visitor 1:"+visitor1.hashCode());
		System.out.println("hashCode of visitor 2:"+visitor2.hashCode());		
		
	}

}
