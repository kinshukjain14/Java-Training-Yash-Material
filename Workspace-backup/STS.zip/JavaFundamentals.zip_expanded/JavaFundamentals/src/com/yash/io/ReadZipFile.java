package com.yash.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

public class ReadZipFile {

	public static void main(String[] args) throws IOException {

		File file=new File("d:\\apache-jmeter-5.1.1.zip");
		InputStream is=new FileInputStream(file);
		ZipInputStream zip=new ZipInputStream(is);
		ZipEntry entry;
		while(( entry=zip.getNextEntry())!=null) {
			System.out.println(entry.getName());
		}
		zip.close();
	}

}
