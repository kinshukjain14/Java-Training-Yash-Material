package com.yash.io;

import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

public class FileVistorDemo extends SimpleFileVisitor<Path> {
	
	@Override
	public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {

		System.out.println(file.getFileName().getFileName());
		if(file.getFileName().getFileName().endsWith("txt")) {
			System.out.println(file+" is a text file");
		}/*
		else if(attrs.isRegularFile()) {
			System.out.println(file+" is a regular file with size "+attrs.size());
		}else if(attrs.isSymbolicLink()) {
			System.out.println(file+" is a symbolic link");
		}else {
			System.out.println(file+" is not a symbolic link.");
		}*/
	   return FileVisitResult.CONTINUE;
	}

	@Override
	public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
		
		System.out.println(dir+" visited ");
		return FileVisitResult.CONTINUE;
	}
	
	@Override
	public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
		
		System.out.println(exc);
		return FileVisitResult.CONTINUE;
	}
}
