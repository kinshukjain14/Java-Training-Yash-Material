package com.yash.io;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.io.Writer;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.FileChannel;

public class CharBufferDemo {

	public static void main(String[] args) throws IOException {

		try(
			Reader reader=new FileReader("D:\\javainductionio\\TextualFile1.txt");
			BufferedReader bufferReader=new BufferedReader(reader);
			
				Writer writer=new FileWriter("D:\\javainductionio\\TextualFile2.txt");
				BufferedWriter bufferWriter=new BufferedWriter(writer);
			){
			String data=null;
			while((data=bufferReader.readLine())!=null) {
				bufferWriter.write(data);
			}
			
		}catch(IOException e) {
			System.err.println("Error processing");
		}
		
		//NIO
		
				RandomAccessFile rafRead=new RandomAccessFile("D:\\javainductionio\\BufferTextFile.txt","rw");
				FileChannel readChannel=rafRead.getChannel();
				
				
				RandomAccessFile rafWrite=new RandomAccessFile("D:\\javainductionio\\BufferTextWriteChannelFile.txt","rw");
				rafWrite.seek(10);
				FileChannel writeChannel=rafWrite.getChannel();
				
				ByteBuffer bufferIn=ByteBuffer.allocate(1024);
				ByteBuffer bufferOut=ByteBuffer.allocate(1024);
				while(readChannel.read(bufferIn)>0) {			
					bufferIn.flip();
					for(int i=0;i<bufferIn.limit();i++) {
						bufferOut.put(bufferIn.get(i));
					}
					bufferOut.flip();
					bufferIn.clear();

				}		
				writeChannel.write(bufferOut);
				rafRead.close();
				rafWrite.close();

				
			
	}

}
