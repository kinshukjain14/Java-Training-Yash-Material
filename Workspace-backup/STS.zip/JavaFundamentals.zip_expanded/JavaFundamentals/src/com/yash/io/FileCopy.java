package com.yash.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class FileCopy {

	public static void main(String[] args) throws IOException {
		
		//Binary stream

		File readFile=new File("D:\\javainductionio\\BinaryFile1.txt");
		File writeFile=new File("D:\\javainductionio\\BinaryFile2.txt");

		try(
			InputStream inputBinaryStream=new FileInputStream(readFile);
		    OutputStream outputBinaryStream=new FileOutputStream(writeFile);
			){
			
			int k=0;
			while((k=inputBinaryStream.read())!=-1) {
				outputBinaryStream.write(k);
			}
			
		}catch(IOException e) {
			System.err.println("Error performing copy operation");
		}
		
		//Character-based stream
		
		File textFile1=new File("D:\\javainductionio\\TextualFile1.txt");
		File textFile2=new File("D:\\javainductionio\\TextualFile2.txt");
		
		try(
		Reader inputcharacterStream=new FileReader(textFile1);
		Writer ouputcharacterStream=new FileWriter(textFile2);
		 ){
			int ch=0;
			while((ch=inputcharacterStream.read())!=-1) {
				ouputcharacterStream.write(ch);
			}
			
		}catch(IOException e) {
			System.err.println("Error performing copy operation");
		}
		
		//NIO
		
		Path readBinaryPath=Paths.get("D:\\javainductionio\\BinaryFile1.txt");
		Path writeBinaryPath=Paths.get("D:\\javainductionio\\BinaryFile2.txt");
		
		byte[] contentOfFile=Files.readAllBytes(readBinaryPath);
		Files.write(writeBinaryPath, contentOfFile, StandardOpenOption.APPEND);
		
		
		Path pathtextFile1=Paths.get("D:\\javainductionio\\TextualFile1.txt");
		Path pathtextFile2=Paths.get("D:\\javainductionio\\TextualFile2.txt");
		
		List<String> textcontentOfFile=Files.readAllLines(pathtextFile1);
		Files.write(pathtextFile2, textcontentOfFile, StandardOpenOption.APPEND);
		
		
		Files.copy(pathtextFile1,writeBinaryPath,StandardCopyOption.REPLACE_EXISTING);
		Files.copy(pathtextFile2,writeBinaryPath,StandardCopyOption.REPLACE_EXISTING);
		
		
		Path movetextFile1=Paths.get("D:\\movedfiles\\TextualFile2.txt");
		Files.move(pathtextFile2, movetextFile1, StandardCopyOption.ATOMIC_MOVE);


		
	}

}
