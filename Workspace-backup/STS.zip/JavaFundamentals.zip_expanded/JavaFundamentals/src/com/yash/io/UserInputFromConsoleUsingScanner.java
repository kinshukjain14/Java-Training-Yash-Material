package com.yash.io;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.yash.serialization.Employee;

public class UserInputFromConsoleUsingScanner {

	public static void main(String[] args) {
        Employee e=new Employee();
		try(
		   Scanner scanner=new Scanner(System.in);
				
		  ){
			System.out.print("Employee Id:");
			if(scanner.hasNextInt()) {
				e.setEmpId(scanner.nextInt());
			}else {
				throw new InputMismatchException("Invalid Input");
			}
			
			System.out.print("Employee Name:");
			if(scanner.hasNext()) {
				e.setEmpName(scanner.next());
			}
			
			System.out.print("Employee Salary:");
			if(scanner.hasNextDouble()) {
				e.setEmpSalary(scanner.nextDouble());
			}
			
			System.out.print("Employee Designation:");
			if(scanner.hasNext()) {
				e.setEmpDesignation(scanner.next());
			}
			
		}catch(InputMismatchException ex) {
			System.err.println("incorrect input");
		}
		if(e.getEmpId()==0 || e.getEmpName()==null || e.getEmpSalary()==0.0 || e.getEmpDesignation()==null) {
			System.out.println("Please try again later...");
		}else {
		System.out.println(e);
		}
	}

}
