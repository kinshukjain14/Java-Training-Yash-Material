package com.yash.io;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

public class StringReaderWriterDemo {

	public static void main(String[] args) throws IOException {

		String data="This is string data";
		
		char charArray[]=new char[data.length()];
		
		StringReader stringReader=new StringReader(data);
		StringWriter stringWriter=new StringWriter();
		int k=0;
		while((k=stringReader.read())!=-1) {
			stringWriter.write((char)k);
		}
		//stringReader.skip(5);
		//stringReader.read(charArray);
     
		StringBuffer buffer=stringWriter.getBuffer();
		buffer.getChars(0, buffer.length(),charArray, 0);
	    System.out.println(charArray);
		
		
	}

}
