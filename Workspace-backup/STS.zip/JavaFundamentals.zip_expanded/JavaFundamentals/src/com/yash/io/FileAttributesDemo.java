package com.yash.io;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileStore;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.DosFileAttributes;
import java.nio.file.attribute.FileTime;
import java.time.LocalDateTime;

public class FileAttributesDemo {

	public static void main(String[] args) throws IOException {

		//IO
		File file=new File("D:\\javainductionio");
		System.out.println("Whether path given is a directory?:"+file.isDirectory());
		
		File file1=new File("D:\\javainductionio\\File1.txt");
		if(file1.exists()) {
			System.out.println("Size:"+file1.length());
			System.out.println("is file writable ?:"+file1.canWrite());
			System.out.println("Whether path given is a directory?:"+file1.isDirectory());
			System.out.println("Whether path given is a file?:"+file1.isFile());
            System.out.println("Whether path is absolute?:"+file1.isAbsolute());
		}
		
		//NIO
		
		Path path1=Paths.get("D:\\\\javainductionio\\\\File1.txt");
		System.out.println("Contains Name:"+path1.getNameCount());
		System.out.println("Whether endswith file1.txt?:"+path1.endsWith("File1.txt"));
		System.out.println("File Name:"+path1.getFileName());
		
		Path path2=Paths.get("D:\\\\javainductionio\\\\File1.txt");
		
		System.out.println("Whether two path are same?:"+path1.equals(path2));
		
		Path basePath=Paths.get("/javainductionio");
		
		Path path=Paths.get("/javainductionio/data1/datadata/file1.txt");
		
		System.out.println("Relativize:"+basePath.relativize(path));
		
		String originalPath="d:\\javainductionio\\teams\\teamA\\..\\teamB";
		Path pathOriginal=Paths.get(originalPath);
		System.out.println("Original path:"+originalPath);
		
		Path teamB=pathOriginal.normalize();
		System.out.println("teamB path:"+teamB);
		
		
		//NIO file attributes
		Path filePath=Paths.get("d:\\javainductionio\\File1.txt");
		DosFileAttributes attributes=Files.readAttributes(filePath,DosFileAttributes.class,LinkOption.NOFOLLOW_LINKS);
		System.out.println("Whether file is ready-only?:"+attributes.isReadOnly());
		System.out.println("Is a system file:"+attributes.isSystem());
		System.out.println("Is it a symbolic link?:"+attributes.isSymbolicLink());
		
		//IO
		
		File file2Path=new File("d:\\javainductionio\\File2.txt");
		if(!file2Path.exists())
		file2Path.createNewFile();
		
		//NIO
		
		Path file3Path=Paths.get("d:\\javainductionio\\File3.txt");
		//Files.createFile(file3Path);
		

		FileSystem fileSystem=FileSystems.getDefault();

		Iterable<FileStore> stores=fileSystem.getFileStores();
		for(FileStore store:stores) {
			System.out.println("Drive name:"+store.name());
			System.out.println("Free space:"+store.getUnallocatedSpace());
		    System.out.println("Total space:"+store.getTotalSpace());
		    System.out.println("Usable space:"+store.getUsableSpace());
		}
		
		Path folderPath=Paths.get("d:\\javainductionio");
		BasicFileAttributes attributesFolder=Files.readAttributes(folderPath,BasicFileAttributes.class,LinkOption.NOFOLLOW_LINKS);
		
		System.out.println(Files.size(folderPath));
		attributesFolder.creationTime();
		System.out.println("Size of folder:"+attributesFolder.size());
		
		long size=Files.walk(new File("D:\\javainductionio").toPath())
		.map(f->f.toFile())
		.filter(f->f.isFile())
		.mapToLong(f->f.length()).sum();
		System.out.println(size);
		
		Path pathOfFile1=Paths.get("D:\\javainductionio\\File1.txt");
		Files.setAttribute(pathOfFile1,"basic:creationTime",FileTime.fromMillis(System.currentTimeMillis())
				,LinkOption.NOFOLLOW_LINKS);

	}

}
