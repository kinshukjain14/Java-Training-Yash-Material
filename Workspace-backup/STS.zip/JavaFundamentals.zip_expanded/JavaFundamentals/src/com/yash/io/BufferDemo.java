package com.yash.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class BufferDemo {

	public static void main(String[] args) throws IOException {

		//Java IO
		
		try(
			InputStream inputbinaryStream=new FileInputStream("D:\\javainductionio\\BufferFile.txt");
		    OutputStream outputbinaryStream=new FileOutputStream("D:\\javainductionio\\BufferWriteFile.txt");

			BufferedInputStream bufferIn=new BufferedInputStream(inputbinaryStream);
		    BufferedOutputStream bufferOut=new BufferedOutputStream(outputbinaryStream);

			){
			int k=0;
			while((k=bufferIn.read())!=-1) {
				bufferOut.write(k);
			}
			
		}catch(IOException e) {
			System.err.println("Error processing");
		}
				
		//NIO
		
		RandomAccessFile rafRead=new RandomAccessFile("D:\\javainductionio\\BufferFile.txt","rw");
		FileChannel readChannel=rafRead.getChannel();
		
		RandomAccessFile rafWrite=new RandomAccessFile("D:\\javainductionio\\BufferWriteChannelFile.txt","rw");
		rafWrite.seek(10);
		FileChannel writeChannel=rafWrite.getChannel();
		
		ByteBuffer bufferIn=ByteBuffer.allocate(1024);
		ByteBuffer bufferOut=ByteBuffer.allocate(1024);
		while(readChannel.read(bufferIn)>0) {			
			bufferIn.flip();
			for(int i=0;i<bufferIn.limit();i++) {
				bufferOut.put(bufferIn.get(i));
			}
			bufferOut.flip();
			bufferIn.clear();

		}		
		writeChannel.write(bufferOut);
		rafRead.close();
		rafWrite.close();

		
		
		
	}

}
