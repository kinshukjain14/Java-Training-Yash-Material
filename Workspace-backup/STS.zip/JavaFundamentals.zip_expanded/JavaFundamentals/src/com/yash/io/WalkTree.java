package com.yash.io;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class WalkTree {

	public static void main(String[] args) throws IOException {

		
		//IO
		
		File file=new File("D:\\javainductionio");
		File[] allTextFiles=file.listFiles(new FileFilter() {
			@Override
			public boolean accept(File pathname) {
             if(pathname.getName().endsWith("txt")) {
            	 return true;
             }
				return false;
			}
		});
		for(File txtFile:allTextFiles) {
			System.out.println(txtFile);
		}
		
		//NIO
		Path path=Paths.get("D:\\javainductionio");
		Files.walkFileTree(path,new FileVistorDemo());
		
		
	}

}
