package com.yash.io;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.jar.JarEntry;
import java.util.jar.JarOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class CreateJarFile {

	public static void main(String[] args) {

		try(
				InputStream is=new FileInputStream("D:\\javainductionio\\HelloWorld.class");
				OutputStream os=new FileOutputStream("D:\\javainductionio\\Sample.jar");
				JarOutputStream jar=new JarOutputStream(os);
			  ){
				JarEntry zipEntry=new JarEntry("HelloWorld.class");
				jar.putNextEntry(zipEntry);
				byte[] buffer=new byte[1024];
				int k;
				while((k=is.read(buffer))>0) {
					jar.write(buffer,0,k);
				}
				jar.closeEntry();
			}catch(IOException e) {
				System.err.println("--Error--");
			}
		}
	}


