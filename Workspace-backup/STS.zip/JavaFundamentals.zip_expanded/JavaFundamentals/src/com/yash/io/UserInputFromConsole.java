package com.yash.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.yash.serialization.Employee;

public class UserInputFromConsole {

	public static void main(String[] args) {
		Employee e=new Employee();
		try(
		  InputStreamReader ir=new InputStreamReader(System.in);
		  BufferedReader br=new BufferedReader(ir);
		 ){
			
			System.out.print("Employee Id:");
			int empId=Integer.parseInt(br.readLine());
			e.setEmpId(empId);
			
			System.out.print("Employee Name:");
			String empName=br.readLine();
			e.setEmpName(empName);
			
			System.out.print("Employee Salary:");
			double empSalary=Double.parseDouble(br.readLine());
			e.setEmpSalary(empSalary);
			
			System.out.print("Employee Designation:");
			String empDesignation=br.readLine();
			e.setEmpDesignation(empDesignation);
			
			
		}catch(IOException ex) {
			System.err.println("--Error Processing--");
		}
		System.out.println(e);
	}

}
