package com.yash.methodoverloading;
import static java.lang.System.out;

public class MethodOverloadingDemo {

	public static void main(String[] args) {

		Calculator calculator=new Calculator();
		int sumTwoInt=calculator.add(10, 20);
		out.println(sumTwoInt);
		
		int sumThreeInt=calculator.add(10, 20,30);
		out.println(sumThreeInt);
		
		float sumTwoFloat=calculator.add(10.5f, 11.2f);
		out.println(sumTwoFloat);
		
		int i=2;
		double squareI=calculator.square(i);
		out.println(squareI);
		
		float f=2.3f;
		double squareF=calculator.square(f);
		out.println(squareF);

		int j=10;
		double d=j;
		
	 double no=34.78;
	 int add2Int=calculator.add2((int)no);
		out.println(add2Int);
		
		int randomNumber=(int)(Math.random()*1000);
		System.out.println("Random number is:"+randomNumber);
		

		int[] args1= {3,4,1,2,6};
		int sum1=calculator.sum(args1);
		System.out.println("Sum1:"+sum1);
		
		int sum2=calculator.sum(new int[] {12,45,67,9});
		out.println("sum2:"+sum2);
		
		double product1=calculator.product(10,20,30);
		System.out.println("product1:"+product1);
		
		double product2=calculator.product(10,20,30,40,50,60);
		System.out.println("product2:"+product2);
		
		double product3=calculator.product(10,20);
		System.out.println("product3:"+product3);
	}

}
