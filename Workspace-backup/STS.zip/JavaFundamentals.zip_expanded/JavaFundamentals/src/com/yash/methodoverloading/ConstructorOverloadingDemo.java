package com.yash.methodoverloading;

public class ConstructorOverloadingDemo {

	public static void main(String[] args) {

		Box box=new Box();
		System.out.println("Area :"+box.area());
		
		Box boxSquare=new Box(10);
		System.out.println("Area for Square:"+boxSquare.area());
		
		Box boxRectangle=new Box(10,20);
		System.out.println("Area for Rectangle:"+boxRectangle.area());

	}

}
