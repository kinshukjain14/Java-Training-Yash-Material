package com.yash.methodoverloading;

public class Box {
	
	private double width;
	private double height;
	
	public Box() {
		this.width=0;
		this.height=0;
	}
	
	public Box(double width) {
		this.width=width;
		this.height=width;
	}
	public Box(double width,double height) {
		this.width=width;
		this.height=height;
	}
	
	public double area() {
		return width*height;
	}

}
