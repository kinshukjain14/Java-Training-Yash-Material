package com.yash.methodoverloading;

public class ConstructorChaining {

	private String strAttribute;
	private double doubleAttribute;
	private int intAttribute;
	
	public ConstructorChaining() {
		System.out.println(" No-Arg Constructor Chaining");
	}
	
	public ConstructorChaining(String strAttribute) {
		this();
		this.strAttribute=strAttribute;
	}
	public ConstructorChaining(String strAttribute,double doubleAttribute) {
		this(strAttribute);
		this.doubleAttribute=doubleAttribute;
	}
	public ConstructorChaining(String strAttribute,double doubleAttribute,int intAttribute) {
		this(strAttribute,doubleAttribute);
		this.intAttribute=intAttribute;
	}

	public String getStrAttribute() {
		return strAttribute;
	}

	public double getDoubleAttribute() {
		return doubleAttribute;
	}

	public int getIntAttribute() {
		return intAttribute;
	}

	@Override
	public String toString() {
		return "ConstructorChaining [strAttribute=" + strAttribute + ", doubleAttribute=" + doubleAttribute
				+ ", intAttribute=" + intAttribute + "]";
	}
	
	
}
