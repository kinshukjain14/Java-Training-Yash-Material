package com.yash.methodoverloading;

public class Calculator {
	
	public int add(int no1,int no2) {
		return no1+no2;
	}
	
	public int add(int no1,int no2,int no3) {
		return no1+no2+no3;
	}
	
	public float add(float no1,float no2) {
		return no1+no2;
	}
	
	public double square(double no) {
		return no*no;
	}
	
	public int add2(int no) {
		return no+2;
	}
	
	public int sum(int[] args) {
		int sum=0;
		for(int arg:args) {
			sum+=arg;//sum=sum+arg
		}
		return sum;
	}

	//.....
/*
	public double product(double no1,double no2) {
		System.out.println("This version of product is called");
		return no1*no2;
	}*/
	public double product(double...n) {
		double product=1;
		for(double val:n) {
			product*=val;
		}
		return product;
	}
	
}
