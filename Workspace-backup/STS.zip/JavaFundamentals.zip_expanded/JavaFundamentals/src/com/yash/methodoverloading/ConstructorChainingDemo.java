package com.yash.methodoverloading;

public class ConstructorChainingDemo {

	public static void main(String[] args) {

		ConstructorChaining o=new ConstructorChaining("str",234,12);
		System.out.println(o);
		
	}

}
