package com.yash.collection;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.Properties;
import java.util.ResourceBundle;

public class PropertiesDemo {

	public static void main(String[] args) throws IOException {
		
		Properties runtimeProperties=System.getProperties();
		String runtimeHome=runtimeProperties.getProperty("java.home");
		System.out.println("JRE HOME:"+runtimeHome);
		
		String runtimeVersion=runtimeProperties.getProperty("java.version");
		System.out.println("JRE Version:"+runtimeVersion);
		
		Properties properties=new Properties();
		properties.setProperty("driver", "com.mysql.jdbc.Driver");
		properties.setProperty("url", "jdbc:mysql://localhost:3306/test");
		properties.setProperty("username", "root");
		properties.setProperty("password", "root");
		
		
		System.out.println("fetch url from properties object:"+properties.getProperty("url"));
		
		String driver=System.getProperty("driver");
		String url=System.getProperty("url");

		String username=System.getProperty("username");
		String password=System.getProperty("password");
		
		System.out.println("driver:"+driver);
		System.out.println("url:"+url);
		System.out.println("username:"+username);
		System.out.println("password:"+password);
		
		InputStream is=new FileInputStream("D:\\javainductionfile\\db.properties");
		Properties fromFileProperties=new Properties();
		fromFileProperties.load(is);
		
		System.out.println("from file driver:"+fromFileProperties.getProperty("driver"));
		System.out.println("from file url:"+fromFileProperties.getProperty("url"));
		System.out.println("from file username:"+fromFileProperties.getProperty("username"));
		System.out.println("from file password:"+fromFileProperties.getProperty("password"));

		
		
	}

}
