package com.yash.collection;

import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo {

	public static void main(String[] args) {

		//hetereogenous collection
		List list=new ArrayList();//Object[] elementData=new Object[10]
		list.add(10);//internally autoboxing//implicitly upcasting
		list.add("sabbir");
		list.add(12f);
		
		for(Object o:list) {
			if(o instanceof Integer) {
			Integer intObject=(Integer)o;
			System.out.println(intObject);
			}
			if(o instanceof String) {
				String strObject=(String)o;
				System.out.println(strObject);
				}
			if(o instanceof Float) {
				Float floatObject=(Float)o;
				System.out.println(floatObject);
				}
			
		}
		System.out.println("=================");
		
		//Homogenous Collection
		List<String> listString=new ArrayList<>();
		listString.add("sabbir");
		listString.add("Amit");
		listString.add("Chetan");
		
		for(int i=0;i<listString.size();i++) {
			System.out.println(listString.get(i));
		}
		
		List<Integer> integerList=new ArrayList<>();
		//integerList.get(0);//IndexOutOfBoundsException
		
		List<Integer> customizedCapacityList=new ArrayList<>(3);
		customizedCapacityList.add(10);
		customizedCapacityList.add(20);
		customizedCapacityList.add(30);
		
		System.out.println("Size:"+customizedCapacityList.size());

		customizedCapacityList.add(40);
		
		for(Integer o:customizedCapacityList) {
			System.out.println(o);
		}
		
		List<Float> floatList=new ArrayList<>();
		floatList.add(0, 12.4f);
		floatList.add(1, 3.4f);
		floatList.add(2, 18.4f);
		
		for(Float f:floatList) {
			System.out.println(f);
		}
		
		List<String> names1=new ArrayList<>();
		names1.add("Sabbir");
		names1.add("Amit");
		names1.add("Sumeet");
		
		if(names1.contains("Sumeet")) {
			System.out.println("Sumeet is present");
		}
		
		List<List<String>> mainList=new ArrayList<>();
		
		List<String> subList1=new ArrayList<>();
		
		subList1.add("sabbir");
		subList1.add("amit");
		subList1.add("rohit");
		subList1.add("rakesh");
		
       List<String> subList2=new ArrayList<>();
		
		subList2.add("Pune");
		subList2.add("Mumbai");
		subList2.add("Bengaluru");
		subList2.add("Chennai");
		
		mainList.add(subList1);
		mainList.add(subList2);
		
		for(List<String> sublist:mainList) {
			for(String o:sublist) {
				System.out.println(o);
			}
		}
		
		List<Double> doubleList=new ArrayList<>();
		
		if(!doubleList.isEmpty()) {
			doubleList.get(0);
		}
		
		
	}

}
