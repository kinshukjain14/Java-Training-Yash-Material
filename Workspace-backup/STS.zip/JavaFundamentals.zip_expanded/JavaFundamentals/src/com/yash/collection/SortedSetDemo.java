package com.yash.collection;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

public class SortedSetDemo {

	public static void main(String[] args) {

		SortedSet<String> countryNames=new TreeSet<>();
		countryNames.add("India");
		countryNames.add("China");
		countryNames.add("Russia");
		countryNames.add("Taiwan");
		
		for(String countryName:countryNames) {
			System.out.println(countryName);
		}
		
		Employee e1=new Employee();
		e1.setEmpId(1001);
		e1.setEmpName("Sabbir");
		e1.setEmpSalary(34000);
		e1.setEmpDesignation("Trainer");
		
		Employee e2=new Employee();
		e2.setEmpId(1007);
		e2.setEmpName("Rohit");
		e2.setEmpSalary(14000);
		e2.setEmpDesignation("Programmer");
		
		Employee e3=new Employee();
		e3.setEmpId(1005);
		e3.setEmpName("Manish");
		e3.setEmpSalary(74000);
		e3.setEmpDesignation("Accountant");
		
		SortedSet<Employee> employeesSet=new TreeSet<>();
		employeesSet.add(e1);
		employeesSet.add(e2);
		employeesSet.add(e3);
		
		System.out.println("=====default sorting of SortedSet=================");
		for(Employee employee:employeesSet) {
			System.out.println(employee);
		}

		
		Employee[] employees=new Employee[employeesSet.size()];
		Employee[] employeesArray=employeesSet.toArray(employees);
		List<Employee> employeesList=Arrays.asList(employeesArray);
		
		Collections.sort(employeesList,new Comparator<Employee>() {
			@Override
			public int compare(Employee o1, Employee o2) {
				// TODO Auto-generated method stub
				return o1.getEmpName().compareTo(o2.getEmpName());
			}
		});
		System.out.println("=====sorted based on Name=================");
		for(Employee employee:employeesList) {
			System.out.println(employee);
		}
		
	}

}
