package com.yash.collection;

public class Student implements Comparable<Student>{
	
	private int rollNo;
	private String studentName;
	private double fees;
	
	public int getRollNo() {
		return rollNo;
	}
	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", studentName=" + studentName + ", fees=" + fees + "]";
	}
	@Override
	public int compareTo(Student o) {
		if(this.rollNo>o.rollNo) {
			return 1;
		}else if(this.rollNo<o.rollNo) {
			return -1;
		}else {
		return 0;
		}
	}
	
	
	
	

}
