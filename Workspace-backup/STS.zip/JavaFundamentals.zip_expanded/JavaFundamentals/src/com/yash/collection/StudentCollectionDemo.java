package com.yash.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class StudentCollectionDemo {
	
	
	class SortStudentBasedOnName implements Comparator<Student>{
		@Override
		public int compare(Student o1, Student o2) {
			return o1.getStudentName().compareTo(o2.getStudentName());
		}
	
	}

	public static void main(String[] args) {


		List<Student> listOfStudent=new ArrayList<>();
		try(Scanner scanner=new Scanner(System.in)){
			
			for(int i=1;i<=3;i++) {
				System.out.println("============Record:"+i+"===========");
				System.out.print("Roll No:");
				int rollNo=scanner.nextInt();
				System.out.print("Student Name:");
				String studentName=scanner.next();
				System.out.print("fees:");
				double fees=scanner.nextDouble();
				Student student=new Student();
				student.setRollNo(rollNo);
				student.setStudentName(studentName);
				student.setFees(fees);
				listOfStudent.add(student);
				System.out.println("=======================");
				
			}
			
		}catch(InputMismatchException e) {
			System.err.println("--Error processing please try again later--");
		}
		
		System.out.println("--data entered by user --");
		for(Student student:listOfStudent) {
			System.out.println(student);
		}
		
		
		Collections.sort(listOfStudent);
		
		System.out.println("--data sorted based on roll no--");

		for(Student student:listOfStudent) {
			System.out.println(student);
		}

		System.out.println("--data sorted based on student name--");
		Collections.sort(listOfStudent, new StudentCollectionDemo().new SortStudentBasedOnName());
		
		for(Student student:listOfStudent) {
			System.out.println(student);
		}
		
		System.out.println("--data sorted based on student fees--");
		Collections.sort(listOfStudent,new Comparator<Student>() {
			@Override
			public int compare(Student o1, Student o2) {
               if(o1.getFees()>o2.getFees()) {
            	   return 1;
               }else if(o1.getFees()<o2.getFees()) {
            	   return -1;
               }else {
				return 0;
               }
			}	
		});
		
		for(Student student:listOfStudent) {
			System.out.println(student);
		}

	}

}
