package com.yash.collection;

import java.util.Deque;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class LinkedListDemo {

	public static void main(String[] args) {

		List<String> listImplementation=new LinkedList<String>();
		
		Deque<String> listdequeImplementation=new LinkedList<String>();
		
		LinkedList<String> linkedList=new LinkedList<String>();
		linkedList.add("sabbir");
		linkedList.addFirst("amit");
		linkedList.add("chintan");
		linkedList.addLast("rohit");

		
		for(String strObj:linkedList) {
			System.out.println("From LinkedList:"+strObj);
		}
		
		Iterator<String> iterator1=linkedList.iterator();
		while(iterator1.hasNext()) {
			
			System.out.println("Element from LinkedList:"+iterator1.next());
		}
	
		for(Iterator<String> iterator2=linkedList.iterator();iterator2.hasNext();) {
			System.out.println("Using for loop:"+iterator2.next());
		}
		
		linkedList.remove("rohit");
		

		for(String strObj:linkedList) {
			System.out.println("From LinkedList:"+strObj);
		}
		
 
	}

}
