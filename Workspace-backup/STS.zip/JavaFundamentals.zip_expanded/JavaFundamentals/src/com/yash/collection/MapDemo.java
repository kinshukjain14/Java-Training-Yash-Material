package com.yash.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {

		Map<Integer,String> mapOfNames=new HashMap<>();
		System.out.println(mapOfNames.put(1, "Sabbir"));
		System.out.println(mapOfNames.put(2, "Amit"));
		System.out.println(mapOfNames.put(1, "Rohit"));
		System.out.println(mapOfNames);
		
		Set<Map.Entry<Integer,String>> allEntries=mapOfNames.entrySet();
		Iterator<Map.Entry<Integer,String>> iterator=allEntries.iterator();
		while(iterator.hasNext()) {
			Map.Entry<Integer,String> me=iterator.next();
			System.out.println("Key:"+me.getKey());
			System.out.println("Value:"+me.getValue());
		}
		
		Set<Integer> onlyKeys=mapOfNames.keySet();
		Iterator<Integer> iteratorOfKeys=onlyKeys.iterator();
		while(iteratorOfKeys.hasNext()) {
			Integer key=iteratorOfKeys.next();
			System.out.println("Key:"+key);
		}


	}

}
