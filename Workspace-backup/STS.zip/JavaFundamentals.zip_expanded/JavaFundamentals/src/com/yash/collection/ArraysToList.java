package com.yash.collection;

import java.util.Arrays;
import java.util.List;

public class ArraysToList {

	public static void main(String[] args) {

		String[] names=new String[] {"Sabbir","Amit","Sumeet","Rohit"};
		
		List<String> listOfNames=Arrays.asList(names);
		for(String name:listOfNames) {
			System.out.println(name);
		}
		
		
	}

}
