package com.yash.collection;

import java.util.SortedMap;
import java.util.TreeMap;

public class SortedMapDemo {

	public static void main(String[] args) {

		SortedMap<Integer,String> sortedMap=new TreeMap<>();
		sortedMap.put(3, "Rohit");
		sortedMap.put(2, "Amit");
		sortedMap.put(4, "Rachit");
		sortedMap.put(1, "Roshan");
		
		System.out.println(sortedMap);
	}

}
