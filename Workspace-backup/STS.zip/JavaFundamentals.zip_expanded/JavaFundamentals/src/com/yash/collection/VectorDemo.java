package com.yash.collection;

import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;

public class VectorDemo {

	public static void main(String[] args) {

		Vector<Integer> vectorOfInteger=new Vector<Integer>();
		vectorOfInteger.addElement(10);
		vectorOfInteger.addElement(20);
		vectorOfInteger.addElement(30);
		
		for(Integer o: vectorOfInteger) {
			System.out.println(o);
		}
		System.out.println("Element at index 0:"+vectorOfInteger.get(0));
		
		Enumeration<Integer> enumeration=vectorOfInteger.elements();
		while(enumeration.hasMoreElements()) {
			System.out.println(enumeration.nextElement());
		}
	
	}

}
