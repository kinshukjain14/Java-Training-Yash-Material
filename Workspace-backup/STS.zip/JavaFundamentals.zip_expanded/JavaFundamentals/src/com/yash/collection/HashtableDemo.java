package com.yash.collection;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class HashtableDemo {

	public static void main(String[] args) {

		Hashtable<Integer,String> studentTable=new Hashtable<>();
		studentTable.put(1, "amit");
		studentTable.put(2, "chintan");
		studentTable.put(3, "rakesh");
		studentTable.put(4, "rohit");
		
		Enumeration<String> enumeration=studentTable.elements();
		while(enumeration.hasMoreElements()) {
			System.out.println(enumeration.nextElement());
		}
		
		Set<Entry<Integer,String>> setOfEntries=studentTable.entrySet();
		Iterator<Entry<Integer,String>> iterator=setOfEntries.iterator();
		while(iterator.hasNext()) {
			Entry<Integer,String> entry=iterator.next();
			//System.out.println("Key:"+entry.getKey());
			if(entry.getKey()==2)
			System.out.println("Value:"+entry.getValue());
		}
		
		
	}

}
