package com.yash.collection;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.PriorityQueue;

public class QueueDemo {

	public static void main(String[] args) {

		Deque<Integer> deck1=new ArrayDeque<>();
		deck1.add(10);
		deck1.add(20);
		deck1.add(30);
		System.out.println("=============Dequeu FIFO========");

		for(Integer o:deck1) {
			System.out.println(o);
		}
		Deque<Integer> deck2=new ArrayDeque<>();
		deck2.push(10);
		deck2.push(20);
		deck2.push(30);
		System.out.println("=============Dequeu LIFO========");
		for(Integer o:deck2) {
			System.out.println(o);
		}
		
		
		PriorityQueue<Integer> priorityQueue=new PriorityQueue<>();
		priorityQueue.add(10);
		priorityQueue.add(5);
		priorityQueue.add(20);
		System.out.println("=============priority queue integer========");
		System.out.println(priorityQueue.peek());
		System.out.println(priorityQueue.poll());
		System.out.println(priorityQueue.poll());
		
		PriorityQueue<Character> priorityQueueChar=new PriorityQueue<>();
		priorityQueueChar.add('e');
		priorityQueueChar.add('c');
		priorityQueueChar.add('a');
		System.out.println("=============priority queue character========");
		System.out.println(priorityQueueChar.peek());
		System.out.println(priorityQueueChar.poll());
		System.out.println(priorityQueueChar.poll());


		
		

		
	}

}
