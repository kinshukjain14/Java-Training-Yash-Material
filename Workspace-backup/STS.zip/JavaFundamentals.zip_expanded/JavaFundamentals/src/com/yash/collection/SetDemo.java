package com.yash.collection;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class SetDemo {

	public static void main(String[] args) {
		Set<String> setOfCityNames=new HashSet<>();
		setOfCityNames.add("Chennai");
		setOfCityNames.add("Mumbai");
		setOfCityNames.add("Benguluru");
		setOfCityNames.add("Pune");
		
		if(setOfCityNames.contains("Pune")) {
			System.out.println("Pune is present");
		}
		
		for(String cityName:setOfCityNames) {
			System.out.println(cityName);
		}
		
		for(Iterator<String> iterator=setOfCityNames.iterator();iterator.hasNext();) {
			System.out.println(iterator.next());
		}
		
	}

}
