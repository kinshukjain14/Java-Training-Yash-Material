package com.yash.collection;

public class AutoBoxingAutoUnboxingDemo {

	public static void main(String[] args) {

		int i=10;
		//boxing
		Integer o=new Integer(i);
		//unboxing
		i=o.intValue();
		
		//Java 5
		
		//Autoboxing
		Integer o1=i;//Integer o1=new Integer(i)
		
		//Autounboxing
		i=o1;//o1.intValue()
		
		
		
	}

}
