package com.yash.collection;

import java.util.Arrays;

public class ArrayCopy {

	public static void main(String[] args) {

		char[] oldArray= {'a','e','t','p'};//4

		System.out.println(oldArray);
		
		char[] newArray=new char[oldArray.length+1];//5
		
		System.arraycopy(oldArray, 0, newArray, 0, newArray.length-1);
		
		
		char[] newArray1=Arrays.copyOf(oldArray,oldArray.length+2);
		
		newArray1[4]='m';
		newArray1[5]='g';
		System.out.println(newArray1);


	}

}
