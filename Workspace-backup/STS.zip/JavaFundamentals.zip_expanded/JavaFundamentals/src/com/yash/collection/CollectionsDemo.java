package com.yash.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollectionsDemo {

	public static void main(String[] args) {

		List<Integer> integerList=new ArrayList<>();
		integerList.add(23);
		integerList.add(13);
		integerList.add(68);
		integerList.add(17);
		
		Collections.sort(integerList);
		for(Integer o:integerList) {
			System.out.println(o);
		}
		
		List<String> stringList=new ArrayList<>();
		stringList.add("sabbir");
		stringList.add("Rakesh");
		stringList.add("sachin");
		stringList.add("chintan");
		
		Collections.sort(stringList);
		
		for(String o:stringList) {
			System.out.println(o);
		}
		
		List<Double> doubleList=new ArrayList<>();
		doubleList.add(23.4d);
		doubleList.add(21000d);
		doubleList.add(34000d);
		
		List<Double> unModifiableList=Collections.unmodifiableList(doubleList);
		unModifiableList.add(32000d);
		unModifiableList.set(1,22000d);
		for(Double d:doubleList) {
			System.out.println(d);
		}
		
		
		
	}

}
