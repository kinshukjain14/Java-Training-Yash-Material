package com.yash.collection;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetDemo {

	public static void main(String[] args) {

		Set<String> ordersSet=new HashSet<>();
		ordersSet.add("ODR1");
		ordersSet.add("ODR4");
		ordersSet.add("ODR2");
		ordersSet.add("ODR3");
		
		System.out.println("==================hash set=================");
		for(String order:ordersSet) {
			System.out.println(order);
		}
		
		LinkedHashSet<String> orders=new LinkedHashSet<>();
		orders.add("ODR1");
		orders.add("ODR4");
		orders.add("ODR3");
		orders.add("ODR2");
		orders.add("ODR2");
		
		System.out.println("==================linked hash set=================");
		for(String order:orders) {
			System.out.println(order);
		}
	}

}
