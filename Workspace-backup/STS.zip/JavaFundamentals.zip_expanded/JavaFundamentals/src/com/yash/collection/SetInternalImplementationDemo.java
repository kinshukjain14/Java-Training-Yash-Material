package com.yash.collection;

import java.util.HashSet;
import java.util.Set;

public class SetInternalImplementationDemo {

	public static void main(String[] args) {

		Set<String> statesSet=new HashSet<>();
		System.out.println(statesSet.add("Gujarat"));
		System.out.println(statesSet.add("Gujarat"));
       
		for(String state:statesSet) {
			System.out.println(state);
		}
		
		Course course1=new Course();
		course1.setCourseId(1001);
		course1.setCourseName("Java");
		course1.setCourseDescription("Java Course");
		
		Course course2=new Course();
		course2.setCourseId(1001);
		course2.setCourseName("Java");
		course2.setCourseDescription("Java Course");
	
	    Set<Course> coursesSet=new HashSet<>();
	    System.out.println(coursesSet.add(course1));
	    System.out.println(coursesSet.add(course2));
	    
	    for(Course course:coursesSet) {
	    	System.out.println(course);
	    }
		
	}
	

}
