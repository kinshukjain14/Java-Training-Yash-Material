package com.yash.collection;

import java.util.LinkedHashMap;

public class LinkedHashMapDemo {

	public static void main(String[] args) {

		LinkedHashMap<Integer,String> linkedHashMap=new LinkedHashMap<>();
		linkedHashMap.put(1, "will always be first index pos");
		linkedHashMap.put(2, "will always be second index pos");
		linkedHashMap.put(3, "will always be third index pos");
		linkedHashMap.put(3, "duplicates not allowed for key");
		
		System.out.println(linkedHashMap);



	}

}
