package com.yash.serialization;

import java.io.Serializable;

public class BWhichIsImplementingSerilizable extends AWhichisNotImplementingSerializable implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BWhichIsImplementingSerilizable() {}
	
	private int b;

	public BWhichIsImplementingSerilizable(int a,int b) {
		super(a);
		this.b = b;
	}

	@Override
	public String toString() {
		return "BWhichIsImplementingSerilizable [b=" + b + "]";
	}
	
	

}
