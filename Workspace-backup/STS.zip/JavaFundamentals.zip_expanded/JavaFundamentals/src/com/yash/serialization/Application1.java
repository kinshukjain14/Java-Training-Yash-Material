package com.yash.serialization;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class Application1 {

	public static void main(String[] args) {

		Employee e=new Employee();
		e.setEmpId(1001);
		e.setEmpName("Sabbir");
		e.setEmpSalary(45000);
		e.setEmpDesignation("Trainer");
		
		try(
		OutputStream os=new FileOutputStream("D:\\javainductionio\\employee.ser");
		ObjectOutputStream oos=new ObjectOutputStream(os);
				
		){
			oos.writeObject(e);
			
		}catch(IOException ex) {
		 ex.printStackTrace();
		}
	}

}
