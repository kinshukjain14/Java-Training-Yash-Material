package com.yash.serialization;

import java.io.Serializable;

public class C implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected int c1;
	protected int c2;
	
	public C() {}
	
	public C(int c1, int c2) {
		super();
		this.c1 = c1;
		this.c2 = c2;
	}
	public int getC1() {
		return c1;
	}
	public int getC2() {
		return c2;
	}
	@Override
	public String toString() {
		return "C [c1=" + c1 + ", c2=" + c2 + "]";
	}
	
	

}
