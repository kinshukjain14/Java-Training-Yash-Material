package com.yash.serialization;

import java.io.Serializable;

public class Outer{
	
	public static class Inner implements Serializable{
		
		private int b;
		public Inner(int b) {
			this.b=b;
		}
		public int getB() {
			return b;
		}
		
		
		@Override
		public String toString() {
			return "Inner [b=" + b + "]";
		}
		
		
	}
	

}
