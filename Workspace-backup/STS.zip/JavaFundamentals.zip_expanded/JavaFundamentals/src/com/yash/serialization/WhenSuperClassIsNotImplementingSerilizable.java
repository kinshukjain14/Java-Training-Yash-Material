package com.yash.serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class WhenSuperClassIsNotImplementingSerilizable {

	public static void main(String[] args) {
		//SerializationBWhichIsnotImplementingSerializable
				try(
					OutputStream os=new FileOutputStream("D:\\javainductionio\\b1.ser");
					ObjectOutputStream oos=new ObjectOutputStream(os);
				   ){
					
					BWhichIsImplementingSerilizable b=new BWhichIsImplementingSerilizable(5,10);
					oos.writeObject(b);
					
				}catch(IOException e) {
					e.printStackTrace();
				}
				
				//De-Serialization
				try(
					InputStream is=new FileInputStream("D:\\javainductionio\\b1.ser");
					ObjectInputStream ois=new ObjectInputStream(is);
				   ){
					
					BWhichIsImplementingSerilizable b=(BWhichIsImplementingSerilizable)ois.readObject();
					System.out.println(b);
					System.out.println(b.getA());
					
				}catch(IOException | ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
	}


