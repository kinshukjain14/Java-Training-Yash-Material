package com.yash.serialization;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class XMLSerializationDeserialization {

	public static void main(String[] args) throws JAXBException, FileNotFoundException {

		Employee e1=new Employee();
		e1.setEmpId(1001);
		e1.setEmpName("Rohit");
		e1.setEmpSalary(45000);
		e1.setEmpDesignation("Trainer");
		
		Employee e2=new Employee();
		e2.setEmpId(1002);
		e2.setEmpName("Rohit");
		e2.setEmpSalary(25000);
		e2.setEmpDesignation("Developer");
		List<Employee> empList=new ArrayList<>();
		empList.add(e1);
		empList.add(e2);
		
		Company company=new Company();
		company.setCompanyName("Yash Technologies");
		company.setEmployees(empList);
		
		JAXBContext context=JAXBContext.newInstance(Company.class);
		Marshaller marshaller=context.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		marshaller.marshal(company, new File("D:\\javainductionio\\company.xml"));
		
		Unmarshaller unmarshaller=context.createUnmarshaller();
		InputStream is=new FileInputStream("D:\\javainductionio\\company.xml");
		Company companyDeserialized=(Company)unmarshaller.unmarshal(is);
		System.out.println(companyDeserialized);
		
		
	}

}
