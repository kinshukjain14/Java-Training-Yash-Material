package com.yash.serialization;

public class AWhichisNotImplementingSerializable {

	public AWhichisNotImplementingSerializable() {}
	
	private int a;

	public AWhichisNotImplementingSerializable(int a) {
		super();
		this.a = a;
	}

	public int getA() {
		return a;
	}

	@Override
	public String toString() {
		return "AWhichisNotImplementingSerializable [a=" + a + "]";
	}
	
	
}
