package com.yash.serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class ExternalizeD {

	public static void main(String[] args) {

		try(
				OutputStream os=new FileOutputStream("D:\\javainductionio\\externalizeD.ser");	
				ObjectOutputStream oos=new ObjectOutputStream(os);
				){
				D d=new D(10,20,5,6);
				oos.writeObject(d);
			}catch(IOException e) {
				e.printStackTrace();
			}
		try(
				InputStream is=new FileInputStream("D:\\javainductionio\\externalizeD.ser");	
				ObjectInputStream oos=new ObjectInputStream(is);
				){
				
			  D d=(D)oos.readObject();
			  System.out.println("C1:"+d.c1);
			  System.out.println("C2:"+d.c2);
              System.out.println(d);
		}catch(IOException | ClassNotFoundException e) {
				e.printStackTrace();
			}
	}

}
