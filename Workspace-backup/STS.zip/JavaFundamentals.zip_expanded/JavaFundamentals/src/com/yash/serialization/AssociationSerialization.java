package com.yash.serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class AssociationSerialization {

	public static void main(String[] args) {

		//Serialization
				try(
					OutputStream os=new FileOutputStream("D:\\javainductionio\\employeeDetails.ser");
					ObjectOutputStream oos=new ObjectOutputStream(os);
				   ){
					
                   Project p1=new Project();
                   p1.setProjectId(1001);
                   p1.setProjectName("JD");
                   EmployeeDetails employeeDetails=new EmployeeDetails();
                   employeeDetails.setEmpId(1);
                   employeeDetails.setFirstName("Amit");
                   employeeDetails.setLastName("Shah");
				   employeeDetails.setProject(p1);
					oos.writeObject(employeeDetails);
					
				}catch(IOException e) {
					e.printStackTrace();
				}
				
				//De-Serialization
				try(
					InputStream is=new FileInputStream("D:\\javainductionio\\employeeDetails.ser");
					ObjectInputStream ois=new ObjectInputStream(is);
				   ){
					
					EmployeeDetails employeeDetails=(EmployeeDetails)ois.readObject();
					System.out.println(employeeDetails);
					
				}catch(IOException | ClassNotFoundException e) {
					e.printStackTrace();
				}
			}
	}


