package com.yash.serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class AnnoymousSerialization {

	public static void main(String[] args) {

		Intf refAnnoymous=new Intf() {
			@Override
			public void x() {

				System.out.println("--x--");
			}	
		};
		
		try(
			OutputStream os=new FileOutputStream("D:\\javainductionio\\annoymous.ser");	
			ObjectOutputStream oos=new ObjectOutputStream(os);
			){
			
			oos.writeObject(refAnnoymous);
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		try(
				InputStream is=new FileInputStream("D:\\javainductionio\\annoymous.ser");	
				ObjectInputStream oos=new ObjectInputStream(is);
				){
				
			  Intf intf=(Intf)oos.readObject();
			  intf.x();
			}catch(IOException | ClassNotFoundException e) {
				e.printStackTrace();
			}
		
	}

}
