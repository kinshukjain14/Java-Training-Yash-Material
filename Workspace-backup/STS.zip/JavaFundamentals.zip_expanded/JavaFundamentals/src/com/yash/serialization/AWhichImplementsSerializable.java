package com.yash.serialization;

import java.io.Serializable;

public class AWhichImplementsSerializable implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int a;

	public AWhichImplementsSerializable() {}
	
	public AWhichImplementsSerializable(int a) {
		super();
		this.a = a;
	}

	public int getA() {
		return a;
	}

	@Override
	public String toString() {
		return "AWhichImplementsSerializable [a=" + a + "]";
	}
	

}
