package com.yash.serialization;

import java.io.Serializable;

public class EmployeeDetails implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int empId;
	private String firstName;
	private String lastName;
	
	private Project project;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [empId=" + empId + ", firstName=" + firstName + ", lastName=" + lastName + ", project="
				+ project + "]";
	}
	

}
