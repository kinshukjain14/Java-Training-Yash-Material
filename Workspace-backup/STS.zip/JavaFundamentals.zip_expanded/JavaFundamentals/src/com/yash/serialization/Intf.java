package com.yash.serialization;

import java.io.Serializable;

public interface Intf extends Serializable {

	public void x();
}
