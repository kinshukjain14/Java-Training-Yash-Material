package com.yash.serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class WhenSuperClassImplementsSerializable {

	public static void main(String[] args) {

		//Serialization
		try(
			OutputStream os=new FileOutputStream("D:\\javainductionio\\b.ser");
			ObjectOutputStream oos=new ObjectOutputStream(os);
		   ){
			
			BWhichIsnotImplementingSerializable b=new BWhichIsnotImplementingSerializable(5,10);
			oos.writeObject(b);
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		//De-Serialization
		try(
			InputStream is=new FileInputStream("D:\\javainductionio\\b.ser");
			ObjectInputStream ois=new ObjectInputStream(is);
		   ){
			
			BWhichIsnotImplementingSerializable b=(BWhichIsnotImplementingSerializable)ois.readObject();
			System.out.println(b);
			System.out.println(b.getA());
			
		}catch(IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
