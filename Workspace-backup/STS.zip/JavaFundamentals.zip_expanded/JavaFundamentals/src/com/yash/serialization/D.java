package com.yash.serialization;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class D extends C implements Externalizable{
	
	private int d1;
	private int d2;
	
	public D() {}
	
	public D(int c1,int c2,int d1,int d2) {
		super(c1,c2);
		this.d1=d1;
		this.d2=d2;
	}

	public int getD1() {
		return d1;
	}

	public int getD2() {
		return d2;
	}

	@Override
	public void writeExternal(ObjectOutput out) throws IOException {

		out.write(this.d1);
		out.write(this.d2);
		out.write(getC1());
	}

	@Override
	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {

		this.d1=in.read();
		this.d2=in.read();
		this.c1=in.read();
	}

	@Override
	public String toString() {
		return "D [d1=" + d1 + ", d2=" + d2 + "]";
	}
	
	

}
