package com.yash.serialization;

import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class BWhichIsnotImplementingSerializable extends AWhichImplementsSerializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int b;
	
	public BWhichIsnotImplementingSerializable() {
		super();
	}
	public BWhichIsnotImplementingSerializable(int a,int b) {
		super(a);
		this.b=b;
	}
	
	public int getB() {
		return b;
	}
	@Override
	public String toString() {
		return "BWhichIsnotImplementingSerializable [b=" + b + "]";
	}
	
	//To prevent serialization of Object of Sub Classes
	/*
	private void writeObject(ObjectOutputStream out) throws IOException{
		//do nothing
	}
	
    private void readObject(ObjectInputStream out) throws IOException{
		//do nothing
	}
    */

	//To terminate serialization & deserialization of Object of Sub Classes
	
	private void writeObject(ObjectOutputStream out) throws IOException{
         throw new NotSerializableException("Serialization of b cannot be done");
	}
	
    private void readObject(ObjectInputStream out) throws IOException{
        throw new NotSerializableException("DeSerialization of b cannot be done");
	}
}
