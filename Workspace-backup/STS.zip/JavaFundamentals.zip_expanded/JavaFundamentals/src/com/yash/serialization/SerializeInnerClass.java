package com.yash.serialization;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
public class SerializeInnerClass {

	public static void main(String[] args) {

		try(
			OutputStream os=new FileOutputStream("D:\\javainductionio\\inner.ser");	
			ObjectOutputStream oos=new ObjectOutputStream(os);
		  ){
			
			//Outer outer=new Outer();
			//Outer.Inner inner=outer.new Inner(10);//non static inner class
			Outer.Inner inner=new Outer.Inner(10);//static
			oos.writeObject(inner);
			
		}catch(IOException e) {
			e.printStackTrace();
		}
		

		try(
			InputStream is=new FileInputStream("D:\\javainductionio\\inner.ser");	
			ObjectInputStream ois=new ObjectInputStream(is);
		  ){
			Outer.Inner inner=(Outer.Inner)ois.readObject();
			System.out.println(inner);
		
			
		}catch(IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

}
