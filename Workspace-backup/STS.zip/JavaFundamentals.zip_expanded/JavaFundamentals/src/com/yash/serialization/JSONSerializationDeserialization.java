package com.yash.serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

public class JSONSerializationDeserialization {

	public static void main(String[] args)  {

		try {
		Employee e1=new Employee();
		e1.setEmpId(1001);
		e1.setEmpName("Rohit");
		e1.setEmpSalary(45000);
		e1.setEmpDesignation("Trainer");
		
		Employee e2=new Employee();
		e2.setEmpId(1002);
		e2.setEmpName("Rohit");
		e2.setEmpSalary(25000);
		e2.setEmpDesignation("Developer");
		List<Employee> empList=new ArrayList<>();
		empList.add(e1);
		empList.add(e2);
		
		Company company=new Company();
		company.setCompanyName("Yash Technologies");
		company.setEmployees(empList);
		
		
		ObjectMapper mapper=new ObjectMapper();
		try {
		//mapper.writeValue(System.out, company);
		
		}catch(Exception e) {}
		finally {
			System.out.close();		}
		
		
		//serialization
		OutputStream os=new FileOutputStream("D:\\javainductionio\\employees.json");
		mapper.writeValue(os, company);
		
		InputStream is=new FileInputStream("D:\\javainductionio\\employees.json");
		Company companyFromJson=mapper.readValue(is, Company.class);
		System.out.println(companyFromJson);
		PrintStream ps=new PrintStream(System.out);
		ps.printf("Test");
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
