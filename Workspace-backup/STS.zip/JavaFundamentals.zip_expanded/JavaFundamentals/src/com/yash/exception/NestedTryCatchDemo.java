package com.yash.exception;

public class NestedTryCatchDemo {

	public static void main(String[] args) {

		System.out.println("--statement 1--");
		try {
			int arr[]= {2,4};
			arr[1]--;
			 try {
			String str=null;
			str.toUpperCase();
			//XXXX
			//XXXX
			 }catch(ArithmeticException e) {
				 //Some Log2 API 
				 e.printStackTrace();
			 }	
		}catch(ArrayIndexOutOfBoundsException | NullPointerException e) {
			e.printStackTrace();
		}
		System.out.println("--statement n--");
	}
}
