package com.yash.exception;

public class TryCatchDemo {

	public static void main(String[] args) {

		System.out.println("--statement 1--");
		try {
        int a=1;int b=0;
        int arr[]= {2,3};
        arr[0]++;
		int c=a/b;
		System.out.println("--other statements in try--"+c);
		String str=null;
		str.toUpperCase();
		}
		catch(ArrayIndexOutOfBoundsException | ArithmeticException  e) {
			e.printStackTrace();
			System.err.println(e);
		}
		catch(Exception e) {
			e.printStackTrace();
			System.err.println(e);
		}
		System.out.println("--statement n--");
	}

}
