package com.yash.exception;

public class CustomizedExceptionDemo {

	public static void main(String[] args) {

		double withdraw=4500;
		double balance=2000;
		if(withdraw>balance)
			throw new InsufficientFundException("Withdraw amount cannot be greater than balance");
		
	
		
		boolean flag=false;
		if(!flag) {
			try {
			DataOperationFailedException o=new DataOperationFailedException("data operation could not be performed resource unavailable");
			throw o;
			}catch(DataOperationFailedException e) {
				System.err.println(e.getMessage());
			}
		}
	}

}
