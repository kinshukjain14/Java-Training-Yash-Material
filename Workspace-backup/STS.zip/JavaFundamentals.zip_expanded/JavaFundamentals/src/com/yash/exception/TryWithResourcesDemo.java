package com.yash.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TryWithResourcesDemo {

	public static void main(String[] args) {

		try(Scanner scanner=new Scanner(System.in);){
			System.out.print("Please Enter Age:");
			int age=scanner.nextInt();
			int doubleAge=age*2;
			System.out.println("Double of your age is :"+doubleAge);
		}catch(InputMismatchException e) {
			System.err.println("Age is incorrect");
			Throwable[] allExceptions=e.getSuppressed();
			for(Throwable exception:allExceptions) {
				System.out.println(exception);
            	}
		}
	}

}
