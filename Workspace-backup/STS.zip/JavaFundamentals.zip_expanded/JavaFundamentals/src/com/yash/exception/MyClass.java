package com.yash.exception;

public class MyClass {

	private MyClass() {}
	
	public void x() {
		System.out.println("--x--");
	}
}
