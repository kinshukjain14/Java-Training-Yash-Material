package com.yash.exception;

public class WrappedExceptionDemo {
	//Framework
	public Object createObject(String className) throws WrapperException {
		//internally using JSE API which throws checked exception
		Class classData;
		Object retObject=null;
		try {
			classData = Class.forName(className);
			retObject= classData.newInstance();
		}
		catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			//wrapping checkedException into uncheckedException
        throw new WrapperException("Framework failed to create object ",e);
		}
		return retObject;
	}

	public static void main(String args[]) {
		
			WrappedExceptionDemo o=new WrappedExceptionDemo();
			try {
			MyClass myclass=(MyClass)o.createObject("com.yash.exception.MyClass");
			myclass.x();
			}catch(WrapperException e) {
				System.err.println(e.getMessage());
				System.err.println(e.getCause());
			}
		System.out.println("--executed--");
	}
}
