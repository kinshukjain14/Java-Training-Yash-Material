package com.yash.exception;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExplicitCloseResourceUsingFinally {

	public static void main(String[] args) {
		Scanner scanner=null;
		try {
		scanner=new Scanner(System.in);
		System.out.print("Please Enter Age:");
		int age=scanner.nextInt();
		int ageAfterOneYear=age+1;
		System.out.print("Age after one year:"+ageAfterOneYear);
	}catch(InputMismatchException e) {
		System.err.println("Age entered is not appropriate");
	}finally {
		scanner.close();
		System.out.println("--finally--");
	}

		

}
	

}
