package com.yash.exception;

public class FinallyDemo {

	public static void main(String[] args) {

		try {
			int a=1;int b=1;
			System.out.println("--Before Exception object is thrown--");
			int c=a/b;
			System.out.println("--After Exception object is thrown--");
		}catch(ArithmeticException e) {
			System.out.println("--Handling Exception--");
		}
		finally {
			System.out.println("--finally executed--");
		}
	}

}
