package com.yash.exception;

import java.io.EOFException;
import java.io.IOException;

public class CheckedExceptionDemo {

	
	class SuperClass{
		
		void x() throws IOException {
			
		}
		
	}
	
	class SubClass extends SuperClass{
		
		@Override
		void x() throws EOFException {
			
		}
	}
	
	public Object createObject(String className) throws ClassNotFoundException,InstantiationException,IllegalAccessException{
			Class classData=Class.forName(className);
		    return classData.newInstance();
		    
	}
	
	public static void main(String[] args) {

		CheckedExceptionDemo o=new CheckedExceptionDemo();
		MyClass myClass=null;
		try {
			myClass = (MyClass)o.createObject("com.yash.exception.MyClass");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		myClass.x();
		

	}

}
