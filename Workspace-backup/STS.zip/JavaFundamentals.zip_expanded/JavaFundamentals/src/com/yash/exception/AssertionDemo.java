package com.yash.exception;

import java.util.Scanner;

public class AssertionDemo {

	public static void main(String[] args) {

		try(Scanner scanner=new Scanner(System.in)){
			
			System.out.print("Please Enter Age:");
			int age=scanner.nextInt();
			assert age>0:"Age cannot be negative";
			age=age+1;
			System.out.println("After one year age will be:"+age);
		}
		
		int noOfAdults=2;
		int noOfChild=3;
		int totalNoOfTickets=noOfAdults+noOfChild;
		int tickets[]=new int[totalNoOfTickets];
		
		
				
		int pass=1;
		for(int i=0;i<tickets.length-1;i++) {
			tickets[i]=pass;
			pass++;
		}
		
		int n=0;
		while(n<tickets.length) {
			assert tickets[n]!=0:"pass not issued";
			System.out.println("Pass issued:"+tickets[n]);
			n++;
		}
			
		
		
	}

}
