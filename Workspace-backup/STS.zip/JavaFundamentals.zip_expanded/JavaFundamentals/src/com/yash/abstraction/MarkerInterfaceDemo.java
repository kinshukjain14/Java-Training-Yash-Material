package com.yash.abstraction;

public class MarkerInterfaceDemo {

	public static void main(String[] args) {

		MarkerImplementationClass o=new MarkerImplementationClass();
		if(o instanceof MarkerInterface) {
			System.out.println("Class is implementing marker interface");
		}else {
			System.out.println("Class is not implementing marker interface");

		}
	}

}
