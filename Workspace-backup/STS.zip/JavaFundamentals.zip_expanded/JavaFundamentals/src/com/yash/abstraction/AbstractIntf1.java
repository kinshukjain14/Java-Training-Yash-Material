package com.yash.abstraction;

public abstract class AbstractIntf1 implements Intf1 {

	@Override
	public void x1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void x2() {
		// TODO Auto-generated method stub
		
	}

	
}
