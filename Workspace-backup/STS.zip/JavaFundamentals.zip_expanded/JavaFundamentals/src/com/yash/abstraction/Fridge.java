package com.yash.abstraction;

public class Fridge implements CalcProfit {

	private double sp;
	private double cp;
	
	
	public Fridge(double sp, double cp) {
		super();
		this.sp = sp;
		this.cp = cp;
	}


	@Override
	public double calculateProfit() {
		return (sp-cp)+100;
	}

}
