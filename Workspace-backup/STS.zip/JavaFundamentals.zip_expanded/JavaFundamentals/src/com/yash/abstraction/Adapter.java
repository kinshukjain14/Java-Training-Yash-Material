package com.yash.abstraction;

public class Adapter implements Interface1 {

	@Override
	public void x1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void x2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void x3() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void x4() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void x5() {
		// TODO Auto-generated method stub
		
	}

}
