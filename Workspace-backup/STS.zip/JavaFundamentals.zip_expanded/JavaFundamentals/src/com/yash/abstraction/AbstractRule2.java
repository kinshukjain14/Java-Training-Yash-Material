package com.yash.abstraction;

public interface  AbstractRule2 {
	 void rule2();
}
