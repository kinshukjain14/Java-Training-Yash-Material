package com.yash.abstraction;

public abstract class AbstractProperties {

	private int a;
	private int b;
	
	public AbstractProperties() {}
	
	public AbstractProperties(int a,int b) {
		this.a=a;
		this.b=b;
	}
	public abstract void abstractMethod();
	
	public void nonStaticConcreteMethod() {
		System.out.println("--non static concrete method--"+"a:"+a+"b:"+b);
	}
	
	public static void staticConcreteMethod() {
		System.out.println("--static concrete method--");
	}
}
