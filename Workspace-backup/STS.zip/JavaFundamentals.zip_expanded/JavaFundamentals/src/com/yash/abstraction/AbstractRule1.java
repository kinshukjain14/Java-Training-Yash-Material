package com.yash.abstraction;

public abstract interface AbstractRule1 {
	
	 int I=10;//by default field will be static and final
	 void rule1();//by default method is public and method is abstract
	 
	 class CanHaveClass{
		 
	 }
}
