package com.yash.abstraction;

public class AbstractPropertiesDemo {

	public static void main(String[] args) {

		//AbstractProperties abstractObject=new AbstractProperties(10,20); error
		
		AbstractProperties.staticConcreteMethod();
		
		SubClassOfAbstract subClassObject=new SubClassOfAbstract(10,20);
		subClassObject.nonStaticConcreteMethod();
	}

}
