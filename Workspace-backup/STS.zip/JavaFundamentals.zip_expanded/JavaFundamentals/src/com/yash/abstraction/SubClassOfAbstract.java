package com.yash.abstraction;

public class SubClassOfAbstract extends AbstractProperties {

	
	public SubClassOfAbstract(int a,int b) {
		super(a,b);
	}
	@Override
	public void abstractMethod() {

		System.out.println("--abstract method--");
	}
	
	@Override
	public void nonStaticConcreteMethod() {
		super.nonStaticConcreteMethod();
	}

}
