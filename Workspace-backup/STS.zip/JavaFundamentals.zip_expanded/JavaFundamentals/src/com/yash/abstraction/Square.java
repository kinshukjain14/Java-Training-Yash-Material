package com.yash.abstraction;

public class Square extends Figure{
	private double length;
	
	public Square() {}
	
	public Square(double length) {
		this.length=length;
	}
	@Override
	public double area() {
		return length*length;
	}
	
}