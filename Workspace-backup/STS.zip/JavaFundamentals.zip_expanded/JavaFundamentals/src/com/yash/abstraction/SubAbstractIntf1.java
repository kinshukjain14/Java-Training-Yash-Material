package com.yash.abstraction;

public class SubAbstractIntf1 extends AbstractIntf1 {

	@Override
	public void x3() {
		// TODO Auto-generated method stub
		
	}

}
