package com.yash.abstraction;

public class SubClassMoreThanOneAbstract implements AbstractRule1,AbstractRule2 {

	@Override
	public void rule2() {

		System.out.println("--rule2---");
	}

	@Override
	public void rule1() {
		
		System.out.println("--rule1---");
	}
	
	public void internal() {}

}
