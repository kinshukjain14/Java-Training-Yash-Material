package com.yash.abstraction;

public interface A {
	
	void a();

}
