package com.yash.abstraction;

public interface MarkerInterface {

}
