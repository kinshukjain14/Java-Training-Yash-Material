package com.yash.abstraction;

public interface C extends A,B {

	void c();
}
