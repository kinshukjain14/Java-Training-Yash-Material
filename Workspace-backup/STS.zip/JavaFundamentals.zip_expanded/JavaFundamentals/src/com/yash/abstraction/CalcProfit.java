package com.yash.abstraction;

public interface CalcProfit {
	
	   double calculateProfit();

}
