package com.yash.abstraction;

public class TV implements CalcProfit{
	
	
	private double sp;
	private double cp;
	

	public TV(double sp, double cp) {
		super();
		this.sp = sp;
		this.cp = cp;
	}

	@Override
	public double calculateProfit() {
		return sp-cp;
	}

}
