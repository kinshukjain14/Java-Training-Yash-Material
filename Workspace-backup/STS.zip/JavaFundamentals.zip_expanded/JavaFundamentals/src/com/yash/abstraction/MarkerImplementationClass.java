package com.yash.abstraction;

public class MarkerImplementationClass implements MarkerInterface{

}
