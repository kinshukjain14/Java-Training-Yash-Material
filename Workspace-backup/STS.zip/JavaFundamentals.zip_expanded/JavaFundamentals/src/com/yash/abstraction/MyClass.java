package com.yash.abstraction;

public class MyClass extends Adapter {

	@Override
	public void x3() {
		System.out.println("--x3 implementation--");
	}
}
