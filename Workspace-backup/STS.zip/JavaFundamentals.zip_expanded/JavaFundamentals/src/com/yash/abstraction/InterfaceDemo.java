package com.yash.abstraction;

public class InterfaceDemo {

	public static void main(String[] args) {
		
		AbstractRule1 intf1=new SubClassMoreThanOneAbstract();
		intf1.rule1();
		//intf1.internal();
		
		SubClassMoreThanOneAbstract classRef=new SubClassMoreThanOneAbstract();
		classRef.internal();
		
		AbstractRule2 intf2=new SubClassMoreThanOneAbstract();
		
		

	}

}
