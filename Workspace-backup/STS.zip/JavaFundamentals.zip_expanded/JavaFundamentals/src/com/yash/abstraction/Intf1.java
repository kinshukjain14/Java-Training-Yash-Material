package com.yash.abstraction;

public interface Intf1 {
   void x1();
   void x2();
   void x3();
}
