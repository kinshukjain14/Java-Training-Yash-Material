package com.yash.abstraction;

public class RelatingUnrelatedClassesUsingInterface {
	
	public static void print(CalcProfit[] calcProfits) {
      for(CalcProfit calcProfit:calcProfits) {
    	  System.out.println(calcProfit.calculateProfit());
      }
	}
	
	public static void main(String args[]) {
		
		CalcProfit[] array= {new TV(2000,1300),new Fridge(900,200)};
		
		print(array);
		
	}

}
