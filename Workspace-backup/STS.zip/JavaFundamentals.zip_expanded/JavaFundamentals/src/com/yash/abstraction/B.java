package com.yash.abstraction;

public interface B {
   void b();
}
