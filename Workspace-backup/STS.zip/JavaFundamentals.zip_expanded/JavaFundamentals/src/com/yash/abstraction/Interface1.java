package com.yash.abstraction;

public interface Interface1 {

	void x1();
	void x2();
	void x3();
	void x4();
	void x5();
}
