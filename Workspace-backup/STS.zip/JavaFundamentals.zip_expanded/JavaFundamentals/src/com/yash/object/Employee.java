package com.yash.object;

public class Employee {
    private int empId;
	private String empName;
	private double empSalary;
	private String empDesignation;

	public Employee(){	
	}
	public Employee(int empId,String empName,double empSalary,String empDesignation) {
		this.empId=empId;
		this.empName=empName;
		this.empSalary=empSalary;
		this.empDesignation=empDesignation;
	}
	public int getEmpId() {
		return empId;
	}

	public String getEmpName() {
		return empName;
	}

	public double getEmpSalary() {
		return empSalary;
	}

	public String getEmpDesignation() {
		return empDesignation;
	}

}
