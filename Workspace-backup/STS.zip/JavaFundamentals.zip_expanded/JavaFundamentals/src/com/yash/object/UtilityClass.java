package com.yash.object;

public class UtilityClass {

	private float cp;
	private float sp;
	public UtilityClass(){
		
	}
    public UtilityClass(float cp,float sp){
		this.cp=cp;
		this.sp=sp;
	}
	public float profit() {
		return sp-cp;
	}
}
