package com.yash.object;

public class ImmutableMutableDemo {

	public static void main(String[] args) {
		Employee e=new Employee(1001,"Sabbir",34000,"Trainer");
		System.out.println("Emp Id:"+e.getEmpId());
		System.out.println("Emp Name:"+e.getEmpName());
		System.out.println("Emp Salary:"+e.getEmpSalary());
		System.out.println("Emp Designation:"+e.getEmpDesignation());
		
		Account account=new Account(111000987);
		account.setAccountBalance(34000);
		account.setAccountType("Savings");
		account.setHoldingType("Joint");
		
		System.out.println("Account Number:"+account.getAccountNumber());
		System.out.println("Account Balance:"+account.getAccountBalance());
		System.out.println("Account type:"+account.getAccountType());
		account.setAccountBalance(45000);
		System.out.println("Modified Account Balance:"+account.getAccountBalance());

		
		
	}

}
