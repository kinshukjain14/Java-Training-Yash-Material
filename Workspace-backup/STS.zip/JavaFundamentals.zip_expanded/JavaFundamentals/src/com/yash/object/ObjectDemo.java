package com.yash.object;

public class ObjectDemo {

	public static void main(String[] args) {

		UtilityClass o1=new UtilityClass();
		float result1=o1.profit();
		System.out.println("Result is:"+result1);
		
		UtilityClass o2=new UtilityClass(500,940);
		float result2=o2.profit();
		System.out.println("Result is:"+result2);

	}

}
