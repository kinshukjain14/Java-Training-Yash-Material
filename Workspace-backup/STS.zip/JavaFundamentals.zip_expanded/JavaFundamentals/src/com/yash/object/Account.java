package com.yash.object;

public class Account {
	private long accountNumber;
	private String accountType;
	private String holdingType;
	private double accountBalance;
	
	public Account() {	
	}
	public Account(long accountNumber) {
		this.accountNumber=accountNumber;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance){
		this.accountBalance=accountBalance;
	}

	public long getAccountNumber() {
		return accountNumber;
	}


	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getHoldingType() {
		return holdingType;
	}

	public void setHoldingType(String holdingType) {
		this.holdingType = holdingType;
	}
	

}
