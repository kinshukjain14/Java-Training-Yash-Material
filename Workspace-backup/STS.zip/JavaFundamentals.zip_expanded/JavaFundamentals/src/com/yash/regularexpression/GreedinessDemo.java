package com.yash.regularexpression;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GreedinessDemo {
	public static void main(String[] args) {
		String t = "Longlonglong ago, in a galaxy far far away";
		
		Pattern p1 = Pattern.compile("ago.*?far");
		Matcher m1 = p1.matcher(t);
		if(m1.find()) {
			System.out.println("Found : "+m1.group());
		}
	}
}
