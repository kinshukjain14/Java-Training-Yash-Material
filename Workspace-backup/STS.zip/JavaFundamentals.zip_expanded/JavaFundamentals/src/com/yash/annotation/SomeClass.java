package com.yash.annotation;
@YashClass
@Documentation(authorName = { "sabbir Poonawala","Amit Kumar" }, creationDate = "13/09/2021",usage = "Demonstrates use of custom annotation")
@YashTable(tableName = "someTable")
public class SomeClass {
	public SomeClass() {
		
	}

}
