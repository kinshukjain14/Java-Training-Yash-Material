package com.yash.annotation;

import java.lang.annotation.Annotation;
import java.util.Arrays;

public class AnnotationProcessing {

	public static void main(String[] args) {

		Class someClassData=SomeClass.class;
		YashClass yashClass=(YashClass)someClassData.getAnnotation(YashClass.class);
		if(yashClass!=null) {
			System.out.println("@YashClass is applied on SomeClass");
		}else {
			System.out.println("@YashClass is not applied on SomeClass");

		}
		
		Annotation[] annotations=someClassData.getAnnotations();
		for(Annotation annotation:annotations) {
			if(annotation instanceof YashClass)
				System.out.println("@YashClass is applied on SomeClass");
			}
		
		
		Documentation documentation=(Documentation)someClassData.getAnnotation(Documentation.class);
		if(documentation!=null) {
			System.out.println("Author Name:"+Arrays.toString(documentation.authorName()));
			System.out.println("Usage:"+documentation.usage());
			System.out.println("Creation Date:"+documentation.creationDate());
		}
		
		
		YashTable yashTable=(YashTable)someClassData.getAnnotation(YashTable.class);

		if(yashTable!=null) {
			System.out.println("Table Name:"+yashTable.tableName());
		}
		}



}


