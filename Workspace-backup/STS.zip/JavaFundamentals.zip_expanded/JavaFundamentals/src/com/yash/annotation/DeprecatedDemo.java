package com.yash.annotation;

import java.util.ArrayList;
import java.util.List;
@SuppressWarnings(value= {"deprecation"})
public class DeprecatedDemo {

	@SuppressWarnings(value= {"deprecation","unused"})
	public static void main(String[] args) {
		
		int x=10;
		MyClass mc=new MyClass();
		mc.x();
		@SuppressWarnings(value= {"rawtypes"})
		List list=new ArrayList();
		new MyClass(10,20);
	}
  
	class SuperInner{
		
		void a() {
			
		}
	}

	class SubInner extends SuperInner{
		@Override
		public void a() {
			
		}
	}
}
