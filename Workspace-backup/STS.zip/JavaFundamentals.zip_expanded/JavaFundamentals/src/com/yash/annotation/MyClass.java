package com.yash.annotation;
/*
 * @author sabbir poonawala
 */
@Deprecated
public class MyClass {
	
	
	MyClass(){}
	@Deprecated
	MyClass(int no1,int no2){}
	
	/**
	 * x() has some issues...
	 * @See xNew()
	 */
	@Deprecated
	public void x() {
		System.out.println("--x--");
	}
	public void xNew() {
		System.out.println("--Better version of x--");

	}
	

}
