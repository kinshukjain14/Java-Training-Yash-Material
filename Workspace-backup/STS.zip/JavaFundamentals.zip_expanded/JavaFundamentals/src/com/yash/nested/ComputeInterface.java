package com.yash.nested;

public interface ComputeInterface {
	
	public int compute(int no1,int no2);

}
