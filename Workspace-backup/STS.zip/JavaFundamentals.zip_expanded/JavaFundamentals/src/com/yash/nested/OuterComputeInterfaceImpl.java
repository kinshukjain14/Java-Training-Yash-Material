package com.yash.nested;

public class OuterComputeInterfaceImpl implements ComputeInterface {


	@Override
	public int compute(int no1, int no2) {
		// TODO Auto-generated method stub
		return no1+no2;
	}
	
	 
	class InnerComputeInterfaceImpl1 implements ComputeInterface{

		@Override
		public int compute(int no1, int no2) {
			// TODO Auto-generated method stub
			return no1-no2;
		}
		
	}
	class InnerComputeInterfaceImpl2 implements ComputeInterface{

		@Override
		public int compute(int no1, int no2) {
			// TODO Auto-generated method stub
			return no1*no2;
		}
		
	}
	
	static class staticInnerComputeInterfaceImpl implements ComputeInterface{
		@Override
		public int compute(int no1, int no2) {
			// TODO Auto-generated method stub
			return no1/no2;
		}
		
	}
	
	//We are creating annoymous class which implements ComputeInterface
	ComputeInterface annoy=new ComputeInterface() {

		@Override
		public int compute(int no1, int no2) {
			// TODO Auto-generated method stub
			return (no1+no2)/2;
		}
	};
	
	public static int computeMethod(int no1,int no2,ComputeInterface computeInterface) {
		return computeInterface.compute(no1, no2);
	}
	
	public static void main(String[] args) {

		OuterComputeInterfaceImpl outer=new OuterComputeInterfaceImpl();
		OuterComputeInterfaceImpl.InnerComputeInterfaceImpl1 inner=outer.new InnerComputeInterfaceImpl1();
		System.out.println("Output:"+inner.compute(20, 10));
		
	 OuterComputeInterfaceImpl.staticInnerComputeInterfaceImpl staticInner=
			 new OuterComputeInterfaceImpl.staticInnerComputeInterfaceImpl();
	 System.out.println("Output static nested class:"+staticInner.compute(4, 2));
	 
	
	 System.out.println("Output Annoymous class:"+outer.annoy.compute(10,20));
	 
	 //Local Class
	 
	 class LocalComputeInterfaceImpl implements ComputeInterface{
		@Override
		public int compute(int no1, int no2) {
			// TODO Auto-generated method stub
			return (20*no1)+no2;
		}
	 }
	LocalComputeInterfaceImpl localClass= new LocalComputeInterfaceImpl();
	System.out.println("Local class:"+localClass.compute(100, 10));
	 
	 int computedOuter= OuterComputeInterfaceImpl.computeMethod(100,150, outer);
	int computedInner= OuterComputeInterfaceImpl.computeMethod(100,150, inner);
	int computedStaticInner=OuterComputeInterfaceImpl.computeMethod(100,150, staticInner);
	
	
 int computedAnnoymous= OuterComputeInterfaceImpl.computeMethod(100, 30, new ComputeInterface() {
	@Override
	public int compute(int no1, int no2) {
		return no1+no2+4;
	}  
  });
 
	System.out.println("Outer as argument:"+computedOuter);
	System.out.println("Inner as argument:"+computedInner);
	System.out.println("Static Inner as argument:"+computedStaticInner);
	System.out.println("Annoymous as argument:"+computedAnnoymous);
	}
}
