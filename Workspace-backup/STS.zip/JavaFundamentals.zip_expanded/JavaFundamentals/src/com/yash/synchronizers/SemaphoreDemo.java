package com.yash.synchronizers;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class ConnectionWorker implements Runnable{
	
	@Override
	public void run() {
		Connection connection=Connection.getInstance();
		connection.connect();
	}
}
public class SemaphoreDemo {

	public static void main(String[] args) throws InterruptedException {

		ExecutorService executorService=Executors.newFixedThreadPool(200);
		for(int i=1;i<=200;i++) {
			executorService.submit(new ConnectionWorker());
		}
		executorService.awaitTermination(4, TimeUnit.MINUTES);
		executorService.shutdown();
		
	}

}
