package com.yash.synchronizers;

import java.util.concurrent.Semaphore;

public class Connection {

	private Connection() {}
	
	private Semaphore semaphore=new Semaphore(10,true);
	private  int connections=0;
	
	public static Connection getInstance() {
		return new Connection();
	}
	
	public void connect() {
		try {
			semaphore.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
		doConnect();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			semaphore.release();
		}
		
	}
	public void doConnect() {
		synchronized(this) {
			connections++;
			System.out.println("Current connections: "+connections);
		}
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		synchronized(this) {
			connections--;
		}
		
	}
	
}
