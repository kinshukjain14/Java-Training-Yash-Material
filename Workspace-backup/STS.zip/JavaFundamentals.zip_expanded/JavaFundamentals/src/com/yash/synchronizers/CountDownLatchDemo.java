package com.yash.synchronizers;

import java.util.concurrent.CountDownLatch;

class Worker extends Thread{
	private int sleepTime;
	private CountDownLatch latch;
	private String name;
	public Worker(int sleepTime,CountDownLatch latch,String name) {
		this.sleepTime=sleepTime;
		this.latch=latch;
		this.name=name;
	}
	
	@Override
	public void run() {
		try {
			System.out.println(name+" started doing task ");
			Thread.sleep(sleepTime);
			latch.countDown();
			System.out.println(name+" continue execution and finish task");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
public class CountDownLatchDemo {

	public static void main(String[] args) {

		
		CountDownLatch latch=new CountDownLatch(4);
		Worker worker1=new Worker(2000,latch,"Thread-1");
		Worker worker2=new Worker(4000,latch,"Thread-2");
		Worker worker3=new Worker(6000,latch,"Thread-3");
		Worker worker4=new Worker(8000,latch,"Thread-4");
		
		worker1.start();
		worker2.start();
		worker3.start();
		worker4.start();
		try {
			latch.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName()+" completed task");
	}

}
