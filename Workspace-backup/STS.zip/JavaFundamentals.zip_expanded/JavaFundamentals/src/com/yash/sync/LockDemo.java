package com.yash.sync;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class LockDemo {

	public static void main(String[] args) {

       ATMLock atm=new ATMLock("ICICI Bank","Magarpatta");
   	   Lock lock=new ReentrantLock(true);

		
		Thread person1=new Thread(new PersonLock("Rakesh",atm,lock));
		Thread person2=new Thread(new PersonLock("Mohit",atm,lock));
		Thread person3=new Thread(new PersonLock("Kunal",atm,lock));
		Thread person4=new Thread(new PersonLock("Amit",atm,lock));
		Thread person5=new Thread(new PersonLock("Priya",atm,lock));
		
		person1.start();
		person2.start();
		person3.start();
		person4.start();
		person5.start();
	}

}
