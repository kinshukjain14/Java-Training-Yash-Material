package com.yash.sync;

import java.time.LocalTime;

public class ThreadLocalDemo {


	public static void main(String[] args) {

		UniqueIdentifier o=new UniqueIdentifier();
		Thread worker1=new Thread(o,"Thread-1");
		Thread worker2=new Thread(o,"Thread-2");

		worker1.start();
		worker2.start();
		
		
	}

}
