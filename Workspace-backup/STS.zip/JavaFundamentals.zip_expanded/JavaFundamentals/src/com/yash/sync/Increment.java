package com.yash.sync;

import java.util.concurrent.atomic.AtomicInteger;

public class Increment implements Runnable{

	private int i=0;
	AtomicInteger atomicInteger=new AtomicInteger(1);

	@Override
	public void run() {

		while(true) {
			/*synchronized(this) {*/
				i++;
				System.out.println(i);	
			}
			//System.out.println(atomicInteger.getAndIncrement());
			
		}
	}
	

