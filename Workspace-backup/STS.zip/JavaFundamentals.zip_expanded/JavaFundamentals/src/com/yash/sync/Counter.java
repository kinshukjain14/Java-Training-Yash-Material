package com.yash.sync;

public class Counter implements Runnable {
	
	Thread t;
	long count;
	volatile boolean running=true;
	public Counter(int priority) {
		t=new Thread(this);
		t.setPriority(priority);
	}
	@Override
	public void run() {
		while(running) {
			count++;
		}
	}
	
	public void start() {
		t.start();
	}
	
	public void stop() {
		running=false;
	}

}
