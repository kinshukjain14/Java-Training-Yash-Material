package com.yash.sync;

public class ProducerConsumer {

	public static void main(String[] args) {

		Queue queue=new Queue();
		Thread producer1=new Thread(new Producer(queue),"producer1");
		producer1.start();
		
		Thread producer2=new Thread(new Producer(queue),"producer2");
		producer2.start();
		
		Thread consumer1=new Thread(new Consumer(queue),"consumer1");
		consumer1.start();
		
		Thread consumer2=new Thread(new Consumer(queue),"consumer2");
		consumer2.start();
	}

}
