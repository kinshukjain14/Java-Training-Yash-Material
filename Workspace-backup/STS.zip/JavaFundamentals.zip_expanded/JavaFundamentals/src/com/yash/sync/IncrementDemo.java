package com.yash.sync;

public class IncrementDemo {

	public static void main(String[] args) {

		Increment increment=new Increment();
		
		Thread worker1=new Thread(increment);
		worker1.start();
		
		Thread worker2=new Thread(increment);
		worker2.start();
		
	}

}
