package com.yash.sync;

public class ATMLock {
	
	private String bankName;
	private String bankLocation;
	public ATMLock(String bankName, String bankLocation) {
		super();
		this.bankName = bankName;
		this.bankLocation = bankLocation;
	}
	
	public void doATM(String personName) {
		System.out.println(personName+" entered ATM cabin.....");
		System.out.println(personName+" doing a transaction.....");
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	      System.out.println(personName+" exits ATM cabin....");
	}

}
