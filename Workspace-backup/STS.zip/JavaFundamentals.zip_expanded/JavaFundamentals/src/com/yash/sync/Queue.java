package com.yash.sync;
public class Queue {
	
	private int n;
	private boolean valueset=false;
	
	public synchronized void put(int n) {
		
		if(valueset) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		this.n=n;
		System.out.println(Thread.currentThread().getName()+" puts value :"+n);
		valueset=true;
        notify();
	}
	
	public synchronized int get() {
		
		if(!valueset) {
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println(Thread.currentThread().getName()+" gets value :"+n);
		valueset=false;
		notify();
		return n;
	}

}
