package com.yash.sync;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

class Worker1 implements Runnable{

	int count;
	public Worker1(int count) {
		this.count=count;
	}
	
	public double sum() {
		double sum=0;
		for(int i=1;i<=count;i++) {
			sum+=i;
		}
		return sum;
	}
	@Override
	public void run() {
		double sum=sum();
		System.out.println("Sum of count:"+count+" "+sum);
	}
	
}

class Worker2 implements Callable<Double>{

	int count;
	public Worker2(int count) {
		this.count=count;
	}
	
	public double sum() {
		double sum=0;
		for(int i=1;i<=count;i++) {
			sum+=i;
		}
		return sum;
	}
	@Override
	public Double call() throws Exception {
		double sum=sum();
		return sum;
	}
	
}
public class ExecutorServiceFramework {

	public static void main(String[] args) throws InterruptedException {
        final int nThreads=10;
		ExecutorService executorService=Executors.newFixedThreadPool(nThreads);
		
		/*for(int i=1;i<=20;i++) {
			executorService.execute(new Worker1(i*2));
		}*/
		Set<Future<Double>> futureSet=new HashSet<>();
		for(int i=1;i<=20;i++) {
			Future<Double> future=executorService.submit(new Worker2(i*2));
			futureSet.add(future);
		}
		
		for(Future<Double> future:futureSet) {
			try {
				System.out.println(future.get());
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		executorService.awaitTermination(1, TimeUnit.MINUTES);
		executorService.shutdown();
		
		
	}

}
