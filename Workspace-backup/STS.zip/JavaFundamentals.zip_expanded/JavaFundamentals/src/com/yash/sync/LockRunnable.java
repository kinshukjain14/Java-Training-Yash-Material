package com.yash.sync;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class LockRunnable implements Runnable {

	ReadWriteLock readWriteLock=new ReentrantReadWriteLock();
	
	@Override
	public void run() {
		readWriteLock.readLock().lock();
		System.out.println("---Read Section BEGIN---"+Thread.currentThread().getName());
		System.out.println("---In read---"+Thread.currentThread().getName());
        try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("---Read Section BEGIN---"+Thread.currentThread().getName());
        readWriteLock.readLock().unlock();
        
        readWriteLock.writeLock().lock();
		System.out.println("---write Section BEGIN---"+Thread.currentThread().getName());
		System.out.println("---In write---"+Thread.currentThread().getName());
        try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("---write Section END---"+Thread.currentThread().getName());
        readWriteLock.writeLock().unlock();
        
        
	}

}
