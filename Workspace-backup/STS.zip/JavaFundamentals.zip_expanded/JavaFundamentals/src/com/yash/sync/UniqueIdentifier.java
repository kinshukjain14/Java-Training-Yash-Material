package com.yash.sync;

import java.time.LocalTime;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

public class UniqueIdentifier implements Runnable{

	private static AtomicInteger atomicInteger=new AtomicInteger(1);
	private static ThreadLocal<Long> threadLocal=new ThreadLocal<Long>() {
		
		@Override
		public Long initialValue() {
			return System.nanoTime();
		}
		
	};
	
	@Override
	public void run() {
		System.out.println("Current Thread:"+Thread.currentThread().getName()+" ID "+threadLocal.get());

	}

}
