package com.yash.sync;

import java.util.concurrent.locks.Lock;

public class PersonLock implements Runnable {
	
	private String personName;
	private ATMLock atmLock;
    private Lock lock;
	public PersonLock(String personName, ATMLock atmLock,Lock lock) {
		super();
		this.personName = personName;
		this.atmLock = atmLock;
		this.lock=lock;
	}

	@Override
	public void run() {
		System.out.println(personName+" waiting in  a queue.....");
	    lock.lock();
		atmLock.doATM(personName);
		lock.unlock();
	}

}
