package com.yash.sync;


public class SynchronizedBlock {

	public static void main(String[] args) {

		ATM atm=new ATM("ICICI Bank","Magarpatta");

		
		Thread person1=new Thread(new Person("Rakesh",atm));
		Thread person2=new Thread(new Person("Mohit",atm));
		Thread person3=new Thread(new Person("Kunal",atm));
		Thread person4=new Thread(new Person("Amit",atm));
		Thread person5=new Thread(new Person("Priya",atm));
		
		person1.start();
		person2.start();
		person3.start();
		person4.start();
		person5.start();
		
	}

}
