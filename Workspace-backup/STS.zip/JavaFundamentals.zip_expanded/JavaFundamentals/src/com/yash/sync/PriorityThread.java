package com.yash.sync;

public class PriorityThread {

	public static void main(String[] args) {

		Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
		
		Counter higherPriority=new Counter(Thread.NORM_PRIORITY+2);
		Counter lowPriority=new Counter(Thread.NORM_PRIORITY-2);
		
		higherPriority.start();
		lowPriority.start();
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		lowPriority.stop();
		higherPriority.stop();
		
		try {
			higherPriority.t.join();
			lowPriority.t.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Count for high priority:"+higherPriority.count);
		System.out.println("Count for low priority:"+lowPriority.count);
	}

}
