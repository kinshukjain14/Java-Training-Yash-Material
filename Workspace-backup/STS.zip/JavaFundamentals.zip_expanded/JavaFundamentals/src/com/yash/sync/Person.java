package com.yash.sync;

public class Person implements Runnable {

	private String personName;
	private ATM atm;
	
	
	public Person(String personName, ATM atm) {
		super();
		this.personName = personName;
		this.atm = atm;
	}


	@Override
	public void run() {
		System.out.println(personName+" waiting in  a queue.....");
		synchronized(atm) {
			System.out.println(personName+" entered ATM cabin.....");
			System.out.println(personName+" doing a transaction.....");
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		      System.out.println(personName+" exits ATM cabin....");
		}
		
	}

}
