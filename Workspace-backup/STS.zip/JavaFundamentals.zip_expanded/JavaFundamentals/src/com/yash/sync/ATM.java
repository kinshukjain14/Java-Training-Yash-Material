package com.yash.sync;

public class ATM {
	private String bankName;
	private String bankLocation;
	public ATM(String bankName, String bankLocation) {
		super();
		this.bankName = bankName;
		this.bankLocation = bankLocation;
	}
	

}
