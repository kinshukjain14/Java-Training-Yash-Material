package com.yash.controls;

public class ReturnDemo {
	
	int x() {
		System.out.println("some statements");
		return 10;
		
	}

	public static void main(String[] args) {
	  ReturnDemo o=new ReturnDemo();
	  int result=o.x();
     boolean flag=true;
     System.out.println("--should be executed---");
     if(flag)
    	 return;
     System.out.println("--should not be executed---");

	}

}
