package com.yash.controls;

public class WhileDemo {

	public static void main(String[] args) {

		int i=5;
		while(i>0) {
			System.out.println("Value of i:"+i);
			i--;
		}
		
	}

}
