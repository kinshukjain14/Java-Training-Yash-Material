package com.yash.controls;

public class DoWhileDemo {

	public static void main(String[] args) {

		int i=0;
		do {
			System.out.println("Value of i:"+i);
			i++;
		}while(i<3);
	}

}
