package com.yash.controls;

public class ForDemo {
	public static void main(String[] args) {
	   for(int i=1;i<=5;i++) {
		   System.out.println("Value of i is:"+i);
	   }
		String[] names= {"sabbir","amit","sumeet"};
		for(int i=0;i<names.length;i++) {
			System.out.println("Name is:"+names[i]);
		}
		for(String name:names) {
			System.out.println("Name is:"+name);
		}
		String value="yash";
		//error
		/*
		for(String val:value) {
			System.out.println("val is:"+val);
		}*/
	}
}
