package com.yash.controls;

public class NestedIfDemo {

	public static void main(String[] args) {

		int age=18;
		if(age<=20) {
			if(age<=18) {
				System.out.println("Age is less than or equal to 18");
			}
		}else {
			System.out.println("Age is greater than 20");
		}
	}

}
