package com.yash.controls;

public class SwitchDemo {
	public static void main(String[] args) {
		int age=35;
		switch(age) {
		case 18:
			   System.out.println("Age is 18");
			   break;
		case 25:
			    System.out.println("Age is 25");
			    break;
		case 30:
			    System.out.println("Age is 30");
			    break;
		default:
			   System.out.println("Age does not match");
		}

		String season="winter";
		switch(season) {
		case "autumn":
			          System.out.println("Season is autumn");
			          break;
		case "winter":
			         System.out.println("Season is winter");
			         break;
		case "summer":
			         System.out.println("Season is summer");
			         break;      
		default:
			    System.out.println("Season is non recognisable");
		}
	}
	

}
