package com.yash.controls;

public class IfDemo {

	public static void main(String[] args) {

		int age=18;
		if(age>=18) {
			System.out.println("Age is 18");
		}
		boolean b=false;
		if(b) {
			System.out.println("will execute");
		}
	  }
	}

	
