package com.yash.controls;

public class IfElseDemo {

	public static void main(String[] args) {

		int age=18;
		if(age>18) {
			System.out.println("Age is 18");
		}else {
			System.out.println("Age is not greater than 18");
		}
	}

}
