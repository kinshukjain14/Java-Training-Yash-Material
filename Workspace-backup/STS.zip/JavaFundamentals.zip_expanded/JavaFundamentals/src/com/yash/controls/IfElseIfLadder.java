package com.yash.controls;

public class IfElseIfLadder {

	public static void main(String[] args) {

		int age=25;
		if(age<18) {
			System.out.println("Age is less than 18");
		}
		else if(age>=25 && age<=30) {
			System.out.println("Age is greater than or equal to 25 and less than 30");
		}
		else if(age>30 && age<=45) {
			System.out.println("Age is greater than 30 and less than or equal to 45");
		}
		else {
			System.out.println("Age is more than 45");
		}
		
	}

}
