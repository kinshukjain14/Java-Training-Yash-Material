package com.yash.controls;

public class TernaryOperator {

	public static void main(String[] args) {

		int a,b;
		a=10;
		b=(a==10)?100:0;
		
	}

}
