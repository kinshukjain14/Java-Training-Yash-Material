package com.yash.log;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class LoggerDemo {

	static {
		LoggerDemo.logger=Logger.getLogger("LoggerDemo");
		try {
			LoggerDemo.fileHandler=new FileHandler("D:\\filehandling\\log.txt",true);
			LoggerDemo.simpleFormatter=new SimpleFormatter();
			LoggerDemo.fileHandler.setFormatter(LoggerDemo.simpleFormatter);
			LoggerDemo.logger.addHandler(LoggerDemo.fileHandler);
			LoggerDemo.logger.setLevel(Level.CONFIG);
			System.out.println(LoggerDemo.logger.isLoggable(Level.CONFIG));
			LoggerDemo.logger.log(Level.CONFIG,"Logger was successfully configured");
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	private static Logger logger;
	private static FileHandler fileHandler;
	private static SimpleFormatter simpleFormatter;
	
	public int compute(int a,int b) {
		logger.log(Level.INFO,"method compute was called:"+LocalDateTime.now());
		int c=a+b;
		
		logger.log(Level.INFO,"Value of c:"+c);
		int t=0;
		try {
		t=c/a;
		if(t>0) {
			logger.log(Level.WARNING,"value of t is beyond range :"+t);
		}
		}catch(ArithmeticException e) {
			logger.log(Level.SEVERE,"Arithmetic Exception was thrown a->0");
		}
		
		return t;
	}
	public static void main(String args[]) {
		LoggerDemo loggerDemo=new LoggerDemo();
		loggerDemo.compute(10,100);
	}
}
