package com.yash.string;

import java.util.Locale;
import java.util.StringTokenizer;

public class StringDemo {

	public static void main(String[] args) {

		//String Literal
		
		String str1="HelloWorld";
		
		//String Object using new
		
		String str2=new String("HelloWorld");
		
		char arrayCh[]= {'S','A','B','B','I','R'};
		
		//String Object using array of char
		
		String str3=new String(arrayCh);
		
		String str4="yash technologies";
		
		System.out.println(str4.toUpperCase());
		
		String str5="\u00EB \u00CB";
		
		System.out.println(str5.toUpperCase(Locale.FRENCH));
		
		String str6="\u2E80";
		
		System.out.println(str6.toUpperCase(Locale.CHINESE));
		
		String str7=" Yash Technologies ";
		System.out.println(str7.trim());
		
		String str8="Yash Technologies";
		System.out.println("Whether starts with Y:"+str8.startsWith("Y"));
		System.out.println("Whether ends with s:"+str8.endsWith("s"));
		
		
		String str9="Yash Technologies";
		System.out.println("Char at zero index pos:"+str9.charAt(0));
		System.out.println("Char at 5 index pos:"+str9.charAt(5));
		
		String str10=" ";
		System.out.println("Whether string is empty:"+str10.isEmpty());
		
		System.out.println("Length of str9:"+str9.length());
		
		String str11="sabbir";
		String str12="Yash";
		String str13="sabbir";
		
		System.out.println("str11.compareTo(str12):"+str11.compareTo(str12));
		System.out.println("str12.compareTo(str13):"+str12.compareTo(str13));
		System.out.println("str11.compareTo(str13):"+str11.compareTo(str13));
		
		
		String str14="HelloWorld";
		System.out.println("Sub string str14:"+str14.substring(0,5));
		
		String str15="Hello, my name is Sabbir";
		String allStrings[]=str15.split(",");
		
		for(String strings:allStrings) {
			System.out.println(strings);
		}
		
		StringTokenizer tokenizer=new StringTokenizer(str15," ");
		while(tokenizer.hasMoreTokens()) {
			System.out.println(tokenizer.nextToken());
		}
		
		
		
		
	}

}
