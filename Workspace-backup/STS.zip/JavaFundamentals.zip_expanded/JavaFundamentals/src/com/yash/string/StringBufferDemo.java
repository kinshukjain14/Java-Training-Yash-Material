package com.yash.string;

public class StringBufferDemo {

	public static void main(String[] args) {

		String str="Sabbir";
		String newStr=str+"Poonawala";//StringBuffer buffer=new StringBuffer(str);buffer.append("Poonawala");
		System.out.println(newStr);
		
		StringBuffer sb1=new StringBuffer("Sabbir");
		sb1.append("Poonawala");
        System.out.println(sb1);
        
        StringBuffer sb2=new StringBuffer("Sabbir");//S->0,a->1
        sb2.insert(1,'h');//S->0,h->1,a->2
        System.out.println(sb2);
        
        StringBuffer sb3=new StringBuffer("Sabbir");
        sb3.replace(1, 2, "u");
        System.out.println(sb3);
        
        sb3.delete(1, 2);
        
        System.out.println(sb3);
        
        sb3.insert(1, 'a');
        
        System.out.println(sb3);
        
        StringBuffer sb4=new StringBuffer("Sabbir");
        sb4.reverse();
        System.out.println(sb4);
        
        StringBuffer sb5=new StringBuffer();//16
        System.out.println("Default Capacity:"+sb5.capacity());
        sb5.append("SabbirPoonawalajjjjjjjjjjjjjjjjjhhhhhhhhhhh");
        System.out.println("Capacity:"+sb5.capacity());
        System.out.println("Length:"+sb5.length());
        
        StringBuffer sb6=new StringBuffer();
        System.out.println("Default Capacity:"+sb6.capacity());
        sb6.ensureCapacity(20);
        System.out.println("Capacity:"+sb6.capacity());

        

                
        

        
        
        

        
	}

}
