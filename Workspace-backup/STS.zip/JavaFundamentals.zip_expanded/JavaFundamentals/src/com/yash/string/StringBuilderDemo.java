package com.yash.string;

public class StringBuilderDemo {

	public static void main(String[] args) {

		StringBuilder sb1=new StringBuilder();
		System.out.println("Initial Capacity:"+sb1.capacity());
		sb1.append("Sabbir");
		System.out.println("Capacity:"+sb1.capacity());
		System.out.println("Length:"+sb1.length());
		
		sb1.insert(1, 'h');
		System.out.println(sb1);
		System.out.println("Length:"+sb1.length());
		
		sb1.replace(0, 7, "Raahul");
		
		System.out.println(sb1);
		
		sb1.delete(1,2);
		System.out.println(sb1);
		
		
		sb1.reverse();
		System.out.println(sb1);
		

		

		
		
		

		


		
		
	}

}
