package com.yash.pack1;

public class MyClass1 {
	
	public void x() {
		System.out.println("--x--");
	}

}
