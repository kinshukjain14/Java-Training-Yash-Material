package com.yash.helper;

import com.yash.abstraction.CalcProfit;
import com.yash.abstraction.Fridge;
import com.yash.abstraction.TV;

public class FactoryCalcProfit {
	
	public static CalcProfit createCalcProfit() {
		CalcProfit calcProfit=new Fridge(900,200);
		return calcProfit;
	}

}
