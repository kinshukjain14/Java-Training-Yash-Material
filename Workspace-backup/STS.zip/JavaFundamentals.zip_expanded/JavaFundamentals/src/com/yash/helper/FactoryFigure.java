package com.yash.helper;

import com.yash.abstraction.Figure;
import com.yash.abstraction.Rectangle;
import com.yash.abstraction.Square;

public class FactoryFigure {

	public static Figure createFigure() {
		Figure figRef=new Square(10);
		return figRef;
	}
}
