package com.yash.enumeration;
import static com.yash.enumeration.MathematicalConstants.*;
public class FinalVariableDemo {

	final double PI=3.14;
	final int I;
	final static int J;
	static{
		J=20;
	}
     {
		I=30;
	}
	public FinalVariableDemo() {
		//I=0;
	}
	
   public FinalVariableDemo(int I){
		//this.I=I;
	}
	public static void main(String[] args) {
		FinalVariableDemo o1=new FinalVariableDemo();
		//o.PI=2.3; Error
		
		FinalVariableDemo o2=new FinalVariableDemo();
		//o2.I=23;//Error
		
		FinalVariableDemo o3=new FinalVariableDemo(10);
		//o3.I=30;
		
		final StringBuffer buffer=new StringBuffer("Hello");
		//buffer=new String("HelloWorld");//Reference of final variable cannot change
		
		buffer.append("World");
		
		System.out.println(buffer);
		
		final int NO1=10;
		final int NO2=20;
		final int NO3;
		NO3=NO1+NO2;
		
		double result=(K*M)/P;
		
	}

}
