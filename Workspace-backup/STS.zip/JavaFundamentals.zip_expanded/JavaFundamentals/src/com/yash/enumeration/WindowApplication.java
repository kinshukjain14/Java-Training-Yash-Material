package com.yash.enumeration;

public class WindowApplication {
	
	
	public void setBackground(Color color) {
		
		switch(color) {
		case RED:
			     System.out.println("Change color to Red");
			     break;
		case GREEN:
		     System.out.println("Change color to Green");
		     break;
		case BLUE:
		     System.out.println("Change color to Blue");
		     break;
		case YELLOW:
		     System.out.println("Change color to Yellow");
		     break;
		case CYAN:
		     System.out.println("Change color to CYAN");
		     break;
			     
		}
	}

	public static void main(String[] args) {
		
		WindowApplication o=new WindowApplication();
		o.setBackground(Color.RED);
		
		System.out.println("G value in Red:"+Color.RED.getG());

	}

}
