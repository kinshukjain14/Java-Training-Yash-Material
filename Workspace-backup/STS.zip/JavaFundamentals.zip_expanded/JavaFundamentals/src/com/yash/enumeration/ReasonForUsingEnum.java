package com.yash.enumeration;

import com.yash.enumeration.Computer.ComputerStates;

public class ReasonForUsingEnum {

	public static void main(String[] args) {

		Computer computer=new Computer();
		computer.setState(ComputerStates.ON);
		computer.setState(ComputerStates.SUSPEND);
		computer.setState(ComputerStates.OFF);
		
		//computer.setState(-2);//error
	}

}
