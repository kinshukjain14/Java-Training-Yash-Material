package com.yash.enumeration;

public interface MathematicalConstants {
	
	double K=2.3;
	double P=3.9;
	double M=2.3;
}
