package com.yash.enumeration;

public class Computer {

	private int state;
	enum ComputerStates{
		OFF(0),ON(1),SUSPEND(2);
		private int val;
		private ComputerStates(int val) {
			this.val=val;
		}
		public int getValue() {
			return val;
		}
	}
	
	//0-shutdown,1-Running,2-suspending
	public void setState(ComputerStates state) {
		
		switch(state) {
		case OFF:
			     System.out.println("Computer is switched OFF");
			     break;
		case ON:
			      System.out.println("Computer is switched ON");
			      break;
		case SUSPEND:
			        System.out.println("Computer is suspended");
			        break;
		
		}
	}
}
