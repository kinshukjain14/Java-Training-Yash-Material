import java.io.IOException;
import java.io.InputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class QueryEmployeeDataXML {
	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {
		InputStream is = ClassLoader.getSystemResourceAsStream("company.xml");
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder = docBuilderFactory.newDocumentBuilder();
		Document document = documentBuilder.parse(is);
		document.getDocumentElement().normalize();
		String rootName = document.getDocumentElement().getNodeName();
		System.out.println("Root Node : "+rootName);
		
		System.out.println(document.getDocumentElement().getNodeName());
		NodeList nodeList = document.getElementsByTagName("department");
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			if(node.getNodeType()==Node.DOCUMENT_NODE) {
				
			}
		}
		
		
	}
}
