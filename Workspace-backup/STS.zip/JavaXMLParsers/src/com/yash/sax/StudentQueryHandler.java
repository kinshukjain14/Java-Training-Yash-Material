package com.yash.sax;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class StudentQueryHandler extends DefaultHandler {
	private String rollNogiven=null;
	boolean bFirstName=false;
	boolean bLastName=false;
	boolean bSemester1Score=false;
	boolean bSemester2Score=false;
	boolean bSemester3Score=false;
	boolean bSemester4Score=false;
	boolean bSemester5Score=false;
	boolean bSemester6Score=false;
	
	public StudentQueryHandler(String rollNo) {
		this.rollNogiven=rollNo;
	}
	
	String rollNo;
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if(qName.equalsIgnoreCase("student")) {
			rollNo = attributes.getValue("rollNo");
			if(rollNo.equalsIgnoreCase(this.rollNogiven) && qName.equalsIgnoreCase("student")) {
				System.out.println("Roll No :" + rollNo);				
			}
		}
		else if(qName.equalsIgnoreCase("firstname") && rollNo.equalsIgnoreCase(this.rollNogiven) ) {
			bFirstName=true;
		}
		else if(qName.equalsIgnoreCase("lastname") && rollNo.equalsIgnoreCase(this.rollNogiven) ) {
			bLastName=true;
		}
		else if(qName.equalsIgnoreCase("sem1marks") && rollNo.equalsIgnoreCase(this.rollNogiven) ) {
			bSemester1Score=true;
		}
		else if(qName.equalsIgnoreCase("sem2marks") && rollNo.equalsIgnoreCase(this.rollNogiven) ) {
			bSemester2Score=true;
		}
		else if(qName.equalsIgnoreCase("sem3marks") && rollNo.equalsIgnoreCase(this.rollNogiven) ) {
			bSemester3Score=true;
		}
		else if(qName.equalsIgnoreCase("sem4marks") && rollNo.equalsIgnoreCase(this.rollNogiven) ) {
			bSemester4Score=true;
		}
		else if(qName.equalsIgnoreCase("sem5marks") && rollNo.equalsIgnoreCase(this.rollNogiven) ) {
			bSemester5Score=true;
		}
		else if(qName.equalsIgnoreCase("sem6marks") && rollNo.equalsIgnoreCase(this.rollNogiven) ) {
			bSemester6Score=true;
		}
	}
	
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		if(bFirstName && rollNo.equalsIgnoreCase(this.rollNogiven)) {
			System.out.println("first name : "+new String(ch,start,length));
			bFirstName=false;
		}
		else if(bLastName && rollNo.equalsIgnoreCase(this.rollNogiven)) {
			System.out.println("last name : "+new String(ch,start,length));
			bLastName=false;
		}
		else if(bSemester1Score && rollNo.equalsIgnoreCase(this.rollNogiven)) {
			System.out.println("Sem 1 marks : "+new String(ch,start,length));
			bSemester1Score=false;
		}
		else if(bSemester2Score && rollNo.equalsIgnoreCase(this.rollNogiven)) {
			System.out.println("Sem 2 marks : "+new String(ch,start,length));
			bSemester2Score=false;
		}
		else if(bSemester3Score && rollNo.equalsIgnoreCase(this.rollNogiven)) {
			System.out.println("Sem 3 marks : "+new String(ch,start,length));
			bSemester3Score=false;
		}
		else if(bSemester4Score && rollNo.equalsIgnoreCase(this.rollNogiven)) {
			System.out.println("Sem 4 marks : "+new String(ch,start,length));
			bSemester4Score=false;
		}
		else if(bSemester5Score && rollNo.equalsIgnoreCase(this.rollNogiven)) {
			System.out.println("Sem 5 marks : "+new String(ch,start,length));
			bSemester5Score=false;
		}
		else if(bSemester6Score && rollNo.equalsIgnoreCase(this.rollNogiven)) {
			System.out.println("Sem 6 marks : "+new String(ch,start,length));
			bSemester6Score=false;
		}
		
	}
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if(qName.equalsIgnoreCase("student") && rollNo.equalsIgnoreCase(this.rollNogiven)) {
			System.out.println("End of element "+qName);
		}
	}
	
}
