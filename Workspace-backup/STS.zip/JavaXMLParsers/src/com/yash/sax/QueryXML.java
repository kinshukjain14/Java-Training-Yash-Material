package com.yash.sax;

import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

public class QueryXML {
	public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter roll no : ");
		String rollno = sc.next();
		InputStream is = ClassLoader.getSystemResourceAsStream("students.xml");
		SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
		SAXParser saxParser = saxParserFactory.newSAXParser();
		saxParser.parse(is,new StudentQueryHandler(rollno));
		sc.close();
	}
}
