package com.yash.sax;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class StudentHandler extends DefaultHandler
{
	boolean bFirstName=false;
	boolean bLastName=false;
	boolean bSemester1Score=false;
	boolean bSemester2Score=false;
	boolean bSemester3Score=false;
	boolean bSemester4Score=false;
	boolean bSemester5Score=false;
	boolean bSemester6Score=false;
	
	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		if(qName.equalsIgnoreCase("student")) {
			String rollNo = attributes.getValue("rollNo");
			System.out.println("Roll No :" + rollNo);
		}
		else if(qName.equalsIgnoreCase("firstname")) {
			bFirstName=true;
		}
		else if(qName.equalsIgnoreCase("lastname")) {
			bLastName=true;
		}
		else if(qName.equalsIgnoreCase("sem1marks")) {
			bSemester1Score=true;
		}
		else if(qName.equalsIgnoreCase("sem2marks")) {
			bSemester2Score=true;
		}
		else if(qName.equalsIgnoreCase("sem3marks")) {
			bSemester3Score=true;
		}
		else if(qName.equalsIgnoreCase("sem4marks")) {
			bSemester4Score=true;
		}
		else if(qName.equalsIgnoreCase("sem5marks")) {
			bSemester5Score=true;
		}
		else if(qName.equalsIgnoreCase("sem6marks")) {
			bSemester6Score=true;
		}
	}
	
	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		if(bFirstName) {
			System.out.println("first name : "+new String(ch,start,length));
			bFirstName=false;
		}
		else if(bLastName) {
			System.out.println("last name : "+new String(ch,start,length));
			bLastName=false;
		}
		else if(bSemester1Score) {
			System.out.println("Sem 1 marks : "+new String(ch,start,length));
			bSemester1Score=false;
		}
		else if(bSemester2Score) {
			System.out.println("Sem 2 marks : "+new String(ch,start,length));
			bSemester2Score=false;
		}
		else if(bSemester3Score) {
			System.out.println("Sem 3 marks : "+new String(ch,start,length));
			bSemester3Score=false;
		}
		else if(bSemester4Score) {
			System.out.println("Sem 4 marks : "+new String(ch,start,length));
			bSemester4Score=false;
		}
		else if(bSemester5Score) {
			System.out.println("Sem 5 marks : "+new String(ch,start,length));
			bSemester5Score=false;
		}
		else if(bSemester6Score) {
			System.out.println("Sem 6 marks : "+new String(ch,start,length));
			bSemester6Score=false;
		}
		
	}
	
	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if(qName.equalsIgnoreCase("student")) {
			System.out.println("End of element "+qName);
		}
	}
}
