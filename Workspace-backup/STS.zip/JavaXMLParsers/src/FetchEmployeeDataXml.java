import java.io.IOException;
import java.io.InputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class FetchEmployeeDataXml {
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		
		InputStream inputStream = ClassLoader.getSystemResourceAsStream("employees.xml");
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder = docBuilderFactory.newDocumentBuilder();
		Document document = documentBuilder.parse(inputStream);
		document.getDocumentElement().normalize();
		String nodeName = document.getDocumentElement().getNodeName();
		System.out.println("Root Node : "+nodeName);
		NodeList nodeList = document.getElementsByTagName("employee");
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node node = nodeList.item(i);
			System.out.println("Node name : "+node.getNodeName());
			if(node.getNodeType()==Node.ELEMENT_NODE)
			{
				Element element = (Element)node;
				System.out.println("Emp ID : "+ element.getAttribute("empId"));
				System.out.println("Emp Name :"+element.getElementsByTagName("empName").item(0).getNodeValue());
				System.out.println("Emp Salary :"+element.getElementsByTagName("empName").item(0).getNodeValue());
				System.out.println("Emp Designation :"+element.getElementsByTagName("empName").item(0).getNodeValue());
				
			}
		}
		
		
		
	}
}
