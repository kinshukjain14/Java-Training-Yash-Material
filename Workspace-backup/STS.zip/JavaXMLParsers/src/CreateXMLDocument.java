import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class CreateXMLDocument {
	public static void main(String[] args) throws ParserConfigurationException, TransformerException {

		File file = new File("D:\\fileHandling\\company.xml");
//		InputStream inputStream = ClassLoader.getSystemResourceAsStream("employees.xml");
		DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder = docBuilderFactory.newDocumentBuilder();
		Document document = documentBuilder.newDocument();
		Element rootElement = document.createElement("company");
		document.appendChild(rootElement);
		
		Element departmentElement = document.createElement("department");
		rootElement.appendChild(departmentElement);
		Attr attribute = document.createAttribute("deapartmentName");
		attribute.setValue("IT");
		departmentElement.setAttributeNode(attribute);
		
		 Element emp1Element = document.createElement("employee");
		 Attr empAttr = document.createAttribute("empId");
		 empAttr.setValue("1001");
		 emp1Element.setAttributeNode(empAttr);
		 departmentElement.appendChild(emp1Element);

		 Element emp2Element = document.createElement("employee");
		 Attr emp2Attr = document.createAttribute("empId");
		 emp2Attr.setValue("1002");
		 emp2Element.setAttributeNode(emp2Attr);
		 departmentElement.appendChild(emp2Element);
		 
		 TransformerFactory transformerFactory = TransformerFactory.newInstance();
		 Transformer newTransformer = transformerFactory.newTransformer();
		 
		 DOMSource domSource = new DOMSource(document);
		 StreamResult streamResult = new StreamResult(file);
		 newTransformer.transform(domSource, streamResult);
		 
		
		
	}
}
