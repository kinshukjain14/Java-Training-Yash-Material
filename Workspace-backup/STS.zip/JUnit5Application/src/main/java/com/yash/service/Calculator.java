package com.yash.service;

public class Calculator {

	public int sum(int no1, int no2) {
		return no1+no2;
	}

}
