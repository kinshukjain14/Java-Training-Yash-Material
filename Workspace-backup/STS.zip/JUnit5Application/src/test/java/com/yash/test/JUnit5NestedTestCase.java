package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

class JUnit5NestedTestCase {
	@Nested
	class NestedTest1{
		int no1;
		@BeforeEach
		void setUp() {
			no1=10;
		}
		@Test
		@DisplayName("NestedTest1-test()")
		void test() {
			assertTrue(no1>5);
		}
		
	}
	
	@Nested
	class NestedTest2{
		int no1;
		@BeforeEach
		void setUp() {
			no1=20;
		}
		@Test
		@DisplayName("NestedTest2-test()")
		void test() {
			assertTrue(no1>10);
		}
		
	}

}
