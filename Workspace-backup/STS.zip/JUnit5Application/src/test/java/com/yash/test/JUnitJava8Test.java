package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import org.junit.jupiter.api.Test;

class JUnitJava8Test {

	@Test
	void testLambda() {
		List<Integer> integerList=new ArrayList<>();
		integerList.add(1);
		integerList.add(20);
		integerList.add(30);
		integerList.add(40);
		integerList.add(50);
		assertTrue(integerList.stream().filter((n)->n>5).count()>=2);	
	}
	
	@Test
   void testAssertAll() {
	int[] numbers= {0,1,2,3,4};
	assertAll("numbers",
			()->assertEquals(numbers[0],0),
			()->assertEquals(numbers[3],3),
			()->assertEquals(numbers[4],4)
			);
	}
	

	@Test
	void testAssumption() {
		assumeTrue("sabbir".equals("amit"),JUnitJava8Test::message);
		assertEquals("sabbir","sabbir");
	}
	
	public static String message() {
		return "Test execution has failed";
	}
	
	@Test
	void testAssumptionAssertion() {
		assumeTrue(1==2);
		assertEquals("sabbir","sabbir");
	}
	
	@Test
	void testSupplier() {
		Supplier<String> supplyMessage=()->{
			return "Test condition failed";
		};
		assertEquals("sabbir","amit",supplyMessage);
	}
	@Test
	void checkIfExceptionThrown() {
		Throwable exception=assertThrows(ArithmeticException.class,()->{
			throw new ArithmeticException("invalid data");
		});
		assertEquals(exception.getMessage(),"invalid data");
	}
	
}
