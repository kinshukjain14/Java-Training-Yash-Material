package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.yash.service.Calculator;

class JUnit5TestCase {

	@BeforeAll
	static void setUpBeforeAll() {
             System.out.println("--Before All--");
	}
	
	@AfterAll
	static void setUpAfterAll() {
             System.out.println("--After All--");
	}
	private Calculator calculator=null;
	@BeforeEach
	void setUpCondition() {
		calculator=new Calculator();
		System.out.println("--Before Each test condition--");
	}
	
	@AfterEach
	void tearDownCondition() {
		System.out.println("--After Each test condition--");
	}
	@Tag("DEV")
	@Test
	public void testAddDev() {
		int expected=15;
		int no1=10;
		int no2=5;
		int actual=no1+no2;
		System.out.println("--Dev test condition--");
		assertEquals(expected,actual);
	}
	@Tag("PROD")
	@Test
	public void testAddProd() {
		int expected=15;
		int no1=10;
		int no2=5;
		int actual=no1+no2;
		System.out.println("--PROD test condition--");
		assertEquals(expected,actual);
	}
	@Test
	@Tag("DEV")
	@Disabled
	public void testDisabled() {
		assertTrue(true);
		System.out.println("this test condition is disabled");
	}

	@Test
	@Tag("DEV")
	@DisplayName("Give proper display name")
	public void displaysName() {
		System.out.println("--displays name--");
		assertTrue(true);
	}
	
	@Test
	@Tag("DEV")
	public void sumPositive() {
		int expected=15;
		int no1=10;
		int no2=5;
		int actual=calculator.sum(no1,no2);
		assertEquals(expected,actual);
	}

}
