package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class JUnit5ParameterizedTestRepeatTest {

	@RepeatedTest(value=5)
	void test() {
     assertEquals("Sabbir","Sabbir");
	}
	@ParameterizedTest
	@ValueSource(strings = {"sabbir","sachin","sumeet"})
	void testNames(String name) {
		assertTrue(name.length()>5);
	}

}
