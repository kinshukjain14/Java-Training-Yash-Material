package com.yash.controller;

import java.util.List;

import com.yash.entity.Employee;
import com.yash.service.EmployeeService;

public class EmployeeController {
	
	private EmployeeService employeeService;
	public List<Employee> handleRequestForAllEmployee(){
		//apart from other computations
		return employeeService.getEmployees();
	}
	public Employee handleRequestForEmployeeById(int empId) {
		return employeeService.getEmployee(empId);
	}

}
