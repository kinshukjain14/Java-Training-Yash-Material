package com.yash.service;

public class AddServiceImpl implements AddService {

	@Override
	public int add(int no1, int no2) {
		System.out.println("--Real method--");
		return no1+no2;
	}

}
