package com.yash.service;

import java.util.List;

import com.yash.entity.Employee;

public interface EmployeeService {
	
	List<Employee> getEmployees();
	Employee getEmployee(int empId);

}
