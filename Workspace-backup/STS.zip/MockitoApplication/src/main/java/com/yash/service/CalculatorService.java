package com.yash.service;

public class CalculatorService {

	private AddService addService;
	
	public CalculatorService(AddService addService) {
		this.addService = addService;
	}

	public int calc(int no1,int no2) {
		//xxx
		//xxx
		//xxx
		int a= addService.add(no1, no2);
		int b=a*a*a;
		return b;
	}
}
