package com.yash.service;

public interface AddService {
	public int add(int no1,int no2);
}
