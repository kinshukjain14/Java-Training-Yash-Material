package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;

import com.yash.service.AddService;
import com.yash.service.CalculatorService;

class TestCalculatorServiceMock {

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testCalcPositive() {
	   AddService addServiceMock=mock(AddService.class);
	   
       CalculatorService calculatorService= new CalculatorService(addServiceMock);
       int no1=10;
       int no2=5;
       int expected=3375;
	   when(addServiceMock.add(no1, no2)).thenReturn(15);
       int actual=calculatorService.calc(no1, no2);
       assertEquals(expected,actual);
	}

}
