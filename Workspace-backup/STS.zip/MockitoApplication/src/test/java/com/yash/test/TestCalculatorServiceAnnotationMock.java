package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.yash.service.AddService;
import com.yash.service.CalculatorService;

class TestCalculatorServiceAnnotationMock {
	@Mock
	private AddService addServiceMock;
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	void testCalcPositive() {
	   
       CalculatorService calculatorService= new CalculatorService(addServiceMock);
       int no1=10;
       int no2=5;
       int expected=3375;
	   when(addServiceMock.add(no1, no2)).thenReturn(15);
       int actual=calculatorService.calc(no1, no2);
       assertEquals(expected,actual);
	}
	@Test
	void testVerifyTimes() {
	       CalculatorService calculatorService= new CalculatorService(addServiceMock);
	       int no1=10;
	       int no2=5;
		   when(addServiceMock.add(no1, no2)).thenReturn(15);
	       calculatorService.calc(no1, no2);
	       verify(addServiceMock,times(1)).add(no1, no2);
	}
	@Test
	void testVerifyTimesAny() {
	       CalculatorService calculatorService= new CalculatorService(addServiceMock);
	       int no1=10;
	       int no2=5;
		   when(addServiceMock.add(anyInt(), anyInt())).thenReturn(15);
	       calculatorService.calc(no1, no2);
	       verify(addServiceMock,times(1)).add(anyInt(), anyInt());
	}


}
