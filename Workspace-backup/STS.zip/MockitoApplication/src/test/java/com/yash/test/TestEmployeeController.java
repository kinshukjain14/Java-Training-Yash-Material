package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.yash.controller.EmployeeController;
import com.yash.entity.Employee;
import com.yash.service.EmployeeService;

class TestEmployeeController {
	
	@Mock
	private EmployeeService employeeService;

	@InjectMocks
	private EmployeeController controller;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testHandleRequestForAllEmployeePositive() {
    when(employeeService.getEmployees()).then(new Answer<List<Employee>>() {
		@Override
		public List<Employee> answer(InvocationOnMock invocation) throws Throwable {

			Employee e1=new Employee();
			e1.setEmpId(1001);
			e1.setEmpName("sabbir");
			e1.setEmpDesignation("Trainer");
			e1.setEmpSalary(34000);
			Employee e2=new Employee();
			e2.setEmpId(1002);
			e2.setEmpName("amit");
			e2.setEmpDesignation("Software programmer");
			e2.setEmpSalary(54000);
			Employee e3=new Employee();
			e3.setEmpId(1003);
			e3.setEmpName("chirag");
			e3.setEmpDesignation("Developer");
			e3.setEmpSalary(74000);
			List<Employee> empList=new ArrayList<Employee>();
			empList.add(e1);
			empList.add(e2);
			empList.add(e3);
			return empList;
					}
    });
    List<Employee> actual=controller.handleRequestForAllEmployee();
    assertTrue(actual.size()>0);
	}

	@Test
	void testHandleRequestForAllEmployeeLambda() {
    when(employeeService.getEmployees()).then((invocation)-> {

			Employee e1=new Employee();
			e1.setEmpId(1001);
			e1.setEmpName("sabbir");
			e1.setEmpDesignation("Trainer");
			e1.setEmpSalary(34000);
			Employee e2=new Employee();
			e2.setEmpId(1002);
			e2.setEmpName("amit");
			e2.setEmpDesignation("Software programmer");
			e2.setEmpSalary(54000);
			Employee e3=new Employee();
			e3.setEmpId(1003);
			e3.setEmpName("chirag");
			e3.setEmpDesignation("Developer");
			e3.setEmpSalary(74000);
			List<Employee> empList=new ArrayList<Employee>();
			empList.add(e1);
			empList.add(e2);
			empList.add(e3);
			return empList;
    });
    List<Employee> actual=controller.handleRequestForAllEmployee();
    assertTrue(actual.size()>0);
	}
	
	@Test
	void testhandleRequestForEmployeeByIdPositive() {
		when(employeeService.getEmployee(1001)).then(new Answer<Employee>() {
			@Override
			public Employee answer(InvocationOnMock invocation) throws Throwable {
				Object args[]=invocation.getArguments();
				int arg1=(Integer)args[0];
				Employee e1=new Employee();
				if(arg1==1001) {
					e1.setEmpId(1001);
					e1.setEmpName("sabbir");
					e1.setEmpDesignation("Trainer");
					e1.setEmpSalary(34000);	
				}
				return e1;
			}
		});
		Employee actual=controller.handleRequestForEmployeeById(1001);
		assertTrue(actual.getEmpId()==1001);
		
	}

}
