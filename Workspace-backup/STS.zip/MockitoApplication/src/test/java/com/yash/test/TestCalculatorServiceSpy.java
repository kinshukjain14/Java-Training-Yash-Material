package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import com.yash.service.AddService;
import com.yash.service.AddServiceImpl;
import com.yash.service.CalculatorService;

class TestCalculatorServiceSpy {

	@Spy
	private AddServiceImpl addServiceImpl;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testCalcPositiveMethod() throws InstantiationException, IllegalAccessException {
	   AddService addService= Mockito.spy(new AddServiceImpl());
       CalculatorService calculatorService= new CalculatorService(addService);
       int no1=10;
       int no2=5;
       int expected=3375;
       int actual=calculatorService.calc(no1, no2);
       assertEquals(expected,actual);
	}
	
	@Test
	void testCalcPositiveAnnotation() {
       CalculatorService calculatorService= new CalculatorService(addServiceImpl);
       int no1=10;
       int no2=5;
       int expected=3375;
       int actual=calculatorService.calc(no1, no2);
       assertEquals(expected,actual);
	}

}
