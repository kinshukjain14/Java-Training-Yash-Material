package Student_Object_Reference;

@FunctionalInterface
public interface StudentFactory {
	public Student getInstance();
}
