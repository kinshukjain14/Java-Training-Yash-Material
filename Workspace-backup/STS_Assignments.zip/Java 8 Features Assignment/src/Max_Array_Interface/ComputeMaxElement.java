package Max_Array_Interface;

@FunctionalInterface
public interface ComputeMaxElement {
	public Integer max(Integer[] arr);
}
