package com.yash.service;

import com.yash.exception.AuthenticationException;

public interface UserService {
	public boolean authenticateUser(String userName,String password) throws AuthenticationException;
}
