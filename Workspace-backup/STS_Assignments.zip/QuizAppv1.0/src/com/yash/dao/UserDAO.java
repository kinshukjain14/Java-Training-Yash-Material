package com.yash.dao;

public interface UserDAO {
	public boolean checkUserCredentials(String userName, String password);
}
