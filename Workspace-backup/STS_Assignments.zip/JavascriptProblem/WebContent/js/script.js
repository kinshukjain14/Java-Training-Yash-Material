$(document).ready(
			function() {
				$("button").click(function() {
					$.ajax({
						url : "SampleServlet",
						type : "POST",
						data:{
							abc:"ss"
						},
						success : function(response) {
							var x = "true";
							document.write("var x text : " + x);
							document.write("<br>");
							document.write("Response text : " + response);
							document.write("<br>");
							document.write("Response text type : "
									+ typeof response);
							document.write("<br>");
							document.write("Response == 'true' text type : "
									+ (response == 'true'));
							document.write("<br>");
							document.write("Response === 'true' text type : "
									+ (response === 'true'));
							document.write("<br>");
							document.write("Response == x text type : "
									+ (response == x));
							document.write("<br>");
							document.write("Response === x text type : "
									+ (response === x));
							document.write("<br>");
						},
						error : function(status) {
							alert("Error" + status)
						}
					});
				});
			});