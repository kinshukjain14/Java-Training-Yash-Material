package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.yash.controller.QuizQuestionController;
import com.yash.exception.QuestionParsingException;
import com.yash.model.QuestionModel;
import com.yash.model.SubjectDataModel;

class TestQuizQuestionController {

	private static QuizQuestionController controller;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		controller = new QuizQuestionController();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		controller = null;
	}
	@DisplayName("Get Questions list from controller : positive")
	@Test
	void test1() {
		try {
			SubjectDataModel subjectQuestions = controller.handleSubjectquestion("Java");
			List<QuestionModel> questionsList = subjectQuestions.getQuestionsList();
			assertTrue(questionsList.size()!=0);
		} catch (QuestionParsingException e) {
			assertTrue(false);
		}
	}
	
	@DisplayName("Get Questions list from controller : Negative")
	@Test
	void test2() {
		try {
			SubjectDataModel subjectQuestions = controller.handleSubjectquestion("Node js");
			List<QuestionModel> questionsList = subjectQuestions.getQuestionsList();
			assertTrue(!(questionsList.size()!=0));
		} catch (QuestionParsingException e) {
		}
		assertTrue(true);
	}
	
	@DisplayName("Check Question having 4 options from controller")
	@Test
	void test3() {
		boolean expectedFlag=true;
		try {
			SubjectDataModel subjectQuestions = controller.handleSubjectquestion("Node js");
			List<QuestionModel> questionsList = subjectQuestions.getQuestionsList();
			for (QuestionModel questionModel : questionsList) {
				Map<String, Boolean> optionsMap = questionModel.getOptionsMap();
				if(optionsMap.size()<4) {
					expectedFlag=false;
					break;
				}
			}
		} catch (QuestionParsingException e) {
		}
		assertTrue(expectedFlag);
	}


}
