package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.xml.sax.SAXException;

import com.yash.dao.QuizQuestionsDAO;
import com.yash.entity.Question;
import com.yash.entity.Subject;
import com.yash.helper.QuizFactory;

class TestQuizQuestionDAO {

	private static QuizQuestionsDAO dao;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		dao = QuizFactory.newDAOInstance();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		dao=null;
	}

	@DisplayName("Check the Subject requested is available for quiz : Positive")
	@Test
	void test1() {
		try {
			Subject subjects = dao.retriveSubjects("Java");
			List<Question> questions = subjects.getQuestions();
			System.out.println(questions.size());
			assertTrue(questions.size()>0);
		} catch (ParserConfigurationException | SAXException | IOException e) {
		}
	}
	@DisplayName("Check the Subject requested is not available for quiz : Negative")
	@Test
	void test2() {
		try {
			Subject subjects = dao.retriveSubjects("node");
			List<Question> actual = subjects.getQuestions();
			assertTrue(!(actual.size()>0));
		} catch (ParserConfigurationException | SAXException | IOException e) {
		}
	}

}
