package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.yash.dao.UserDAO;
import com.yash.entity.User;
import com.yash.helper.QuizFactory;

class TestUserDAO {

	private static UserDAO dao;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		dao = QuizFactory.newUserDao();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		dao=null;
	}

	@DisplayName("Check user credentials from data source : Positive")
	@Test
	void test1() {
		String username = "kinshuk.jain14";
		String password = "kinshu123";
		
		boolean check = dao.checkUserCredentials(username, password);
		assertTrue(check);
	}

	@DisplayName("Check user credentials from data source : Negative")
	@Test
	void test2() {
		String username = "kinshuk.jain";
		String password = "kinshu123";
		
		boolean check = dao.checkUserCredentials(username, password);
		assertTrue(!check);
	}

	@DisplayName("Check if user data is available in data source or not")
	@Test
	void test3() {
		String username = "ashutosh12";
		String password = "12345";
		dao.checkUserCredentials(username, password);
		Optional<User> response = dao.requestUserResponse();
		assertTrue(response.isPresent());
	}
	
}
