package com.yash.dao;

import com.yash.entity.Module;
import com.yash.exception.DAOException;

public interface QuizQuestionsDAO 
{
	public Module retriveSubjects(String subjectName) throws DAOException;
}
