package com.yash.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Optional;

import com.yash.entity.User;
import com.yash.exception.DAOException;
import com.yash.helper.ConnectionManager;

public class JDBCUserDAOImpl implements UserDAO {

	private static int userId;
	private ConnectionManager manager = new ConnectionManager();
	
	@Override
	public boolean checkUserCredentials(String userName, String password) throws DAOException {
		boolean status = false;
		try(
				Connection connection = manager.openConnection();
				)
		{
			CallableStatement statement = connection.prepareCall("{call sp_getUserId(?,?,?)}");
			statement.setString(1, userName);
			statement.setString(2, password);
			statement.registerOutParameter(3, Types.INTEGER);
			statement.execute();
			userId=statement.getInt(3);
			if(userId!=0) {
				status=true;
			}
			else {
				status=false;
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new DAOException(e,"DAO Exception : username or password does not exist");
		}
	return status;
	}

	@Override
	public Optional<User> requestUserResponse() throws DAOException {
		Optional<User> userData=null;
		try(
				Connection connection = manager.openConnection();
				){
			CallableStatement statement = connection.prepareCall("{call sp_getUserDetails(?)}");
			statement.setInt(1, userId);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) {
				User user = new User(resultSet.getInt("user_id"), resultSet.getString("user_name")
						, resultSet.getString("password"), resultSet.getString("first_name")+" "+resultSet.getString("last_name")
						, resultSet.getString("email"), resultSet.getLong("contact"));
				userData=Optional.of(user);
			}			
		} catch (ClassNotFoundException | SQLException e) 
		{
			throw new DAOException(e,"DAO Exception : username or password does not exist");
		}
		return userData;
	}

	@Override
	public boolean registerUser(User user) throws DAOException {
		try(
				Connection connection = manager.openConnection();
				){
			PreparedStatement statement=connection.prepareStatement("insert into users values(?,?,?,?,?,?,?,?,?)");
			String[] split = user.getName().split(" ");
			statement.setInt(1, user.getUserId());
			statement.setString(2, split[0]);
			statement.setString(3, split[1]);
			statement.setString(4, user.getEmail());
			statement.setLong(5, user.getContactNo());
			statement.setString(6, user.getUserName());
			statement.setString(7, user.getPassword());
			statement.setTimestamp(8, java.sql.Timestamp.valueOf(user.getRegisteredOn()));
			statement.setTimestamp(9, java.sql.Timestamp.valueOf(user.getLastLogin()));
			int rows=statement.executeUpdate();
			if(rows>0) {
				return true;
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new DAOException(e, "DAO Exception : unable to add record in table");
		}
		return false;
	}

}
