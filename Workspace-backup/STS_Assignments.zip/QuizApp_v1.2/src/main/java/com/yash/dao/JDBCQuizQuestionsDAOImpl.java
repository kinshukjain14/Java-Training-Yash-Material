package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.yash.entity.Module;
import com.yash.entity.Option;
import com.yash.entity.Question;
import com.yash.exception.DAOException;
import com.yash.helper.ConnectionManager;

public class JDBCQuizQuestionsDAOImpl implements QuizQuestionsDAO{

	private String sqlQuery;
	private int module_id;
	@Override
	public Module retriveSubjects(String subjectName) throws DAOException 
	{
		switch(subjectName) {
			case "Java":
				sqlQuery="SELECT * FROM quizdb.java_module";
				break;
			case "SQL":
				sqlQuery="SELECT * FROM quizdb.sql_module";
				break;
			case "HTML":
				sqlQuery="SELECT * FROM quizdb.html_module";
				break;
			case "CSS":
				sqlQuery="SELECT * FROM quizdb.css_module";
				break;
			default:
				sqlQuery="";
				break;
		}
		
		ConnectionManager manager = new ConnectionManager();
		Module module=null ;
		try(Connection connection = manager.openConnection())
		{
			PreparedStatement statement = connection.prepareStatement(sqlQuery);
			ResultSet resultSet = statement.executeQuery();
			List<Question> qList=new ArrayList<Question>();			
			
			while(resultSet.next())
			{
				int ques_id = resultSet.getInt("ques_id");
				module_id = resultSet.getInt("module_id");
				String ques_desc=resultSet.getString("ques_desc");
				Question question = new Question();
				question.setQuestionId(ques_id);
				question.setQuestions(ques_desc);
				Option op = new Option();		
					do
					{
						int tempId = resultSet.getInt("ques_id");
						int option_id = resultSet.getInt("option_id");						
						String option_desc=resultSet.getString("option_desc");
						int check = resultSet.getInt("Correct");
						if(tempId == ques_id) 
						{
							op.setOptionId(option_id);						
							op.setOptions(option_desc, check==1);
							question.setOption(op);
							if(resultSet.isLast()) {
								qList.add(question);
							}
							continue;
						}
						else 
						{
							qList.add(question);
							resultSet.previous();
							break;
						}
					}while(resultSet.next());
			}
			module = new Module(module_id, subjectName, qList);
			
		} catch (ClassNotFoundException | SQLException e) 
		{
			throw new DAOException(e, "DAO Exception : unable to load questions");
		}
		return module;
	}

}
