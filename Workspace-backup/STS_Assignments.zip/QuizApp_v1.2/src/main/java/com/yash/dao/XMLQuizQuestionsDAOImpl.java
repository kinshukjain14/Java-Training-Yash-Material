package com.yash.dao;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.yash.entity.Module;
import com.yash.exception.DAOException;

public class XMLQuizQuestionsDAOImpl implements QuizQuestionsDAO{

	@Override
	public Module retriveSubjects(String subjectName) throws DAOException
	{
		DataHandler dataHandler = new DataHandler(subjectName);
		File file = new File("src\\main\\java\\com\\yash\\resources\\testpaper.xml");
		SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
		SAXParser saxParser;
		try {
			saxParser = saxParserFactory.newSAXParser();
			InputSource source = new InputSource(file.getPath());
			source.setEncoding(StandardCharsets.UTF_8.displayName());
			
			saxParser.parse(source, dataHandler);
			
		} catch (ParserConfigurationException | SAXException | IOException e) {
			throw new DAOException(e, "DAO Exception : Exception in parsing data source");
		}
		
		Module subject = dataHandler.getSubjectQuestions(); 
		return subject;
	}

}
