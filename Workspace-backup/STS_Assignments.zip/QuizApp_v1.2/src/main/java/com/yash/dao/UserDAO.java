package com.yash.dao;

import java.util.Optional;

import com.yash.entity.User;
import com.yash.exception.DAOException;

public interface UserDAO
{
	public boolean checkUserCredentials(String userName, String password) throws DAOException;
	public Optional<User> requestUserResponse() throws DAOException;
	public boolean registerUser(User user) throws DAOException;
}
