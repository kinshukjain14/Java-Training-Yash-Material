package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.mysql.cj.jdbc.CallableStatement;
import com.yash.dao.UserDAO;
import com.yash.entity.User;
import com.yash.exception.DAOException;
import com.yash.helper.ConnectionManager;
import com.yash.helper.QuizFactory;

class TestUserDAO {

	@Mock
	private ConnectionManager manager;
	
	@Mock
	private Connection connection;
	
	@Mock
	private CallableStatement statement;
	
	@Mock
	private ResultSet resultSet;
	
	@InjectMocks
	private static UserDAO dao;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception 
	{
		dao = QuizFactory.newUserDao();
	}
	
	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@DisplayName("Check user credentials from data source : Positive")
	@Test
	void testUserCredentialsFromDataSource_Positive() throws DAOException, SQLException, ClassNotFoundException {
		String username = "kinshuk.jain14";
		String password = "kinshu123";
		
		when(manager.openConnection()).thenReturn(connection);
		when(connection.prepareCall(anyString())).thenReturn(statement);
		when(statement.getInt(3)).thenReturn(12211);
		boolean check = dao.checkUserCredentials(username, password);
		assertTrue(check);
	}

	@DisplayName("Check user credentials from data source : Negative")
	@Test
	void testUserCredentialsFromDataSource_Negative() throws SQLException, ClassNotFoundException, DAOException {
		String username = "kinshuk.jain";
		String password = "kinshu123";
		when(manager.openConnection()).thenReturn(connection);
		when(connection.prepareCall(anyString())).thenReturn(statement);
		when(statement.getInt(3)).thenReturn(0);
		boolean actual=dao.checkUserCredentials(username, password);
		assertTrue(!actual);
	}
	
	@SuppressWarnings("unchecked")
	@DisplayName("Check user credentials from data source : Exception")
	@Test
	void testUserCredentialsFromDataSource_Exception() throws SQLException, ClassNotFoundException {
		try {
		String username = "kinshuk.jain";
		String password = "kinshu123";
		when(manager.openConnection()).thenReturn(connection);
		when(connection.prepareCall(anyString())).thenThrow(DAOException.class);
		
		dao.checkUserCredentials(username, password);
		}
		catch(DAOException e) {
			assertTrue(true);
		}
	}

	@DisplayName("Check if user data is available in data source or not : Positive")
	@Test
	void testCheckIfUserDataIsAvailableInDataSourceOrNot_Positive() throws DAOException, SQLException, ClassNotFoundException {
		when(manager.openConnection()).thenReturn(connection);
		when(connection.prepareCall(anyString())).thenReturn(statement);
		when(statement.executeQuery()).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(true).thenReturn(false);
		Optional<User> response = dao.requestUserResponse();
		assertTrue(response.isPresent());
	}
	
	@DisplayName("Check if user data is available in data source or not : Negative")
	@Test
	void testCheckIfUserDataIsAvailableInDataSourceOrNot_Negative() throws DAOException, SQLException, ClassNotFoundException {
		when(manager.openConnection()).thenReturn(connection);
		when(connection.prepareCall(anyString())).thenReturn(statement);
		when(statement.executeQuery()).thenReturn(resultSet);
		when(resultSet.next()).thenReturn(false);
		Optional<User> response = dao.requestUserResponse();
		assertTrue(response==null);
	}
	
}
