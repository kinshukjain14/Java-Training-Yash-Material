package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import com.yash.controller.QuizQuestionController;
import com.yash.exception.QuestionParsingException;
import com.yash.model.QuestionModel;
import com.yash.service.QuizServices;
import com.yash.model.ModuleDataModel;

class TestQuizQuestionController {

	@Mock
	private QuizServices service;
	
	@InjectMocks
	private QuizQuestionController controller;
	
	@BeforeEach
	void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}
	
	@DisplayName("Get Questions list from controller : positive")
	@Test
	void testGetquestionsListIfSizeGreaterThanZero() {
		try {
			when(service.getSubjectQuestions("Java")).then((invocation)->{
				List<QuestionModel> qList = new ArrayList<>();
				String x = "xx";
				Map<String, Boolean> map = new HashMap<>();
				qList.add(new QuestionModel(x,map));
				qList.add(new QuestionModel(x,map));
				qList.add(new QuestionModel(x,map));
				qList.add(new QuestionModel(x,map));
				return new ModuleDataModel(qList);
			});
			ModuleDataModel subjectQuestions = controller.handleSubjectquestion("Java");
			List<QuestionModel> questionsList = subjectQuestions.getQuestionsList();
			assertTrue(questionsList.size()!=0);
		} catch (QuestionParsingException |NullPointerException e) {
			e.printStackTrace();
			assertTrue(false);
		}
	}
	
	@DisplayName("Get Questions list from controller : Negative")
	@Test
	void testGetQustionsListIfSizeIsNotGeaterThanZero() {
		try {
			when(service.getSubjectQuestions("Node js")).then((invocation)->{
				List<QuestionModel> qList = new ArrayList<>();
				return new ModuleDataModel(qList);
			});
			ModuleDataModel subjectQuestions = controller.handleSubjectquestion("Node js");
			List<QuestionModel> questionsList = subjectQuestions.getQuestionsList();
			assertTrue(questionsList.size()==0);
		} catch (QuestionParsingException e) 
		{
			assertTrue(false);			
		}
	}
	
	@DisplayName("Check Question having 4 options from controller")
	@Test
	void testCheckQuestionsHaving4Options() {
		boolean expectedFlag=true;
		try {
			when(service.getSubjectQuestions("Node js")).then((invocation)->
			{
				Map<String,Boolean> map = new HashMap<>();
				map.put("Q", false);
				map.put("A", false);
				map.put("B", false);
				map.put("C", false);
				
				List<QuestionModel> qList = new ArrayList<>();
				qList.add(new QuestionModel("a", map));
				qList.add(new QuestionModel("b", map));
				qList.add(new QuestionModel("c", map));
				qList.add(new QuestionModel("d", map));
				
				return new ModuleDataModel(qList);
			});
			ModuleDataModel subjectQuestions = controller.handleSubjectquestion("Node js");
			List<QuestionModel> questionsList = subjectQuestions.getQuestionsList();
			for (QuestionModel questionModel : questionsList) 
			{
				Map<String, Boolean> optionsMap = questionModel.getOptionsMap();
				if(optionsMap.size()<4) {
					expectedFlag=false;
					break;
				}
			}
		} catch (QuestionParsingException e) {
		}
		assertTrue(expectedFlag);
	}


}
