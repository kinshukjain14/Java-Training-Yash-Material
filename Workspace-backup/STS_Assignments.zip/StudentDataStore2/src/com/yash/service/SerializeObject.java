package com.yash.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import com.yash.entity.Student;
import com.yash.model.StudentModel;

public class SerializeObject {
	
	public boolean serializeStudentObject(List<StudentModel> studentsList) {
		File file = new File("D:\\STS\\StudentDataStore\\src\\com\\yash\\resources");
		List<Student> list = new ArrayList<>();
		
		for (StudentModel student : studentsList) 
		{
			Student s = new Student();
			s.setName(student.getName());
			s.setRollNo(student.getRollNo());
			s.setScoreList(student.getScoreList());
			s.setPercentage(student.getPercentage());
			list.add(s);
		}
		
		try(
				OutputStream os = new FileOutputStream(file.getAbsolutePath()+"\\student.dat");
				ObjectOutputStream oos = new ObjectOutputStream(os);
				){
			if(file.isDirectory()) 
			{
				oos.writeObject(list);
				return true;
			}
			else {
				throw new IOException("Directory does not exist");
			}
		}
		catch(IOException e) {
			System.err.println(e.getMessage());
			return false;
		}
	
	}
}
