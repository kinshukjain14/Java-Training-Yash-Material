package com.yash.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import com.yash.entity.Student;
import com.yash.model.StudentModel;

public class DeserializeObject
{
	
	@SuppressWarnings("unchecked")
	public List<StudentModel> deserializeStudentObject()
	{
		File file = new File("D:\\STS\\StudentDataStore\\src\\com\\yash\\resources");
		try(
				InputStream is = new FileInputStream(file.getAbsoluteFile()+"\\student.dat");
				ObjectInputStream ois = new ObjectInputStream(is);
				){
			if(file.isDirectory()) 
			{	
				List<StudentModel> model = new ArrayList<>();
				List<Student> lists = (List<Student>)ois.readObject();
				for (Student student : lists) {
					StudentModel sm = new StudentModel();
					sm.setRollNo(student.getRollNo());
					sm.setName(student.getName());
					sm.setScoreList(student.getScoreList());
					sm.setPercentage(student.getPercentage());
					model.add(sm);
				}
				
				return model;
			}
			else 
			{
				throw new IOException("Directory does not exist");
			}
		}
		catch(IOException | ClassNotFoundException e) {
			System.err.println(e.getMessage());
			return null;
		}
	
	}
}
