package com.yash.controller;

import java.util.List;

import com.yash.model.StudentModel;
import com.yash.service.DeserializeObject;
import com.yash.service.SerializeObject;

public class StudentModelController {
	public boolean handleSerialization(List<StudentModel> studentsList) {
		return new SerializeObject().serializeStudentObject(studentsList);
	}
	
	public List<StudentModel> handleDeserialize()
	{
		return new DeserializeObject().deserializeStudentObject();
	}
}
