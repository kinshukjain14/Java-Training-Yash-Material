package com.yash.ui;

import com.yash.view.MainMenu;

public class UIClient 
{
	public static void main(String[] args) 
	{
		MainMenu.mainMenu();
	}

}
