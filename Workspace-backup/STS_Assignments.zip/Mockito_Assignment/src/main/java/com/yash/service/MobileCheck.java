package com.yash.service;

public interface MobileCheck {
	boolean checkMobileNumber(String number);
}
