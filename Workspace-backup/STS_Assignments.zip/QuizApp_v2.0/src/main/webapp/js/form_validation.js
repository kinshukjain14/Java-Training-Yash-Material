var successCode="success";

$(document).ready(function() {
	
    $(document).tooltip();
    $('#password').tooltip({ content: $('#policy').html() });

    // Sign in form validation 
    $("form[name='signin']").validate({
        rules: {
            username:"required", 
            password:"required",
        },
        messages: {
            username:"",
            password:""
        },
        highlight:function(element){
            $(element).css("border","2px solid red");
        },
        unhighlight:function(element){
            $(element).css("border","0px solid red");
        },
        submitHandler: function(form) {
        	var dataObject={
        			username:$('#username').val(),
    				password:$('#password').val()	
        	};
        	
            ajaxCall(form,dataObject,handleSignInSuccess);	      
        },
    });
    
    //Sign Up form validation
    $.validator.addMethod("regex",function(value,element,regularExpression){
        var regex = new RegExp(regularExpression);
        return this.optional(element) || regex.test(value); 
     });
    $.validator.addMethod("valueNotEquals", function(value, element, arg){
    	  return arg !== value;
    });

    $("form[name='signup']").validate({
        rules: {
            firstName:{
                required:true,
                digits:false,
                regex:'[A-Z][a-z]*',
            },
            lastName:{
                required:true,
                digits:false,
                regex:"[A-Z][a-z]*"
            },
            contact:{
                digits:true,
                required:true,
                regex:'^[6-9][0-9]{9}',
            },
            email:{
                required:true, 
                email:true,
            },
            password:{
                required:true,
                regex:"^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,20}$"
            },
            cnfpassword:{
                required:true,
                equalTo:"#password"
            },
            dateOfBirth:'required',
            gender:'required',
            address :'required',
            countries:{ valueNotEquals: "-1" },
            states:{ valueNotEquals: "-1" },
            cities:{ valueNotEquals: "-1" },
        },
        messages: {
            firstName:"",
            lastName:"",
            contact:"",
            email:"",
            password:"",
            cnfpassword:"",
            dateOfBirth:"",
            gender:"",
            address:"",
            countries:"",
            states:"",
            cities:"",
        },
        highlight:function(element){
            $(element).css("border","2px solid red");
        },
        unhighlight:function(element){
            $(element).css("border","0px solid red");
        },
        submitHandler: function(form) {
        	var dataObject={
        		firstName : $("#firstName").val(),
        		lastName : $("#lastName").val(),
        		contact : $("#contact").val(),
        		email : $("#email").val(),
        		password : $("#password").val(),
        		dateOfBirth : $("#dateOfBirth").val(),
        		gender : $("input[type='gender']").val(),
        		address : $("#address").val(),
        		countries : $("#countries option:selected").text(),
        		states : $("#states option:selected").text(),
        		cities : $("#cities option:selected").text()
        	};
            ajaxCall(form,dataObject,handleSignUpSuccess);
        },
    });
    
    $("#countries").bind('change',function(event,ui){
    	var countryId = $(this).val();
    	let data = {
    		type:'country',
    		code:countryId
    	}
    	
    	let form ={
    		action:'location',
    		method:'POST'
    	}
    	let successMethod = (response)=>{
    		$('#states').html('')
    		$('<option value="-1">( Select )</option>').appendTo('#states');
    		$.each(response,(index,element)=>{
    			$('<option value="'+element.stateId+'">'+element.stateName+'</option>').appendTo('#states');
    		})
    		$('<option value="other"> Other </option>').appendTo('#states');
    	}
    	ajaxCall(form,data,successMethod);
    });
    
    $("#states").bind('change',function(event,ui){
    	let stateId = $(this).val();
    	let data = {
    		type:'state',
    		code:stateId
    	}
    	
    	let form ={
    		action:'location',
    		method:'POST'
    	}
    	let successMethod = (response)=>{
    		$('#cities').html('')
    		$('<option value="-1">( Select )</option>').appendTo('#cities');
    		$.each(response,(index,element)=>{
    			$('<option value="'+element.cityId+'">'+element.cityName+'</option>').appendTo('#cities');
    		})
    		$('<option value="other"> other </option>').appendTo('#cities');
    	}
    	ajaxCall(form,data,successMethod);
    });
    
});

function ajaxCall(form,dataObject,methodCall){
	 $.ajax({
			url:form.action,
			type:form.method,
			data:dataObject,
			beforeSend:function(){
				$('#overlay').fadeIn(300);
			},
			success:methodCall,
			error:function(status){
				Swal.fire({
				  icon: 'error',
				  title: 'Oops...',
				  text: 'Something went wrong!',
				})
			},
			complete:function(){
				$('#overlay').fadeOut(300);
			}
		});
}

function handleSignInSuccess(response){
		if(response.successflag == "true"){
			Swal.fire({
				  icon: 'success',
				  title: 'Welcome',
				}).then((result)=>{
					window.open("Dashboard.jsp","_self");            						
				});
			
		}
		else if(response.successflag == "false") {
			Swal.fire({
			  icon: 'info',
			  title: 'Oops...',
			  text: 'Invalid username or password!!',
			})
		}
}

function handleSignUpSuccess(response){
	if(response.successflag == "true"){
		Swal.fire({
			  icon: 'success',
			  title: 'Registration Successful',
			}).then((result)=>{
				window.open("SignIn.jsp","_self");            						
			});
		
	}
	else if(response.successflag == "false") {
		Swal.fire({
		  icon: 'info',
		  title: 'Oops...',
		  text: response.message,
		})
	}
}