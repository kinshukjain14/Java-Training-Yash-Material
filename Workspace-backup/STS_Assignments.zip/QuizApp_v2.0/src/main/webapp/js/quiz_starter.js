var moduleQuestions;
var ques_count = 0;
var progress = 0;
var maxTime = 15;
var startTimer;
var timeLeft;
var answerChoice;
var score = 0;
var answered = 0;
var duration=0;
var candidateId = 0;

var param;
const urlSearchParams = new URLSearchParams(window.location.search);
const params = Object.fromEntries(urlSearchParams.entries());

$(document).ready(function () {
	candidateId = Math.floor(Math.random() * 1000000000000);
	
    $.ajax({
        type: "GET",
        url: "fetchquestion?module="+params.module,
        datatype: "json",
        beforeSend:function(){
        	 $('#overlay').fadeIn(300);
        },
        success: function (data) {
            moduleQuestions = Object.assign(data);
// console.log(moduleQuestions)
        },
        error: function (xhr, ajaxOptions, thrownError) {
        	Swal.fire({
				  icon: 'error',
				  title: 'Oops...',
				  text: 'Something went wrong!!',
				})
        },
        complete:function(){
        	$('#overlay').fadeOut(300);
        }
    });

    $('.start_btn').button();
    $('.info-box').css('display', 'none');
    $('.quiz-box').css('display', 'none');
    $('.result-box').css('display', 'none');

    $(".start_btn").click(function () {
        var dialogBox = $('.info-box');
        $('.start_btn').hide();
        if (dialogBox.hasClass('ui-dialog-content')) {
            dialogBox.dialog('open');
        }
        else {
            dialogBox.dialog({
                autoOpen: true,
                title: "Instructions for Quiz",
                width: 550,
                height: 350,
                escape: true,
                draggable: false,
                buttons: [
                    {
                        text: "Proceed",
                        open: function () { },
                        click: function () {
                            dialogBox.dialog('close')
                            loadQuizQuestions(1);
                        }
                    }
                ],
                show: {
                    effect: "fade",
                    duration: 100
                },
                hide: {
                    effect: "fade",
                    duration: 100
                },
                close: function () {
                    $('.start_btn').show();
                }
            });
        }
    });


});

function loadQuizQuestions(params) {
    $('.quiz-box').dialog({
        dialogClass: "no-titlebar",
        draggable: false,
        resizable: false,
        width: 800,
        height: 510,
        closeOnEscape: false,
        buttons: [
            {
                text: "Next Question",
                id: 'nxt-btn',
                open: function () {
                    $(".timeline").progressbar();
                    loadData();
                },
                click: function () {
                    clearInterval(startTimer);
                    loadData();
                }
            }
        ],
    });
}

var loadData = () => {
    if (ques_count < moduleQuestions.questionsList.length) {
        startTimer = setInterval(timer, 1000);
        showQuestion();
        ques_count++;
    }
    if(ques_count == moduleQuestions.questionsList.length)
    {
    	clearInterval(startTimer);
    	$.ajax({
    		url:'savescore',
			type:'POST',
			data:{
				correct : score,
				totalAttempt : answered,
				totalQuestions : moduleQuestions.questionsList.length,
				timeTaken : duration,
				candidateID : candidateId
			},
			beforeSend:function(){
				$('#overlay').fadeIn(300);
			},
			success:function(response){
				$('.quiz-box').dialog('close');
				if(response.responseText == "true"){
					Swal.fire({
						  icon: 'success',
						  title: 'Your Performance',
						  html:	
							  '<p>Percentage : '+response.percentage+'%</p>'+
							  '<p>Total Questions : '+moduleQuestions.questionsList.length+'</p>'+
							  '<p>Correct : '+response.correct+'</p>'+
							  '<p>Attempted : '+response.attempted+'</p>'+
							  '<p>Unanswered : '+response.unanswered+'</p>'+
							  '<p>Status : '+response.status+'</p>'+
							  '<p>Grade : '+response.grade+'</p>',
						}).then((result)=>{
							window.close();
						});
				}
				else if(response.responseText == "false") {
					Swal.fire({
						  icon: 'error',
						  title: 'Oops...',
						  text: 'Unable to generate scores, error in application!',
						})
				}
			},
			error:function(status){
				Swal.fire({
				  icon: 'error',
				  title: 'Oops...',
				  text: 'Something went wrong!',
				})
			},
			complete:function(){
				$('#overlay').fadeOut(300);
			}
    	});	
    }
}

function updateProgress() {
    $(".timeline").progressbar({
        value: ++progress,
        max: 15
    });
}

function timer() {
    updateProgress();
    timeLeft = --maxTime;
    if (timeLeft < 10) {
        timeLeft = "0" + timeLeft;
    }
    else {
        timeLeft = timeLeft + "";
    }
    if (timeLeft == 0) {
        maxTime = 15;
        progress = 0;
        clearInterval(startTimer);
        setTimeout(()=>{
            $("#nxt-btn").click();
        },1000)
    }
    $('.time-left-sec').html(timeLeft);
}

function showQuestion() {
    $('.total-ques').text('Question : '+(ques_count+1)+' of '+moduleQuestions.questionsList.length);
    maxTime = 15;
    duration += progress;
    progress = 0;
    var main = $('main');
    main.html('');
    $('<div class="ques-text">' + (ques_count + 1) + ". " + moduleQuestions.questionsList[ques_count].question+ '</div>')
        .appendTo(main);

    $.each(moduleQuestions.questionsList[ques_count].optionsMap,(optionDesc, choice) => {
        $('<div class="option-list" name="' + choice + '" onclick="checkAnswer(this);">' + optionDesc + '</div>').appendTo(main);
    });
}

function checkAnswer(param) {
	answered++;
    clearInterval(startTimer);
    var id = $(param).attr('name');
    if (id === "true") {
        $(param).css('border', '2px solid green');
        setTimeout(function(){
            $('#nxt-btn').click();
        },1000);
        score++;
    }
    else {
        $(param).css('border', '2px solid red');
        setTimeout(function(){
            $('#nxt-btn').click();
        },500);
    }
}

// percentage = eval((score * 100)/moduleQuestions.questionsList.length)
// unanswered = moduleQuestions.questionsList.length - answered;
// if(percentage >= 80){
// status = "PASS";
// }
// grade = evaluateGrade(percentage)
// $('.result-box-content').html('<div>'+
// '<h2>Your Analysis</h2><br>'+
// '<ul>'+
// '<li>Percentage :'+percentage+'%</li>'+
// '<li>Total Questions : '+moduleQuestions.questionsList.length+'</li>'+
// '<li>Attempted : '+answered+'</li>'+
// '<li>Unanswered : '+unanswered+'</li>'+
// '<li>Status : '+status+'</li>'+
// '<li>Grade : '+grade+'</li>'+
// '</ul>'+
// '</div>');
//
// console.log("Score : "+score);
// $('.quiz-box').dialog('close');
// $('.result-box').dialog({
// draggable: false,
// resizable: false,
// width:500,
// height:300,
// close: function(){close()}
// });



