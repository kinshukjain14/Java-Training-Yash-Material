$(document).ready(
			function() {
				console.log
				$.ajax({
					url : "savescore?user="+$("#userId").val(),
					type : "GET",
					beforeSend : function() {
						$('#overlay').fadeIn(300);
					},
					success : function(response) 
					{
						console.log(response);
						$.each(response, function(index, element) {
							$(
									'<tr>' + '<td>' + element.moduleName
											+ '</td>' + '<td>'
											+ element.percentage + '</td>'
											+ '<td>' + element.appeared_on
											+ '</td>' + '<td>' + element.grade
											+ '</td>' + '<td>' + element.status
											+ '</td>' + '</tr>').appendTo(
									$('#scoredata tbody'))
						})
					},
					error : function(status) {
						Swal.fire({
							icon : 'error',
							title : 'Oops...',
							text : 'Something went wrong!',
						})
					},
					complete : function() {
						$('#overlay').fadeOut(300);
					}

				});
			});