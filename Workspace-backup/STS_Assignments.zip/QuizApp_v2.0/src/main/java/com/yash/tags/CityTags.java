package com.yash.tags;

import java.io.IOException;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyTagSupport;

import com.yash.helper.QuizFactory;
import com.yash.model.CitiesModel;
import com.yash.service.LocationService;

public class CityTags extends BodyTagSupport{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String stateCode;

	
	public String getStateCode() {
		return stateCode;
	}


	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}


	@Override
	public int doEndTag() throws JspException {
		JspWriter out = pageContext.getOut();
		try {
		if(stateCode.equals("-1") ) {
			out.write("<select class='fields' name='cities' id='cities'>");
			out.write("<option value='-1'>( Select )</option>");
			out.write("</select>");
		}
		else {
			int stateId = Integer.parseInt(stateCode);
			LocationService service = QuizFactory.newLocationService();
			List<CitiesModel> cities = service.getCities(stateId);
			out.write("<select class='fields' name='cities' id='cities'>");
			cities.forEach((x)->{
				try {
					out.write("<option value='"+x.getCityId()+"'>"+x.getCityName()+"</option>");
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
			out.write("</select>");
			
		}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return EVAL_PAGE;
	}
}
