package com.yash.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.yash.helper.QuizFactory;
import com.yash.model.CitiesModel;
import com.yash.model.StatesModel;
import com.yash.service.LocationService;

/**
 * Servlet implementation class LocationControllerServletClass
 */
public class LocationControllerServletClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LocationControllerServletClass() {
        super();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String type = request.getParameter("type");
		String code = request.getParameter("code");
		int id = Integer.parseInt(code);
		response.setContentType("application/json");
		ServletOutputStream sos = response.getOutputStream();
		LocationService service = QuizFactory.newLocationService(); 
		ObjectMapper mapper = new ObjectMapper();
		if(type.equals("country")) {
			List<StatesModel> states = service.getStates(id);
			mapper.registerModule(new JavaTimeModule());
			mapper.writeValue(sos, states);
		}
		else if(type.equals("state")) {
			List<CitiesModel> cities = service.getCities(id);
			mapper.registerModule(new JavaTimeModule());
			mapper.writeValue(sos, cities);
		}
	}

}
