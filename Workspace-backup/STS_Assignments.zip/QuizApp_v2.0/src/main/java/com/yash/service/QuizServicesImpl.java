package com.yash.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.yash.dao.QuizQuestionsDAO;
import com.yash.entity.Question;
import com.yash.entity.Module;
import com.yash.entity.Option;
import com.yash.exception.DAOException;
import com.yash.exception.QuestionParsingException;
import com.yash.helper.QuizFactory;
import com.yash.model.QuestionModel;
import com.yash.model.ModuleDataModel;

public class QuizServicesImpl implements QuizServices{

	@Override
	public ModuleDataModel getSubjectQuestions(String subjectName) throws QuestionParsingException{
		List<QuestionModel> qModels = new ArrayList<>();
		QuizQuestionsDAO quizQuestions = QuizFactory.newDAOInstance();
		Module subject;
		try {
			subject = quizQuestions.retriveSubjects(subjectName);
			List<Question> questions = subject.getQuestions();
			questions.forEach(x->{
				String question = x.getQuestions();
				Option option = x.getOption();
				qModels.add(new QuestionModel(question, option.getOptions()));
				
			});
			Collections.shuffle(qModels);
			ModuleDataModel model = new ModuleDataModel(qModels);
			model.setModuleId(subject.getSubjectCode());
			model.setModuleName(subject.getSubjectName());
			return model;
		} catch (DAOException e) {
			throw new QuestionParsingException("Error in processing the quiz questions");
		}
	}

	
}
