package com.yash.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.entity.QuizScores;
import com.yash.exception.DAOException;
import com.yash.helper.ConnectionManager;

public class JDBCQuizScoreDAOImpl implements QuizScoresDAO {

	private ConnectionManager manager = new ConnectionManager();
	@Override
	public boolean saveQuizScores(QuizScores score) throws DAOException {
		try(
			Connection connection = manager.openConnection();	
				){
			PreparedStatement statement = connection.prepareStatement("insert into quizscores values (?,?,?,?,?,?,?,?)");
			statement.setLong(1, score.getCandidateId());
			statement.setInt(2,score.getUserId());
			statement.setInt(3, score.getModuleId());
			statement.setDouble(4, score.getPercentage());
			statement.setString(5, score.getStatus());
			statement.setString(6, score.getGrade());
			statement.setInt(7, score.getTime_taken());
			statement.setDate(8,java.sql.Date.valueOf(score.getAppeared_on()));
			int i = statement.executeUpdate();
			if(i>0) {
				return true;
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			throw new DAOException(e, "DAO Exception : failed to store quiz scores");
		}
		return false;
	}

	@Override
	public List<QuizScores> fetchQuizScores(int userId) throws DAOException {
		List<QuizScores> scoresList = new ArrayList<>();
		try(
				Connection connection = manager.openConnection();	
					){
			CallableStatement statement = connection.prepareCall("{call sp_getQuizScores(?)}");
			statement.setInt(1, userId);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) 
			{
				QuizScores quizScores = new QuizScores();
				quizScores.setUserId(resultSet.getInt("user_id"));
				quizScores.setCandidateId(resultSet.getLong("quiz_id"));
				quizScores.setPercentage(resultSet.getDouble("percentage"));
				quizScores.setGrade(resultSet.getString("grade"));
				quizScores.setTime_taken(resultSet.getInt("time_taken"));
				quizScores.setAppeared_on(resultSet.getDate("appeared_on").toLocalDate());
				quizScores.setCandidateName(resultSet.getString("first_name")+" "+resultSet.getString("last_name"));
				quizScores.setStatus(resultSet.getString("status"));
				quizScores.setModuleName(resultSet.getString("module_name"));
				quizScores.setModuleId(resultSet.getInt("module_id"));
				scoresList.add(quizScores);
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return scoresList;
	}

}
