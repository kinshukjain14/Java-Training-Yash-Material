package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.exception.AuthenticationException;
import com.yash.exception.UserAlreadyExistException;
import com.yash.exception.UserDataNotFoundException;
import com.yash.exception.UserRegistrationException;
import com.yash.helper.QuizFactory;
import com.yash.model.UserModel;
import com.yash.service.UserService;

/**
 * Servlet implementation class UserAuthServletContollerClass
 */
public class UserAuthServletContollerClass extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	private UserService service;
	int flag = 0;
	private final String SIGN_IN = "1";
	private final String SIGN_UP = "2";
//	private final String LOG_OUT = "3";
	private final String AUTH_PASS = "{\"successflag\":\"true\"}";
	private final String AUTH_FAIL = "{\"successflag\":\"false\"}";
	private final String USER_DATA_EXIST = "{\"successflag\":\"false\",\"message\":\"Email or Contact no. already registered!!\"}";
	private final String USER_DATA_FAIL = "{\"successflag\":\"false\",\"message\":\"Unable to register user!!\"}";

	public UserAuthServletContollerClass() {
		super();
		service = QuizFactory.newUserAuthService();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		session.invalidate();
		response.sendRedirect("SignIn.jsp");
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String option = request.getParameter("option");
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
        response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
        response.setDateHeader("Expires", 0); // Proxies.
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();

		switch (option) 
		{
			case SIGN_IN:
				if (handleUserDetailsRequest(request, response)) {
					out.write(AUTH_PASS);
					return;
				}
				out.write(AUTH_FAIL);
				break;
			case SIGN_UP:
				if (handleUserDataStore(request, response)) {
					out.write(AUTH_PASS);
					return;
				}
				
				if (flag == 1) {
					out.write(USER_DATA_FAIL);
				} else if (flag == 2) {
					out.write(USER_DATA_EXIST);
				}
				break;
			}
	}

	public boolean handleUserDetailsRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		try {
			if (service.authenticateUser(userName, password)) {
				HttpSession session = request.getSession(true);
				UserModel userData = service.sendUserData();
				session.setAttribute("firstName", userData.getFirstName());
				session.setAttribute("name", userData.getFirstName()+" "+userData.getLastName());
				session.setAttribute("userId", userData.getUserId());
				return true;
			}
		} catch (AuthenticationException | UserDataNotFoundException e) {
		}
		return false;
	}

	public boolean handleUserDataStore(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		UserModel model = new UserModel();
		String firstName = request.getParameter("firstName");
		String lastName = request.getParameter("lastName");
		String contact = request.getParameter("contact");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String gender = request.getParameter("gender");
		String dateOfBirth = request.getParameter("dateOfBirth");
		DateTimeFormatter pattern = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate birthDate = LocalDate.parse(dateOfBirth, pattern);
		String address = request.getParameter("address");
		String countries = request.getParameter("countries");
		String states = request.getParameter("states");
		String cities = request.getParameter("cities");
		
		model.setFirstName(firstName);
		model.setLastName(lastName);
		model.setContactNo(Long.parseLong(contact));
		model.setUserId((int) (Math.random() * 1000000000));
		model.setEmail(email);
		model.setPassword(password);
		model.setUserName(email);
		model.setRegisteredOn(LocalDateTime.now());
		model.setLastLogin(LocalDateTime.now());
		model.setGender(gender);
		model.setDateOfBirth(birthDate);
		model.setAddress(address);
		model.setCountry(countries);
		model.setState(states);
		model.setCity(cities);
		
		try {
			if (service.addUserRegistration(model)) {
				return true;
			}
		} catch (UserRegistrationException e) {
			flag = 1;
		} catch (UserAlreadyExistException e) {
			flag = 2;
		}
		return false;
	}

}
