package com.yash.dao;

import java.util.List;

import com.yash.entity.Cities;
import com.yash.entity.Countries;
import com.yash.entity.States;
import com.yash.exception.DAOException;

public interface LocationDAO {
	public List<Countries> getAllCountries() throws DAOException;
	public List<States> getAllStates(int countryId) throws DAOException ;
	public List<Cities> getAllCities(int stateId) throws DAOException;
}
