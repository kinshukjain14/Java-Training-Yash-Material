package com.yash.entity;

import java.io.Serializable;
import java.time.LocalDate;

public class QuizScores implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int userId;
	private Long candidateId;
	private String candidateName;
	private int moduleId;
	private String moduleName;
	private String status;
	private double percentage;
	private int time_taken;
	private LocalDate appeared_on;
	private String grade;
	
	public QuizScores() {
		super();
	}
	public Long getCandidateId() {
		return candidateId;
	}
	public void setCandidateId(Long candidateId) {
		this.candidateId = candidateId;
	}
	public String getCandidateName() {
		return candidateName;
	}
	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public double getPercentage() {
		return percentage;
	}
	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getTime_taken() {
		return time_taken;
	}
	public void setTime_taken(int time_taken) {
		this.time_taken = time_taken;
	}
	public LocalDate getAppeared_on() {
		return appeared_on;
	}
	public void setAppeared_on(LocalDate appeared_on) {
		this.appeared_on = appeared_on;
	}
	public int getModuleId() {
		return moduleId;
	}
	public void setModuleId(int moduleId) {
		this.moduleId = moduleId;
	}
	
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	@Override
	public String toString() {
		return "Last Quiz Scores analysis \nId : " + candidateId + "\nCandidate Name : " + candidateName + "\nModule Name : "
				+ moduleName + "\nStatus : " + status + "\nPercentage : " + percentage + "%" + "\nGrade : "+grade+"\nTime Taken : "+ time_taken+" mins"
				+"\nDate of attempt : "+appeared_on+" ";
				
	}

}
