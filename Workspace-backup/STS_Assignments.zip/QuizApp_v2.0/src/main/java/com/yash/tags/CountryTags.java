package com.yash.tags;

import java.io.IOException;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyTagSupport;

import com.yash.helper.QuizFactory;
import com.yash.model.CountriesModel;
import com.yash.service.LocationService;

public class CountryTags extends BodyTagSupport{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public int doEndTag() throws JspException {
		LocationService service = QuizFactory.newLocationService();
		List<CountriesModel> countries = service.getCountries();
		JspWriter out = pageContext.getOut();
		try {
			out.write("<select class='fields' id='countries' name='countries'>");
			out.write("<option value='-1'>( Select )</option>");
				countries.forEach((x)->{
					try {
						out.write("<option value='"+x.getCountryId()+"'>"+x.getCountryName()+"</option>");
					} catch (IOException e) {
						e.printStackTrace();
					}
				});
			out.write("</select>");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return EVAL_PAGE;
	}
}
