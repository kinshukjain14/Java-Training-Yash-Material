package com.yash.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.yash.exception.QuestionParsingException;
import com.yash.helper.QuizFactory;
import com.yash.model.ModuleDataModel;
import com.yash.service.QuizServices;

/**
 * Servlet implementation class QuizQuestionServletController
 */
public class QuizQuestionServletController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	private QuizServices service;
    public QuizQuestionServletController() {
        super();
        this.service = QuizFactory.newServicesInstance(); 
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json");
		try {
			HttpSession session = request.getSession(false);
			String moduleName = request.getParameter("module");
			ModuleDataModel subjectQuestions = service.getSubjectQuestions(moduleName);
			session.setAttribute("moduleDetails",subjectQuestions);
			ObjectMapper mapper = new ObjectMapper();
//			mapper.registerModule(new JSR310Module());
			mapper.registerModule(new JavaTimeModule());
			ServletOutputStream sos = response.getOutputStream();
			mapper.writeValue(sos, subjectQuestions);
		} catch (QuestionParsingException e) {
			e.printStackTrace();
		}
		
	}

}
