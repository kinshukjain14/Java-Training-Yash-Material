package com.yash.entity;

public class Countries {
	private int country_id;
	private String shortName;
	private String countryName;
	private int phoneCode;
	
	public Countries(int country_id, String shortName, String countryName, int phoneCode) {
		super();
		this.country_id = country_id;
		this.shortName = shortName;
		this.countryName = countryName;
		this.phoneCode = phoneCode;
	}
	public int getCountry_id() {
		return country_id;
	}
	public String getShortName() {
		return shortName;
	}
	public String getCountryName() {
		return countryName;
	}
	public int getPhoneCode() {
		return phoneCode;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((countryName == null) ? 0 : countryName.hashCode());
		result = prime * result + country_id;
		result = prime * result + phoneCode;
		result = prime * result + ((shortName == null) ? 0 : shortName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Countries other = (Countries) obj;
		if (countryName == null) {
			if (other.countryName != null)
				return false;
		} else if (!countryName.equals(other.countryName))
			return false;
		if (country_id != other.country_id)
			return false;
		if (phoneCode != other.phoneCode)
			return false;
		if (shortName == null) {
			if (other.shortName != null)
				return false;
		} else if (!shortName.equals(other.shortName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Countries [country_id=" + country_id + ", shortName=" + shortName + ", countryName=" + countryName
				+ ", phoneCode=" + phoneCode + "]";
	}
	
}
