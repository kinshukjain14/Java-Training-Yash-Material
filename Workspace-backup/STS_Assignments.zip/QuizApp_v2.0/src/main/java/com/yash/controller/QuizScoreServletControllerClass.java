package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.helper.QuizFactory;
import com.yash.model.ModuleDataModel;
import com.yash.model.QuizScoreModel;
import com.yash.service.QuizScoreServices;

/**
 * Servlet implementation class QuizScoreServletControllerClass
 */
public class QuizScoreServletControllerClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	private QuizScoreServices service;
    public QuizScoreServletControllerClass() {
        super();
        service = QuizFactory.newQuizScoreServices();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String user = request.getParameter("user");
    	int userId=0;
    	if(user!=null) {
    		userId=Integer.parseInt(user);
    	}
    	String quizScore = service.getQuizScore(userId);
    	response.setContentType("application/json");
    	response.getWriter().write(quizScore);
    }
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer correct = Integer.parseInt(request.getParameter("correct"));
		Integer totalAttempt = Integer.parseInt(request.getParameter("totalAttempt"));
		Integer totalQuestions = Integer.parseInt(request.getParameter("totalQuestions"));
		Integer unattempted = totalQuestions - totalAttempt;
		Double percentage = (double)((correct * 100)/totalQuestions); 
		String grade = getGrades(percentage);
		String status ="FAIL";
		if(percentage >= 80.0 ) {
			status="PASS";
		}
		HttpSession session = request.getSession(false);
		ModuleDataModel moduleDetails = (ModuleDataModel) session.getAttribute("moduleDetails");
		Integer userId = (int) session.getAttribute("userId"); 
		String candidateName = (String) session.getAttribute("name");
		String candidate = request.getParameter("candidateID");
		Long candidateId = 0l;
		if(candidate !=null) {
			candidateId=Long.parseLong(candidate);
		}
		int moduleId = moduleDetails.getModuleId();
		String moduleName = moduleDetails.getModuleName();
		String time = request.getParameter("timeTaken");
		Integer timeTaken =0;
		if(time != null) {
			timeTaken = Integer.parseInt(time);
		}
		LocalDate appearedOn = LocalDate.now();
		
		QuizScoreModel model = new QuizScoreModel();
		model.setUserId(userId);
		model.setCandidateId(candidateId);
		model.setCandidateName(candidateName);
		model.setModuleId(moduleId);
		model.setModuleName(moduleName);
		model.setPercentage(percentage);
		model.setStatus(status);
		model.setGrade(grade);
		model.setTime_taken(timeTaken);
		model.setAppeared_on(appearedOn);
		
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		if(service.addQuizScore(model)) {
			String responseText = "{" + 
					"    \"responseText\":\"true\"," + 
					"    \"moduleName\": \""+moduleName+"\"," + 
					"    \"candidateId\": \""+candidateId+"\"," + 
					"    \"percentage\": \""+percentage+"\"," + 
					"    \"attempted\": \""+totalAttempt+"\"," + 
					"    \"unanswered\": \""+unattempted+"\"," + 
					"    \"correct\": \""+correct+"\"," + 
					"    \"status\": \""+status+"\"," + 
					"    \"grade\": \""+grade+"\"" + 
					"}";
			out.write(responseText);
		}
		else {
			String responseText = "{\"responseText\":\"false\"}";
			out.write(responseText);			
		}
		
	}

	private String getGrades(double percentage) {
		if(percentage > 90)
			return "A";
		else if(percentage > 80 && percentage<=90)
			return "B";	
		else if(percentage > 70 && percentage<=80)
			return "C";
		else if(percentage > 60 && percentage<=70)
			return "D";
		else if(percentage > 50 && percentage<=60)
			return "E";
		else 
			return "F";
	}

}
