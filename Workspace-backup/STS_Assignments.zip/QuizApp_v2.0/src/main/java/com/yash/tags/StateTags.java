package com.yash.tags;

import java.io.IOException;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyTagSupport;

import com.yash.helper.QuizFactory;
import com.yash.model.StatesModel;
import com.yash.service.LocationService;

public class StateTags extends BodyTagSupport{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String countryCode;

	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	@Override
	public int doEndTag() throws JspException {
		JspWriter out = pageContext.getOut();
		try {
		if(countryCode.equals("-1") ) {
			out.write("<select class='fields' name='states' id='states'>");
			out.write("<option value='-1'>( Select )</option>");
			out.write("</select>");
		}
		else {
			int countryId = Integer.parseInt(countryCode);
			LocationService service = QuizFactory.newLocationService();
			List<StatesModel> states = service.getStates(countryId);
			out.write("<select class='fields' name='states' id='states'>");
			states.forEach((x)->{
				try {
					out.write("<option value='"+x.getStateId()+"'>"+x.getStateName()+"</option>");
				} catch (IOException e) {
					e.printStackTrace();
				}
			});
			out.write("</select>");
			
		}
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		return EVAL_PAGE;
	}
}
