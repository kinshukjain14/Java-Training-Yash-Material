package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.yash.entity.Cities;
import com.yash.entity.Countries;
import com.yash.entity.States;
import com.yash.exception.DAOException;
import com.yash.helper.ConnectionManager;

public class JDBCLocationDaoImpl implements LocationDAO {
	
	@Override
	public List<Countries> getAllCountries() throws DAOException {
		ConnectionManager manager= new ConnectionManager();
		List<Countries> countriesList = new ArrayList<>();
		try(Connection connection = manager.openConnection()){
			Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("select * from countries");
			while(resultSet.next()) {
				Countries countries = new Countries(resultSet.getInt("id"),
						resultSet.getString("shortname"), 
						resultSet.getString("name"), 
						resultSet.getInt("phonecode"));
				countriesList.add(countries);
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new DAOException(e,"DAO Exception : unable to fetch countries");
		}
		return countriesList;
	}

	@Override
	public List<States> getAllStates(int countryId) throws DAOException {
		ConnectionManager manager= new ConnectionManager();
		List<States> statesList = new ArrayList<>();
		try(Connection connection = manager.openConnection()){
			PreparedStatement statement = connection.prepareStatement("select * from states where country_id=?");
			statement.setInt(1, countryId);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				States states = new States(resultSet.getInt("id"), resultSet.getString("name"), resultSet.getInt("country_id"));
				statesList.add(states);
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new DAOException(e,"DAO Exception : unable to fetch states");
		}
		return statesList;
	}

	@Override
	public List<Cities> getAllCities(int stateId) throws DAOException {
		ConnectionManager manager= new ConnectionManager();
		List<Cities> statesList = new ArrayList<>();
		try(Connection connection = manager.openConnection()){
			PreparedStatement statement = connection.prepareStatement("select * from cities where state_id=?");
			statement.setInt(1, stateId);
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				Cities cities = new Cities(resultSet.getInt("id"), resultSet.getString("name"), resultSet.getInt("state_id"));
				statesList.add(cities);
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
			throw new DAOException(e,"DAO Exception : unable to fetch cities");
		}
		return statesList;
	}

}
	