package com.yash.tags;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;

public class StateTagHandler implements Tag{
	
	public StateTagHandler() {}
	
	private PageContext pageContext;
	private Tag parent;
	
	private String countrycode;
	
	public String getCountrycode() {
		return countrycode;
	}

	public void setCountrycode(String countrycode) {
		this.countrycode = countrycode;
	}

	@Override
	public int doEndTag() throws JspException {
        try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
			Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/hrDB","root","root");
			PreparedStatement statement=connection.prepareStatement("select state_code,state_name from statetable where country_code=?");
			statement.setString(1, countrycode);
			ResultSet resultSet=statement.executeQuery();
			JspWriter out=pageContext.getOut();
			out.write("<select name=state>");
			while(resultSet.next()) {
				out.write("<option value='"+resultSet.getString("state_code")+"'>"+resultSet.getString("state_name")+"</option>");
			}
			out.write("</select>");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return EVAL_PAGE;
	}

	@Override
	public int doStartTag() throws JspException {
		// TODO Auto-generated method stub
		return SKIP_BODY;
	}

	@Override
	public Tag getParent() {
		// TODO Auto-generated method stub
		return parent;
	}

	@Override
	public void release() {
		pageContext=null;
		parent=null;
	}

	@Override
	public void setPageContext(PageContext arg0) {
      this.pageContext=arg0;		
	}

	@Override
	public void setParent(Tag arg0) {
		this.parent=arg0;
	}

}
