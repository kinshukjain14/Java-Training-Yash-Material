package com.yash.functions;

public class StringFunctions {
	public static String convertToUpper(String val) {
		return val.toUpperCase();
	}
}
