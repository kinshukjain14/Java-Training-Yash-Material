package com.yash.tags;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

public class TranslateTagHandler extends BodyTagSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String language;
	
	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	@Override
	public int doAfterBody() throws JspException {
		BodyContent content = getBodyContent();
		String string = content.getString();
		StringBuffer buffer = new StringBuffer();
		char[] bodyChars = string.toCharArray();
		if(language.equals("hindi")) {
			for (char c : bodyChars) {
				if(c=='a') {
					buffer.append('\u0912');
				}
				else if(c=='b') {
					buffer.append('\u0922');					
				}
				else if(c=='c'){					
					buffer.append('\u0932');					
				}
			}
		}
		
		JspWriter out = content.getEnclosingWriter();
		try {
			out.write(buffer.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return EVAL_PAGE;
	}
}
