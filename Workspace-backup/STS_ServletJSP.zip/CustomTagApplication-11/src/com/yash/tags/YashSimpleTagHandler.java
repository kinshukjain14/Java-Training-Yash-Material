package com.yash.tags;

import java.io.IOException;

import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.JspTag;
import javax.servlet.jsp.tagext.SimpleTag;

public class YashSimpleTagHandler implements SimpleTag{

	public YashSimpleTagHandler() {
	}
	
	private JspContext jspContext;
	private JspTag parent;
	private JspFragment jspFragment;
	
	//Mandatory method need to be overriden
	@Override
	public void doTag() throws JspException, IOException {
		JspWriter out = jspContext.getOut();
		out.write("<h1>Yash Technologies</h1>");
		
	}

	@Override
	public JspTag getParent() {
		return parent;
	}

	@Override
	public void setJspBody(JspFragment jspBody) {
		this.jspFragment=jspBody;
	}

	@Override
	public void setJspContext(JspContext pc) {
		this.jspContext=pc;
	}

	@Override
	public void setParent(JspTag parent) {
		this.parent=parent;
	}

}
