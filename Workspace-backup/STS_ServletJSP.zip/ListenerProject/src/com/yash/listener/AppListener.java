package com.yash.listener;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 * Application Lifecycle Listener implementation class AppListener
 *
 */
@WebListener
public class AppListener implements ServletContextListener, ServletContextAttributeListener {

	
    /**
     * Default constructor. 
     */
	private Logger logger=null;

    public AppListener() {
    	this.logger=logger.getLogger("AppListener");
    	FileHandler handler=null;
    	try {
			handler=new FileHandler("D:\\logs\\log.txt");
			SimpleFormatter formatter=new SimpleFormatter();
			handler.setFormatter(formatter);
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	logger.addHandler(handler);
    }

	/**
     * @see ServletContextAttributeListener#attributeAdded(ServletContextAttributeEvent)
     */
    public void attributeAdded(ServletContextAttributeEvent arg0)  { 
       logger.log(Level.INFO,"--context attribute added---:"+arg0.getValue());
    }

	/**
     * @see ServletContextAttributeListener#attributeRemoved(ServletContextAttributeEvent)
     */
    public void attributeRemoved(ServletContextAttributeEvent arg0)  { 
    	logger.log(Level.INFO,"--context attribute removed---:"+arg0.getValue());
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent arg0)  { 
    	logger.log(Level.INFO,"---context destroyed---:"+arg0.getServletContext().getServletContextName());
    }

	/**
     * @see ServletContextAttributeListener#attributeReplaced(ServletContextAttributeEvent)
     */
    public void attributeReplaced(ServletContextAttributeEvent arg0)  { 
    	logger.log(Level.INFO,"--context attribute replaced---:"+arg0.getValue());
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent arg0)  { 
    	logger.log(Level.INFO,"---context initialized---:"+arg0.getServletContext().getServletContextName());
    	ServletContext sc=arg0.getServletContext();
    	sc.setAttribute("appData", "App Data");
    	
    	
		sc.setAttribute("appData", "App-Data");
		
		sc.removeAttribute("appData");
    }
	
}
