package com.yash.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class MyServletClass
 */
public class MyServletClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServletClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ServletContext app=getServletContext();
		String data="App Data";
		app.setAttribute("appData", data);
		
		app.setAttribute("appData", "App-Data");
		
		app.removeAttribute("appData");
		
		request.setAttribute("username", "sabbir");
		
		request.setAttribute("username", "shabbir");
		
		request.removeAttribute("username");
		
		HttpSession session = request.getSession(true);
		String sessionData="Session Data";
		session.setAttribute("sessionData", sessionData);
		session.setAttribute("sessionData", "New Session Data");
		session.removeAttribute("sessionData");
		session.invalidate();
		
		PrintWriter pw=response.getWriter();
		pw.println("Response coming from Servlet...");
		
		
	}

}
