package com.yash.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.yash.entity.QuizScores;
import com.yash.exception.DAOException;
import com.yash.helper.ConnectionManager;

public class JDBCQuizScoreDAOImpl implements QuizScoresDAO {

	private ConnectionManager manager = new ConnectionManager();
	private int user_id;
	private int module_id;
	@Override
	public boolean saveQuizScores(QuizScores score) throws DAOException {
		try(
			Connection connection = manager.openConnection();	
				){
			PreparedStatement statement = connection.prepareStatement("insert into quizscores values (?,?,?,?,?,?,?,?)");
			statement.setInt(1, score.getCandidateId());
			user_id=score.getUserId();
			statement.setInt(2, user_id);
			module_id=score.getModuleId();
			statement.setInt(3, module_id);
			statement.setDouble(4, score.getPercentage());
			statement.setString(5, score.getStatus());
			statement.setString(6, score.getGrade());
			statement.setInt(7, score.getTime_taken());
			statement.setDate(8,java.sql.Date.valueOf(score.getAppeared_on()));
			int i = statement.executeUpdate();
			if(i>0) {
				return true;
			}
			
		} catch (ClassNotFoundException | SQLException e) {
			throw new DAOException(e, "DAO Exception : failed to store quiz scores");
		}
		return false;
	}

	@Override
	public String fetchQuizScores() throws DAOException {
		QuizScores quizScores = new QuizScores();
		try(
				Connection connection = manager.openConnection();	
					){
			CallableStatement statement = connection.prepareCall("{call sp_getQuizScores(?,?)}");
			statement.setInt(1, user_id);
			statement.setInt(2, module_id);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) 
			{
				quizScores.setUserId(resultSet.getInt("user_id"));
				quizScores.setCandidateId(resultSet.getInt("quiz_id"));
				quizScores.setPercentage(resultSet.getDouble("percentage"));
				quizScores.setGrade(resultSet.getString("grade"));
				quizScores.setTime_taken(resultSet.getInt("time_taken"));
				quizScores.setAppeared_on(resultSet.getDate("appeared_on").toLocalDate());
				quizScores.setCandidateName(resultSet.getString("first_name")+" "+resultSet.getString("last_name"));
				quizScores.setStatus(resultSet.getString("status"));
				quizScores.setModuleName(resultSet.getString("module_name"));
			}
			else 
			{
				return "**** No Data found ****";
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return quizScores.toString();
	}

}
