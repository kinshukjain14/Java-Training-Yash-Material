package com.yash.service;

import com.yash.dao.QuizScoresDAO;
import com.yash.entity.QuizScores;
import com.yash.exception.DAOException;
import com.yash.helper.QuizFactory;
import com.yash.model.QuizScoreModel;

public class QuizScoreServiceImpl implements QuizScoreServices {

	private static QuizScoresDAO dao;
	
	public QuizScoreServiceImpl() {
		dao=QuizFactory.newQuizScoresDAO();
	}
	
	@Override
	public boolean addQuizScore(QuizScoreModel model) 
	{
		QuizScores quizScores = new QuizScores();
		quizScores.setUserId(model.getUserId());
		quizScores.setCandidateId(model.getCandidateId());
		quizScores.setCandidateName(model.getCandidateName());
		quizScores.setModuleName(model.getModuleName());
		quizScores.setPercentage(model.getPercentage());
		quizScores.setStatus(model.getStatus());
		quizScores.setModuleId(model.getModuleId());
		quizScores.setTime_taken(model.getTime_taken());
		quizScores.setAppeared_on(model.getAppeared_on());
		quizScores.setGrade(model.getGrade());
		try {
			return dao.saveQuizScores(quizScores);
		} catch (DAOException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public String getQuizScore() {
		try {
			return dao.fetchQuizScores();
		} catch (DAOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
