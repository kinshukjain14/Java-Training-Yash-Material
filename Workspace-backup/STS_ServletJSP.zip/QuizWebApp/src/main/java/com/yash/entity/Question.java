package com.yash.entity;

public class Question 
{
	private int questionId;
	private String question;
	private Option option;
	
	public Question() {
	}

	public String getQuestions() {
		return question;
	}

	public void setQuestions(String questions) {
		this.question = questions;
	}

	public Option getOption() {
		return option;
	}

	public void setOption(Option option) {
		this.option = option;
	}

	public int getQuestionId() {
		return questionId;
	}

	public void setQuestionId(int questionId) {
		this.questionId = questionId;
	}

}
