package com.yash.entity;

import java.util.List;

public class Module {
	private int moduleId;
	private String moduleName;
	private List<Question> questions;
	
	public Module(int moduleId, String moduleName, List<Question> questions) 
	{
		super();
		this.moduleId = moduleId;
		this.moduleName = moduleName;
		this.questions = questions;
	}

	public int getSubjectCode() 
	{
		return moduleId;
	}

	public String getSubjectName() 
	{
		return moduleName;
	}

	public List<Question> getQuestions() 
	{
		return questions;
	}
	
	
}
