package com.yash.service;

import java.util.Optional;
import java.util.function.Supplier;

import com.yash.dao.UserDAO;
import com.yash.entity.User;
import com.yash.exception.AuthenticationException;
import com.yash.exception.DAOException;
import com.yash.exception.UserDataNotFoundException;
import com.yash.exception.UserRegistrationException;
import com.yash.helper.QuizFactory;
import com.yash.model.UserModel;

public class UserServiceImpl implements UserService {

	private UserDAO dao;
	
	
	public UserServiceImpl() {
		super();
		dao = QuizFactory.newUserDao();
	}

	@Override
	public boolean authenticateUser(String userName, String password) throws AuthenticationException {
			try {
				if(dao.checkUserCredentials(userName, password))
					return true;
				else
					throw new AuthenticationException("== Invalid username or password ==");
			} catch (DAOException e) {
			}
			return false;
	}

	@Override
	public UserModel sendUserData() throws UserDataNotFoundException {
		Optional<User> requestUserResponse = null;
		try {
			requestUserResponse = dao.requestUserResponse();
		} catch (DAOException e) {
			e.printStackTrace();
		}
		UserModel model = new UserModel();
		if(requestUserResponse.isPresent()) {
			String message="Data Requested not found";
			Supplier<UserDataNotFoundException> exceptionSupplier = () -> new UserDataNotFoundException(message);
			User reqUser = requestUserResponse.orElseThrow(exceptionSupplier);
			
			model.setUserId(reqUser.getUserId());
			model.setName(reqUser.getName());
			model.setContactNo(reqUser.getContactNo());
			model.setEmail(reqUser.getEmail());
		}
		
		return model;
	}

	@Override
	public boolean addUserRegistration(UserModel usermodel) throws UserRegistrationException {
		try {
			User user = new User(usermodel.getUserId(), usermodel.getUserName(), usermodel.getPassword(),
					usermodel.getName(), usermodel.getEmail(), usermodel.getContactNo());
			user.setRegisteredOn(usermodel.getRegisteredOn());
			user.setLastLogin(usermodel.getLastLogin());
			return dao.registerUser(user);
		} catch (DAOException e) 
		{
			e.printStackTrace();
			throw new UserRegistrationException("Unable to register user data");
		}
	}
	
	

}
