package com.yash.controller;

import com.yash.helper.QuizFactory;
import com.yash.model.QuizScoreModel;
import com.yash.service.QuizScoreServices;

public class QuizScoresController {
	
	private static QuizScoreServices service=QuizFactory.newQuizScoreServices();
	
	public static boolean handleQuizScoreStorage(QuizScoreModel model)
	{
		return service.addQuizScore(model);
	}
	
	public static String handleQuizScoreRetrival() {
		return service.getQuizScore();
	}
}
