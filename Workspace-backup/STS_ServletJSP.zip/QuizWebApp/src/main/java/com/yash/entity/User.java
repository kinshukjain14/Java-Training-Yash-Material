package com.yash.entity;

import java.time.LocalDateTime;

public class User {
	private int userId;
	private String userName;
	private String password;
	private String name;
	private String email;
	private Long contactNo;
	private LocalDateTime registeredOn;
	private LocalDateTime lastLogin;
	
	public User(int userId,String userName, String password,String name,String email,Long contactNo) {
		super();
		this.userId=userId;
		this.userName = userName;
		this.password = password;
		this.name=name;
		this.email=email;
		this.contactNo=contactNo;
	}
	public String getUserName() {
		return userName;
	}
	public String getPassword() {
		return password;
	}
	public int getUserId() {
		return userId;
	}
	public String getName() {
		return name;
	}
	public String getEmail() {
		return email;
	}
	public Long getContactNo() {
		return contactNo;
	}
	public LocalDateTime getRegisteredOn() {
		return registeredOn;
	}
	public void setRegisteredOn(LocalDateTime registeredOn) {
		this.registeredOn = registeredOn;
	}
	public LocalDateTime getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(LocalDateTime lastLogin) {
		this.lastLogin = lastLogin;
	}
	
}
