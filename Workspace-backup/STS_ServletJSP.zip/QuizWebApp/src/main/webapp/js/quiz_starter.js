var moduleQuestions;
$(document).ready(function () 
{
    $.ajax({
        type: "GET",
        url: "./resource/QuestionBank.json",
        datatype: "json",
        success: function (data){
            $(data.testpaper).each(function(index,element){
                if(element.module.moduleName == "Java"){
                    moduleQuestions = Object.assign(element.module);
                }
            })
        },
        error:function(xhr,ajaxOptions,thrownError){
            alert(xhr.status);
            alert(thrownError);
        }
    });

    $('.start_btn').button();
    $('.info-box').css('display', 'none');
    $('.quiz-box').css('display', 'none');

    $(".start_btn").click(function () {
        console.log(moduleQuestions);
        var dialogBox = $('.info-box');
        $('.start_btn').hide();
        if (dialogBox.hasClass('ui-dialog-content')) {
            dialogBox.dialog('open');
        }
        else {
            dialogBox.dialog({
                autoOpen: true,
                title: "Instructions for Quiz",
                width: 550,
                height: 350,
                escape: true,
                draggable: false,
                buttons: [
                    {
                        text: "Proceed",
                        open: function () { },
                        click: function () {
                            dialogBox.dialog('close')
                            loadQuizQuestions(1);
                        }
                    }
                ],
                show: {
                    effect: "fade",
                    duration: 100
                },
                hide: {
                    effect: "fade",
                    duration: 100
                },
                close: function () {
                    $('.start_btn').show();
                }
            });
        }
    });
});

function loadQuizQuestions(params) 
{
    $('.quiz-box').dialog({
        dialogClass: "no-titlebar",
        draggable:false,
        resizable: false,
        width:800, 
        height:500,
        closeOnEscape: false,
        buttons: [
            {
                text: "Next Ques",
                id:'nxt-btn',
                open: function () {
                    $(".timeline").progressbar(); 
                    startTimer = setInterval(timer,1000);
                },
                click: function () {
                    clearInterval(startTimer);
                }
            }
        ], 
    });
}

var progress=0;
var maxTime=15;
var startTimer;
var timeLeft;

function updateProgress(){
    $(".timeline").progressbar({
        value: progress++,
        max:15
    });
}

function timer(){
    updateProgress();
    timeLeft = maxTime--;
    if(timeLeft<10){
        timeLeft = "0"+timeLeft;
    }
    else{
        timeLeft = timeLeft+"";
    }
    if(timeLeft == 0){
        clearInterval(startTimer);
    }
    $('.time-left-sec').html(timeLeft);
}

