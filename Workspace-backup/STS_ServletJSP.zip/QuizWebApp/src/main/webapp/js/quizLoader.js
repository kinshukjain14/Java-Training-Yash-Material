var xmlhttp=getXMLHTTP(); 

function getXMLHTTP()
{
    var xmlhttp=null;
    if(window.ActiveXObject){
        try {
            xmlhttp = new ActiveXObject("MsXml2.XMLHTTP");
        } catch (e) {
            try {
                xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
            } catch (error) {}
        }
    }
    else{
        xmlhttp = new XMLHttpRequest();
    }
    return xmlhttp;
}

function getJSONData()
{
    var moduleSelected = document.getElementById("inputValue").value;
    if (moduleSelected == "" || moduleSelected == " ") {
        alert("Module not selected");
        return;
    }
    xmlhttp.open("GET","./resource/QuestionBank.json",true);
    xmlhttp.onreadystatechange = function() {
        console.log("asass")
        if(xmlhttp.readyState == 4 && xmlhttp.status == 200){
            eval("var data="+xmlhttp.responseText+";");
            var section1 = document.getElementById("section1");
            var section2 = document.getElementById("section2");
            section1.style.display="none";

            var br = document.createElement("br");
            var h2 = document.createElement("h2");
            var section = document.createElement("section");
            var ol = document.createElement("ol");
            var form = document.createElement("form");

            var h2Text = document.createTextNode("Module selected : "+moduleSelected);
            h2.appendChild(h2Text);
            section2.appendChild(h2);
            section2.appendChild(section);
            section.appendChild(form);
            form.appendChild(ol);
            
            var moduleArr = data.testpaper;
            for(var i=0;i<moduleArr.length;i++){
                if(moduleArr[i].module.moduleName == moduleSelected){
                   var questionsArr = moduleArr[i].module.questions;
                   var j=1;
                   questionsArr.forEach(element => {
                       var li = document.createElement("li");
                       var dl = document.createElement("dl");
                       var questionDesc = document.createTextNode(element.quesDescription);
                       li.appendChild(questionDesc);
                       li.appendChild(dl);
                       ol.appendChild(li);
                       var optionArr = element.option;
                       optionArr.forEach(op => {
                            var optionchoice = op.choice;
                            var optionDesc = op.optionText;
                            var optionid = op.optionId;
                            var dt = document.createElement("dt");
                            var input = document.createElement("input");
                            input.setAttribute("type","radio");
                            input.setAttribute("id",""+optionid);
                            input.setAttribute("name",""+j);
                            input.setAttribute("value",""+optionchoice);
                            
                            var label = document.createElement("label");
                            label.setAttribute("for",""+optionid);
                            var optionDescTextNode = document.createTextNode(optionDesc);
                            dl.appendChild(dt);
                            dt.appendChild(input);
                            dt.appendChild(label);
                            label.appendChild(optionDescTextNode);
                        });
                        j++;

                   });
                }
            }
            var button = document.createElement("input");
            button.setAttribute("type","button");
            button.setAttribute("value","Submit");
            form.appendChild(br);
            form.appendChild(button);
        }
    };
    xmlhttp.send(null);
}
