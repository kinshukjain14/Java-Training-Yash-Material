$(document).ready(function () {
    $("#btn1").click(function () {
       $.ajax({
            type:"GET",
            url:"./resource/QuestionBank.json",
            datatype:"json",
            success:function(data){
                $("#section2").html("");
                var modSelected = $("#inputValue").val();
                
                $("<h2>Module Selected : "+modSelected+"</h2>").appendTo($("#section2"));
                $("<ol id='questions'></ol>").appendTo($("#section2"));

                $(data.testpaper).each((index,element)=>
                {
                    if(element.module.moduleName == modSelected){
                        $(element.module.questions).each((indexes,elements)=>
                        {
                            $('<li>'+elements.quesDescription+'</li>').appendTo($("#questions"));
                            $('<dl id="'+elements.questionId+'"></dl>').appendTo($("#questions"));
                            $(elements.option).each((i,e)=>{
                                var optionText = e.optionText;
                                var x = parseInt(e.optionId);
                                x=x*100;
                                $('<dt id='+x+'></dt>').appendTo($('#'+elements.questionId));
                                $('<input type="radio" name="'+indexes+'" id="'+e.optionId+'" value="'+e.choice+'">').appendTo("#"+x);
                                $('<label for="'+e.optionId+'">'+optionText+'</label>').appendTo("#"+x);
                            });                           
                        });
                    }
                });
                $('br').appendTo('#section2');
                $('<input type="button" value="Submit">').appendTo('#section2');
                $('br').appendTo('#section2');
            },
            error:function(xhr,ajaxOptions,thrownError){
                alert(xhr.status);
                alert(thrownError);
            }
       }) ;
    });
});