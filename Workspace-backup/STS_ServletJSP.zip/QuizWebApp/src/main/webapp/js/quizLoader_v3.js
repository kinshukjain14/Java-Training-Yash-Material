$(document).ready(function () 
{
    var currentobj;
    // $("#btn1").click(function () {
    $(".card").click(function () {
        currentobj = this;
       $.ajax({
            type:"GET",
            url:"./resource/QuestionBank.json",
            datatype:"json",
            success:function(data){
                $("#section2").html("");
                // var modSelected = $("#inputValue").val();
                var modSelected = $(currentobj).attr('id');
                console.log(modSelected);

                $("<h2>Module Selected : "+modSelected+"</h2>").appendTo($("#section2"));
                $("<ol id='questions'></ol>").appendTo($("#section2"));

                $(data.testpaper).each((index,element)=>
                {
                    if(element.module.moduleName == modSelected)
                    {
                        $(element.module.questions).each((indexes,elements)=>
                        {
                            var y = parseInt(elements.questionId);
                            y=y*100;
                            $('<li id="'+elements.questionId+'">'+elements.quesDescription+'</li>').appendTo($("#questions"));
                            $('<dl id="'+y+'"></dl>').appendTo($("#"+elements.questionId));
                            $(elements.option).each((i,e)=>{
                                var optionText = e.optionText;
                                var x = parseInt(e.optionId);
                                x=x*100;
                                $('<dt id='+x+'></dt>').appendTo($('#'+y));
                                $('<input type="radio" name="'+indexes+'" id="'+e.optionId+'" value="'+e.choice+'">').appendTo("#"+x);
                                $('<label for="'+e.optionId+'">'+optionText+'</label>').appendTo("#"+x);
                            });                           
                        });
                    }
                });
                $('br').appendTo('#section2');
                $('<input id="btn2" type="button" value="Submit" onclick="validateScore()">').appendTo('#section2').ready(function(){
                    $('#btn2').button();
                });
                
                $('br').appendTo('#section2');
                if(!($('ol').html() == ''))
                {
                    $('#section1').hide();
                }
                else{
                    alert("Module not available")
                    $('#section2').html('');
                    $('<br><br><br>').appendTo('#section2');
                }
            },
            error:function(xhr,ajaxOptions,thrownError){
                alert(xhr.status);
                alert(thrownError);
            }
       }) ;
    });
});

function validateScore()
{
    console.log("sass")
    var allOptions =  $('input[type=radio]').get();
    var count = 0;
    for (let i = 0; i < allOptions.length; i++) {
        if (allOptions[i].value == '1' && allOptions[i].checked == true) {
            count++;
        }
    }
    alert('Score : '+count);
}

