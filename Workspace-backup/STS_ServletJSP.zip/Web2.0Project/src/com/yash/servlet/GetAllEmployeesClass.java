package com.yash.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.model.EmployeeModel;

/**
 * Servlet implementation class GetAllEmployeesClass
 */
public class GetAllEmployeesClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetAllEmployeesClass() {
        super();
    }
    
    private String driver;
    private String url;
    private String username;
    private String password;
    
    @Override
    public void init(ServletConfig servletConfig) {
    	this.driver=servletConfig.getInitParameter("driver");
    	this.url=servletConfig.getInitParameter("url");
    	this.username=servletConfig.getInitParameter("username");
    	this.password=servletConfig.getInitParameter("password");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Connection connection=null;
		List<EmployeeModel> employeeModelList=new ArrayList<EmployeeModel>();
		try {
			connection=DriverManager.getConnection(url,username,password);
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery("select employee_id,first_name,last_name from employees");
			while(resultSet.next()) {
				EmployeeModel model=new EmployeeModel();
				model.setEmployeeId(resultSet.getInt("employee_id"));
				model.setFirstName(resultSet.getString("first_name"));
				model.setLastName(resultSet.getString("last_name"));
				employeeModelList.add(model);
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		PrintWriter pw=response.getWriter();
		pw.println("<html><head><title>Employee Details</title></head>");
		pw.println("<body>");
		pw.println("<table cellspacing=2 cellpadding=2 border=2>");
		pw.println("<tr><th>Employee Id</th><th>First Name</th><th>Last Name</th></tr>");
		for(EmployeeModel model:employeeModelList) {
			pw.println("<tr>");
			pw.println("<td>"+model.getEmployeeId()+"</td>");
			pw.println("<td>"+model.getFirstName()+"</td>");
			pw.println("<td>"+model.getLastName()+"</td>");
			pw.println("</tr>");
		}
		pw.println("</table>");
		pw.println("</body>");
		pw.println("</html>");
		
	}

}
