package com.yash.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.yash.model.DepartmentModel;

public class DepartmentDAO {
	
	private int rows;

	public String createDepartment(DepartmentModel model) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		}catch (Exception e) {
			
		}
		try {
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hr","root","root");
			
			PreparedStatement prepareStatement = connection.prepareStatement("insert into departments values(?,?,?,?)");
			prepareStatement.setInt(1, model.getDepartmentId());
			prepareStatement.setString(2, model.getDepartmentName());
			prepareStatement.setInt(3, model.getManagerId());
			prepareStatement.setInt(4, model.getLocationId());
			rows = prepareStatement.executeUpdate();
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(rows>0) {
			return "success";
		}
		return "Failure";
	}
	
}	
