package com.yash.factory;

import com.yash.dao.JDBCJobsDAOImpl;
import com.yash.dao.JobsDAO;
import com.yash.service.JobsService;
import com.yash.service.JobsServiceImpl;

public class JobsFactory {
	public static JobsDAO createJobsDAO() {
		JobsDAO jobsDAO=new JDBCJobsDAOImpl();
		return jobsDAO;
	}
	public static JobsService createJobsService() {
		JobsService jobsService=new JobsServiceImpl();
		return jobsService;
	}
}
