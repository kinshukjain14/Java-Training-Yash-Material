package com.yash.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.entity.Jobs;
import com.yash.factory.DepartmentFactory;
import com.yash.factory.EmployeeFactory;
import com.yash.factory.JobsFactory;
import com.yash.model.DepartmentsModel;
import com.yash.model.EmployeeContactModel;
import com.yash.model.JobsModel;
import com.yash.model.ManagersModel;
import com.yash.service.DepartmentsService;
import com.yash.service.EmployeeService;
import com.yash.service.JobsService;

/**
 * Servlet implementation class EmployeeControllerClass
 */
public class EmployeeControllerClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeControllerClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String action=request.getParameter("action");
		if(action.equals("viewcontact")) {
			EmployeeService employeeService=EmployeeFactory.createEmployeeService();
			List<EmployeeContactModel> contactList=employeeService.getEmployeeContactModels();
			request.setAttribute("contactList", contactList);
			RequestDispatcher dispatcher=request.getRequestDispatcher("employeecontact.jsp");
			if(dispatcher!=null) {
				dispatcher.forward(request, response);
			}
		}
		if(action.equals("register")) {
			EmployeeService employeeService=EmployeeFactory.createEmployeeService();
			List<ManagersModel> managersList=employeeService.getManagers();
			DepartmentsService departmentService=DepartmentFactory.createDepartmentsService();
			List<DepartmentsModel> departmentsList=departmentService.getDepartments();
			JobsService jobsService=JobsFactory.createJobsService();
			List<JobsModel> jobsList=jobsService.getJobs();
			
			request.setAttribute("managersList", managersList);
			request.setAttribute("departmentsList", departmentsList);
			request.setAttribute("jobsList", jobsList);
			RequestDispatcher dispatcher=request.getRequestDispatcher("employeeform.jsp");
			if(dispatcher!=null) {
				dispatcher.forward(request, response);
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
