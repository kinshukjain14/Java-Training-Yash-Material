package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class FundTransferClass
 */
public class FundTransferClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FundTransferClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Object object=request.getAttribute("logindate");
		PrintWriter pw=response.getWriter();
		pw.println("<html><head><title>Account Statement</title></head>");
		pw.println("<body>");
		pw.println("<p>Login Date:"+object+"<br></br></p>");
		HttpSession session=request.getSession(false);
		
		String username=(String)session.getAttribute("username");
		pw.println("<p>User Name:"+"<b>"+username+"</b><br></br></p>");
		pw.println("</body>");
		pw.println("</html>");}

}
