package com.yash.dao;

import com.yash.exception.DAOException;

public interface AuthUserDAO {

	public boolean authUser(String userName,String password) throws DAOException;
}
