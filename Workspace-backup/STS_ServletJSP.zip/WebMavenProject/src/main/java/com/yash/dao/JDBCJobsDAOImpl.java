package com.yash.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.yash.entity.Jobs;
import com.yash.exception.DAOException;
import com.yash.helper.ConnectionManager;

public class JDBCJobsDAOImpl implements JobsDAO {

	public List<Jobs> getAllJobs() throws DAOException {
		ConnectionManager manager=new ConnectionManager();
		List<Jobs> jobsList=new ArrayList<Jobs>();
		try {
			Connection connection=manager.openConnection();
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery("select * from jobs");
			while(resultSet.next()) {
				Jobs jobs=new Jobs();
				jobs.setJobId(resultSet.getString("job_id"));
				jobs.setJobTitle(resultSet.getString("job_title"));
				jobsList.add(jobs);
				
			}
			manager.closeConnection();
		} catch (ClassNotFoundException e) {
			throw new DAOException(e,"DAO Exception");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new DAOException(e,"DAO Exception");
		}
		return jobsList;
	}

}
