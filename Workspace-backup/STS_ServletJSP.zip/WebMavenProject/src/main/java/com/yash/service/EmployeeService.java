package com.yash.service;

import java.util.List;

import com.yash.entity.Employees;
import com.yash.model.EmployeeContactModel;
import com.yash.model.ManagersModel;

public interface EmployeeService {

	public List<Employees> getAllEmployees();
	public List<EmployeeContactModel> getEmployeeContactModels();
	List<ManagersModel> getManagers();
}
