package com.yash.service;

import java.util.ArrayList;
import java.util.List;

import com.yash.dao.JobsDAO;
import com.yash.entity.Jobs;
import com.yash.exception.DAOException;
import com.yash.factory.JobsFactory;
import com.yash.model.JobsModel;

public class JobsServiceImpl implements JobsService {

	public List<JobsModel> getJobs() {
		JobsDAO jobsDAO=JobsFactory.createJobsDAO();
		List<JobsModel> jobsModel=new ArrayList<JobsModel>();
		try {
			List<Jobs> jobsList=jobsDAO.getAllJobs();
			for(Jobs jobs:jobsList) {
				JobsModel model=new JobsModel();
				model.setJobId(jobs.getJobId());
				model.setJobTitle(jobs.getJobTitle().toUpperCase());
				jobsModel.add(model);
			}
		} catch (DAOException e) {
			e.printStackTrace();
		}

		return jobsModel;
	}

}
