package com.yash.model;

public class JobsModel {
	
	public JobsModel() {}
	
	private String jobId;
	private String jobTitle;
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	@Override
	public String toString() {
		return "JobsModel [jobId=" + jobId + ", jobTitle=" + jobTitle + "]";
	}
	
	

}
