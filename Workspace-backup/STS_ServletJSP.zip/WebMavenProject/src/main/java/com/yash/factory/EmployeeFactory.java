package com.yash.factory;

import com.yash.dao.EmployeesDAO;
import com.yash.dao.JDBCEmployeesDAOImpl;
import com.yash.service.EmployeeService;
import com.yash.service.EmployeeServiceImpl;

public class EmployeeFactory {
	
	public static EmployeesDAO createEmployeeDAO() {
		EmployeesDAO employeesDAO=new JDBCEmployeesDAOImpl();
		return employeesDAO;
	}

	public static EmployeeService createEmployeeService() {
		EmployeeService employeeService=new EmployeeServiceImpl();
		return employeeService;
	}
}
