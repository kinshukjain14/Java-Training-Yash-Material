package com.yash.dao;

import java.util.List;

import com.yash.entity.Departments;
import com.yash.exception.DAOException;

public interface DepartmentsDAO {
	
	public boolean storeDepartment(Departments departments) throws DAOException;
	public List<Departments> getAllDepartments() throws DAOException;

}
