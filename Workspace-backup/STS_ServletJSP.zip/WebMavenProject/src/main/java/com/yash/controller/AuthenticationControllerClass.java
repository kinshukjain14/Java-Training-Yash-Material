package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.exception.AuthenticationException;
import com.yash.factory.FactoryAuthService;
import com.yash.model.UserModel;
import com.yash.service.AuthService;

/**
 * Servlet implementation class AuthenticationControllerClass
 */
public class AuthenticationControllerClass extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public AuthenticationControllerClass() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userName=request.getParameter("username");
        String password=request.getParameter("password");
        
        UserModel userModel=new UserModel();
        userModel.setUserName(userName);
        userModel.setPassword(password);
        
        PrintWriter out=response.getWriter();
        AuthService auth=FactoryAuthService.getInstance();
        try {
			UserModel user=auth.authService(userModel);
			if(user.isAuthenticated()) {
				
				Date date=new Date();
				request.setAttribute("logindate", date);
				HttpSession session=request.getSession(true);
				session.setMaxInactiveInterval(60*60);
				session.setAttribute("username", user.getUserName());
				RequestDispatcher dispatcher=request.getRequestDispatcher("welcome");
				dispatcher.forward(request, response);
			}
		} catch (AuthenticationException e) {
		  response.sendError(777);
		}
        
        
	}

}
