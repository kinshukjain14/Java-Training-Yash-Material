package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.yash.entity.Departments;
import com.yash.entity.Jobs;
import com.yash.exception.DAOException;
import com.yash.helper.ConnectionManager;

public class JDBCDepartmentsDAOImpl implements DepartmentsDAO {
	private ConnectionManager manager=new ConnectionManager();

	public boolean storeDepartment(Departments departments) throws DAOException {
		int rows=0;
		try {
			Connection connection=manager.openConnection();
			PreparedStatement statement=connection.prepareStatement("insert into departments values(?,?,?,?)");
			statement.setInt(1, departments.getDepartmentId());
			statement.setString(2, departments.getDepartmentName());
			statement.setInt(3,departments.getManagerId());
			statement.setInt(4, departments.getLocationId());
			rows=statement.executeUpdate();
			manager.closeConnection();
		} catch (ClassNotFoundException e) {
			throw new DAOException(e,"DAO Exception");
		} catch (SQLException e) {
			throw new DAOException(e,"DAO Exception");
		}
		if(rows>0)
		return true;
		else
	    return false;
	}

	public List<Departments> getAllDepartments() throws DAOException {
		ConnectionManager manager=new ConnectionManager();
		List<Departments> departmentsList=new ArrayList<Departments>();
		try {
			Connection connection=manager.openConnection();
			Statement statement=connection.createStatement();
			ResultSet resultSet=statement.executeQuery("select * from departments");
			while(resultSet.next()) {
				Departments department=new Departments();
				department.setDepartmentId(resultSet.getInt("department_id"));
				department.setDepartmentName(resultSet.getString("department_name"));
				departmentsList.add(department);
				
			}
			manager.closeConnection();
		} catch (ClassNotFoundException e) {
			throw new DAOException(e,"DAO Exception");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new DAOException(e,"DAO Exception");
		}
		return departmentsList;
	}

}
