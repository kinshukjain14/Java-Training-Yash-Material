package com.yash.service;

import java.util.ArrayList;
import java.util.List;

import com.yash.dao.EmployeesDAO;
import com.yash.entity.Employees;
import com.yash.exception.DAOException;
import com.yash.factory.EmployeeFactory;
import com.yash.model.EmployeeContactModel;
import com.yash.model.ManagersModel;

public class EmployeeServiceImpl implements EmployeeService {

	public List<Employees> getAllEmployees() {
		EmployeesDAO employeesDAO=EmployeeFactory.createEmployeeDAO();
		List<Employees> employeesList=null;
		try {
			employeesList=employeesDAO.getAllEmployees();
		} catch (DAOException e) {
			e.printStackTrace();
		}
		return employeesList;
	}

	public List<EmployeeContactModel> getEmployeeContactModels() {
		List<Employees> employees=getAllEmployees();
		List<EmployeeContactModel> modelsList=new ArrayList<EmployeeContactModel>();
		for(Employees employee:employees) {
			EmployeeContactModel model=new EmployeeContactModel();
			model.setFullName(employee.getFirstName()+" "+employee.getLastName());
			model.setPhoneNumber(employee.getPhoneNumber());
			model.setEmail(employee.getEmail());
			modelsList.add(model);
		}
		return modelsList;
	}

	public List<ManagersModel> getManagers() {
		EmployeesDAO employeesDAO=EmployeeFactory.createEmployeeDAO();
		List<ManagersModel> managersList=new ArrayList<ManagersModel>();
		try {
			List<Employees> employeesList=employeesDAO.getMangers();
			
			for(Employees employee:employeesList) {
				ManagersModel model=new ManagersModel();
				model.setEmployeeId(employee.getEmployeeId());
				model.setFullName(employee.getFirstName()+" "+employee.getLastName());
				managersList.add(model);
			}
		} catch (DAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return managersList;
	}

}
