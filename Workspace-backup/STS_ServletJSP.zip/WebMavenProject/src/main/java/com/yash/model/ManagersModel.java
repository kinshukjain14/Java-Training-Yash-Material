package com.yash.model;

public class ManagersModel {
	
	private int employeeId;

    private String fullName;
    
    
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	@Override
	public String toString() {
		return "ManagersModel [employeeId=" + employeeId + ", fullName=" + fullName + "]";
	}
	
	
	

}
