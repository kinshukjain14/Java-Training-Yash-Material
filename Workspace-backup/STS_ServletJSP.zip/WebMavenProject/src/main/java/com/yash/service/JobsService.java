package com.yash.service;

import java.util.List;

import com.yash.model.JobsModel;

public interface JobsService {
	public List<JobsModel> getJobs();

}
