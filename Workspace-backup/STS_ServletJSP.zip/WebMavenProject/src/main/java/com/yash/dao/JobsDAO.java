package com.yash.dao;

import java.util.List;

import com.yash.entity.Jobs;
import com.yash.exception.DAOException;

public interface JobsDAO {
	
	public List<Jobs> getAllJobs() throws DAOException;

}
