package com.yash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.yash.exception.DAOException;
import com.yash.helper.ConnectionManager;

public class JDBCAuthUserDAOImpl implements AuthUserDAO {
	
	private ConnectionManager manager=new ConnectionManager();

	public boolean authUser(String userName, String password) throws DAOException {
		boolean ifUserFound=false;
		try {
		Connection connection=manager.openConnection();
		PreparedStatement statement=connection.prepareStatement("select * from auth where authUser=? and authPassword=?");
		statement.setString(1, userName);
		statement.setString(2, password);
		ResultSet resultSet=statement.executeQuery();
		while(resultSet.next()) {
			ifUserFound=true;
		}
		}catch(ClassNotFoundException e) {
			throw new DAOException(e,"DAO Exception");
		}catch(SQLException e) {
			throw new DAOException(e,"DAO Exception");
		}
		return ifUserFound;
	}

}
