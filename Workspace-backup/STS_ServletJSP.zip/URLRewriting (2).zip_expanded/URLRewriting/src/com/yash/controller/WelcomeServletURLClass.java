package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class WelcomeServletURLClass
 */
@WebServlet(name = "WelcomeServletURL", urlPatterns = { "/welcomeurl" })
public class WelcomeServletURLClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WelcomeServletURLClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String username=request.getParameter("username");
		  
		  PrintWriter pw=response.getWriter();
		  
		  HttpSession session=request.getSession(true);
		  String sessionId=session.getId();
		  pw.println("<html><head><title>WelcomePage</title></head>");
		  pw.println("<body>");
		  pw.println("<p>Welcome,"+"<b>"+username+"</b><br></br></p>");
		  pw.println("<p><a href='accstatementurl?username="+username+"'>Account Statement</a><br></br></p>");
		  pw.println("<p><a href='fundurl?username="+username+"'>Fund Transfer</a><br></br></p>");
		  pw.println("<p><a href='logouturl'>Logout</a><br></br></p>");
		  pw.println("</body>");
		  pw.println("</html>");
	}

}
