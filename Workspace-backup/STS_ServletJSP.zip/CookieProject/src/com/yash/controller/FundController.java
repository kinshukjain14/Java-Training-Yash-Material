package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FundController
 */
public class FundController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FundController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Cookie[] cookies=request.getCookies();
		String username=null;
		if(cookies.length!=0) {
			for(Cookie cookie:cookies) {
				if(cookie.getName().equals("LoginCookie")) {
					username=cookie.getValue();
				}
			}
		}
		PrintWriter pw=response.getWriter();
		pw.println("<html><head><title>Fund Transfer Page</title></head>");
		pw.println("<body>");
		pw.println("<p>User Name:"+"<b>"+username+"</b><br></br></p>");
		pw.println("</body>");
		pw.println("</html>");
	}

}
