package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class WelcomePageClass
 */
public class WelcomePageClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WelcomePageClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username=request.getParameter("username");
		  
		  PrintWriter pw=response.getWriter();
		  
		  pw.println("<html><head><title>WelcomePage</title></head>");
		  pw.println("<body>");
		  pw.println("<p>Welcome,"+"<b>"+username+"</b><br></br></p>");
		  pw.println("<p><a href='accstatement'>Account Statement</a><br></br></p>");
		  pw.println("<p><a href='fund'>Fund Transfer</a><br></br></p>");
		  pw.println("<p><a href='logout'>Logout</a><br></br></p>");
		  pw.println("</body>");
		  pw.println("</html>");
		

	}

}
