package com.yash.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginCookieClass
 */
public class LoginCookieClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginCookieClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		if(username.equals("sabbirp") && password.equals("sabbirp")) {
			
			Cookie cookie=new Cookie("LoginCookie",username);
			cookie.setMaxAge(60*60);
			response.addCookie(cookie);
			
			RequestDispatcher dispatcher=request.getRequestDispatcher("welcomepage");
			dispatcher.forward(request, response);
			
		}else {
			response.sendError(777);
		}
	}

}
