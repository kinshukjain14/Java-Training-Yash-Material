package com.yash.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GetServletClass
 */
@WebServlet(name = "GetServlet", urlPatterns = { "/getservlet" })
public class GetServletClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetServletClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String employeeId = request.getParameter("employeeId");
		String email = request.getParameter("email");
		PrintWriter pw = response.getWriter();
		pw.println("<html>");
		pw.println("<head>");
		pw.println("<title>First Servlet Annotation</title>");
		pw.println("</head>");		
		pw.println("<body>");		
		pw.println("<i>Employee Id fetched : "+employeeId+"</i><br>");
		pw.println("<i>Employee email fetched : "+email+"</i>");
		pw.println("</body>");		
		pw.println("</html>");
	}

}
