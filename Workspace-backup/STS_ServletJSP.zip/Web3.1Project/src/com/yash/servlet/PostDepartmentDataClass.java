package com.yash.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PostDepartmentDataClass
 */
@WebServlet(
		name = "PostDepartmentData", 
		urlPatterns = { "/postdepartmentdata" }, 
		initParams = { 
				@WebInitParam(name = "driver", value = "com.mysql.jdbc.Driver"), 
				@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/hr"), 
				@WebInitParam(name = "username", value = "root"), 
				@WebInitParam(name = "password", value = "root")
		})
public class PostDepartmentDataClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private String driver;
    private String url;
    private String username;
    private String password;
    private Connection connection;
	@Override
	public void init(ServletConfig servletConfig) throws ServletException {
		this.driver=servletConfig.getInitParameter("driver");
    	this.url=servletConfig.getInitParameter("url");
    	this.username=servletConfig.getInitParameter("username");
    	this.password=servletConfig.getInitParameter("password");
    	try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	try {
			this.connection=DriverManager.getConnection(url,username,password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PostDepartmentDataClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int departmentId = Integer.parseInt(request.getParameter("departmentId"));
		String departmentName = request.getParameter("departmentName");
		int managerId = Integer.parseInt(request.getParameter("managerId"));
		int locationId = Integer.parseInt(request.getParameter("locationId"));
		int rows = 0;
		try {
			PreparedStatement statement= connection.prepareStatement("insert into departments value (?,?,?,?)");
			statement.setInt(1, departmentId);
			statement.setString(2, departmentName);
			statement.setInt(3, managerId);
			statement.setInt(4, locationId);
			rows = statement.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		PrintWriter out = response.getWriter();
		
		if(rows>0) {
			out.println("<b>Record Successfully inserted</b>");
		}
		else {
//			out.println("<font style='color:red'>Error processing request></font>");
			
		}
	}

}
