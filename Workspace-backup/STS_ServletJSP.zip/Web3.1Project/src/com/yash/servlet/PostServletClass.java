package com.yash.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PostServletClass
 */
@WebServlet(name = "PostServlet", urlPatterns = { "/postservlet" })
public class PostServletClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PostServletClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String employeeId = request.getParameter("employeeId");
		String email = request.getParameter("email");
		PrintWriter pw = response.getWriter();
		pw.println("<html>");
		pw.println("<head>");
		pw.println("<title>First Servlet Annotation</title>");
		pw.println("</head>");		
		pw.println("<body>");		
		pw.println("<b>Employee Id fetched : "+employeeId+"</b><br>");
		pw.println("<b>Employee email fetched : "+email+"</b>");
		pw.println("</body>");		
		pw.println("</html>");
	}

}
