package com.yash.aspect;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect
{
	
	static {
		LoggingAspect.logger = Logger.getLogger("LoggingAspect");
		try {
			Path path = Paths.get("D:\\Workspaces\\STS_SpringAssignment\\QuizApp_v5.0\\src\\main\\resources\\logs.txt");
			
			LoggingAspect.fileHandler = new FileHandler(path.toString(),true);
			LoggingAspect.simpleFormatter = new SimpleFormatter();
			LoggingAspect.fileHandler.setFormatter(LoggingAspect.simpleFormatter);
			LoggingAspect.logger.addHandler(LoggingAspect.fileHandler);
			LoggingAspect.logger.setLevel(Level.CONFIG);
			LoggingAspect.logger.log(Level.CONFIG,"--- Logger Configured ---");
		} catch (SecurityException | IOException e) {
			e.printStackTrace();
		}
	}
	
	private static Logger logger;
	private static FileHandler fileHandler;
	private static SimpleFormatter simpleFormatter;
	
	@AfterThrowing(pointcut = "execution(* com.yash.*.*.*(..))",throwing = "error")
	public void afterThrowing(JoinPoint joinPoint,Throwable error) {
		logger.log(Level.SEVERE,"After throwing aspect -- "+joinPoint.getSignature().getName()+" Error :- "+error);		
	}
	
	@Pointcut(value = "execution(* com.yash.*.*.*(..))")
	public void getPointCut() {
	}
	
	@Around(value = "getPointCut()")
	public Object aroundAdvice(ProceedingJoinPoint joinPoint) {
		logger.log(Level.INFO,"-- "+joinPoint.getSignature().getName()+" execution started --");
		Object proceed = null;
		try {
			 proceed = joinPoint.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		logger.log(Level.INFO," Value Returned : "+proceed);
		logger.log(Level.INFO,"-- "+joinPoint.getSignature().getName()+" execution finished --");
		return proceed;
	}
}
