package com.yash.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.annotation.SessionScope;

import com.yash.model.AllEmployeesModel;
import com.yash.model.Employees;
import com.yash.service.EmployeesService;


@RestController
@RequestMapping("api")
@SessionScope
@CrossOrigin(origins = "*")
public class EmployeeController {

	public EmployeeController() {}
	@Autowired
	private EmployeesService employeesService;

	@GetMapping("employees")
	public ResponseEntity<Employees> handleGetAllEmployees(HttpServletRequest request){
		
		
		
		List<AllEmployeesModel> employeesList=employeesService.retrieveAllEmployees();
		ResponseEntity<Employees> response=null;
		Employees employees=new Employees();
		
		if(!employeesList.isEmpty()) {
			employees.setEmployees(employeesList);
			response= new ResponseEntity<Employees>(employees,HttpStatus.OK);
		}else {
			response=new ResponseEntity<Employees>(HttpStatus.NOT_FOUND);
		}
		return response;
	}
}
