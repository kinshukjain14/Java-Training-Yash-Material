package com.yash.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.model.DepartmentsModel;
import com.yash.service.DepartmentsService;

@RestController
@RequestMapping("api")
@CrossOrigin(origins = "*")
public class DepartmentController {
	
	@Autowired
	private DepartmentsService departmentService;
	@GetMapping("departments")
	public ResponseEntity<List<DepartmentsModel>>handleGetAllDepartments(HttpServletRequest request){
		HttpSession session=request.getSession();
		session.setAttribute("firstName","Amit");
		List<DepartmentsModel> departmentsList=departmentService.retrieveDepartments();
		ResponseEntity<List<DepartmentsModel>> response=null;
		if(!departmentsList.isEmpty()) {
			response=new ResponseEntity<List<DepartmentsModel>>(departmentsList,HttpStatus.OK);
		}else {
			response=new ResponseEntity<List<DepartmentsModel>>(HttpStatus.NOT_FOUND);

		}
		return response;
		
	}

}
