package com.yash.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.model.JobsModel;
import com.yash.service.JobsService;

@RestController
@RequestMapping("api")
@CrossOrigin(origins = "*")
public class JobsController {
    @Autowired
	private JobsService jobsService;
    @GetMapping("jobs")
	public ResponseEntity<List<JobsModel>> handleGetAllJobs(HttpServletRequest request){
		
    	HttpSession session=request.getSession(false);
		System.out.println("First Name:"+session.getAttribute("firstName"));
    	List<JobsModel> jobsList=jobsService.retrieveJobs();
		ResponseEntity<List<JobsModel>> response=null;
		if(!jobsList.isEmpty()) {
			response=new ResponseEntity<List<JobsModel>>(jobsList,HttpStatus.OK);
		}else {
			response=new ResponseEntity<List<JobsModel>>(HttpStatus.NOT_FOUND);
		}
		return response;
	}
}
