package com.yash.aspect;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;


@Aspect
@Component
public class LoggingAspect 
{
	private Logger logger;
	private FileHandler fileHandler;
	private SimpleFormatter simpleFormatter;
	
	public LoggingAspect() {
		logger = Logger.getLogger(this.getClass().getName());
		try {
//			this.fileHandler = new FileHandler("/src/main/resources/logs/logs.txt",true);
			this.fileHandler = new FileHandler("D:\\fileHandling\\logs\\logs.txt",true);
			this.simpleFormatter = new SimpleFormatter();
			fileHandler.setFormatter(simpleFormatter);
			logger.addHandler(fileHandler);
			logger.setUseParentHandlers(false);
		} 
		catch (SecurityException | IOException e) {
			e.printStackTrace();
		}
	}
	
	@Before(value = "execution(* com.yash.*.*.*(..))")
	public void beforeAdvice(JoinPoint joinPoint) {
		logger.log(Level.INFO,"-- "+ joinPoint.getSignature().getName()+" called --");
	}
	
	@After(value = "execution(* com.yash.*.*.*(..))")
	public void afterAdvise(JoinPoint joinPoint) {
		logger.log(Level.INFO,"-- "+ joinPoint.getSignature().getName()+" completed --");
	}
	
	@AfterThrowing("execution(* com.yash.*.*(..))")
	public void afterThrowing(JoinPoint joinPoint) {
		logger.log(Level.INFO,"-- "+ joinPoint.getSignature().getName()+" throws exception --");		
	}	
	
}
