package com.yash.helper;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class UserAuthSQLQueries {
	@Value(value = "${getUserIdProcedure}")
	private String getUserIdProcedure;
	
	@Value(value = "${getUserDetailsByUserIdProcedure}")
	private String getUserDetailsByUserIdProcedure;
	
	@Value(value = "${insertUserDetails}")
	private String insertUserDetails;
	
	public String getInsertUserDetails() {
		return insertUserDetails;
	}
	public void setInsertUserDetails(String insertUserDetails) {
		this.insertUserDetails = insertUserDetails;
	}
	public String getGetUserIdProcedure() {
		return getUserIdProcedure;
	}
	public void setGetUserIdProcedure(String getUserIdProcedure) {
		this.getUserIdProcedure = getUserIdProcedure;
	}
	public String getGetUserDetailsByUserIdProcedure() {
		return getUserDetailsByUserIdProcedure;
	}
	public void setGetUserDetailsByUserIdProcedure(String getUserDetailsByUserIdProcedure) {
		this.getUserDetailsByUserIdProcedure = getUserDetailsByUserIdProcedure;
	}
	@Override
	public String toString() {
		return "UserAuthSQLQueries [getUserIdProcedure=" + getUserIdProcedure + ", getUserDetailsByUserIdProcedure="
				+ getUserDetailsByUserIdProcedure + ", insertUserDeatails=" + insertUserDetails + "]";
	}
	
	
}
