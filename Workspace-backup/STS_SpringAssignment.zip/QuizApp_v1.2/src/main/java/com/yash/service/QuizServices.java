package com.yash.service;

import com.yash.exception.QuestionParsingException;
import com.yash.model.ModuleDataModel;

public interface QuizServices 
{
	public ModuleDataModel getSubjectQuestions(String subjectName) throws QuestionParsingException;
}
