package com.yash.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;

import com.yash.exception.AuthenticationException;
import com.yash.exception.UserDataNotFoundException;
import com.yash.exception.UserRegistrationException;
import com.yash.model.UserModel;
import com.yash.service.UserService;

@Controller
@EnableAspectJAutoProxy
public class UserAuthController {
	
	@Autowired
	private UserService userService;
	
	public UserAuthController() {
		super();
//		userService = QuizFactory.newUserAuthService();
	}

	public boolean handleUserAuth(UserModel user) throws AuthenticationException
	{
		String userName=user.getUserName();
		String password = user.getPassword();
		return userService.authenticateUser(userName, password);
	}
	
	public UserModel handleUserDetailsRequest() throws UserDataNotFoundException {
		return userService.sendUserData();
	}
	
	public boolean handleUserDataStore(UserModel user) throws UserRegistrationException {
		return userService.addUserRegistration(user);
	}
}
