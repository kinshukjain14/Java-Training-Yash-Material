package com.yash.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.yash.dao.QuizQuestionsDAO;
import com.yash.entity.Question;
import com.yash.entity.Module;
import com.yash.entity.Option;
import com.yash.exception.DAOException;
import com.yash.exception.QuestionParsingException;
import com.yash.model.QuestionModel;
import com.yash.model.ModuleDataModel;

@Service
public class QuizServicesImpl implements QuizServices{

	@Autowired@Qualifier("jDBCQuizQuestionsDAOImpl")
	private QuizQuestionsDAO quizQuestionsDAO;

	@Override
	public ModuleDataModel getSubjectQuestions(String subjectName) throws QuestionParsingException{
		List<QuestionModel> qModels = new ArrayList<>();
//		quizQuestionsDAO = QuizFactory.newDAOInstance();
		Module subject;
		try {
			subject = quizQuestionsDAO.retriveSubjects(subjectName);
			List<Question> questions = subject.getQuestions();
			questions.forEach(x->{
				String question = x.getQuestions();
				Option option = x.getOption();
				qModels.add(new QuestionModel(question, option.getOptions()));
				
			});
			Collections.shuffle(qModels);
			ModuleDataModel model = new ModuleDataModel(qModels);
			return model;
		} catch (DAOException e) {
			e.printStackTrace();
			throw new QuestionParsingException("Error in processing the quiz questions");
		}
	}

	
}
