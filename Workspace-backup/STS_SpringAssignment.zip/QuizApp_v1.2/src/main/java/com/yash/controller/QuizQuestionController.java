package com.yash.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.yash.exception.QuestionParsingException;
import com.yash.model.ModuleDataModel;
import com.yash.service.QuizServices;

@Controller
@Scope("prototype")
@EnableAspectJAutoProxy
public class QuizQuestionController {
	
	@Autowired
	private QuizServices quizServices;
	
	public QuizQuestionController() {
//		this.quizServices = QuizFactory.newServicesInstance(); 
	}
	
	public ModuleDataModel handleSubjectquestion(String subjectName) throws QuestionParsingException {
		return quizServices.getSubjectQuestions(subjectName); 
	}
	
}
