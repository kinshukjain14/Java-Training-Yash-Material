package com.yash.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class DebuggingAspect {
	
	@Pointcut(value = "execution(* com.yash.*.*.*(..))")
	public void valid() {
	}
	
	
	@Pointcut(value = "execution(* org.com.*.*.*(..))")
	public void inValid() {
	}
	
	@Around(value = "valid() && inValid()")
	public Object aroundAdvice(ProceedingJoinPoint joinPoint) {
		System.out.println("----- "+joinPoint.getSignature().getName()+" started --");
		Object o =null;
		try {
			o = joinPoint.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		System.out.println("Value Returned : "+o);
		System.out.println("----- "+joinPoint.getSignature().getName()+" ended --");
		return o;
	}	
}
