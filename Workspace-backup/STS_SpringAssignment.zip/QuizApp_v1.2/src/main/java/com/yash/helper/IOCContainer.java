package com.yash.helper;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.yash.configuration.QuizAppConfiguration;

public class IOCContainer {
	public static ApplicationContext getIocContainer() {
		ApplicationContext ioc = new AnnotationConfigApplicationContext(QuizAppConfiguration.class);
		return ioc;
	}
}
