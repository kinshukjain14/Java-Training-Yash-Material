package com.yash.helper;

import com.yash.dao.JDBCQuizQuestionsDAOImpl;
import com.yash.dao.JDBCQuizScoresDAOImpl;
import com.yash.dao.JDBCUserDAOImpl;
import com.yash.dao.QuizQuestionsDAO;
import com.yash.dao.QuizScoresDAO;
import com.yash.dao.UserDAO;
import com.yash.service.QuizScoreServicesImpl;
import com.yash.service.QuizScoreServices;
import com.yash.service.QuizServices;
import com.yash.service.UserService;
import com.yash.service.UserServiceImpl;
import com.yash.service.QuizServicesImpl;

public class QuizFactory
{
	public static QuizQuestionsDAO newDAOInstance() {
//		return new XMLQuizQuestionsDAOImpl();
		return new JDBCQuizQuestionsDAOImpl();
	}
	
	public static QuizServices newServicesInstance() {
		return new QuizServicesImpl();
	}
	
	public static QuizScoresDAO newQuizScoresDAO() {
//		return new FileQuizScoreDAOImpl();
		return new JDBCQuizScoresDAOImpl();
	}
	
	public static QuizScoreServices newQuizScoreServices() {
		return new QuizScoreServicesImpl();
	}
	
	public static UserDAO newUserDao() {
//		return new MemoryUserDAOImpl();
		return new JDBCUserDAOImpl();
	}
	public static UserService newUserAuthService() {
		return new UserServiceImpl();
	}
}
