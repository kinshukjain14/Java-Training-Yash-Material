package com.yash.validation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserInputValidation 
{
	
	public boolean validateContactNumber(Long contactNo) 
	{
		String regex = "^[6-9][0-9]{9}";
		return validate(contactNo.toString(),regex);
	}
	public boolean validateEmail(String emailId) 
	{
		String regex = "[A-Za-z0-9+_.-]+@[a-z]+[.][a-z]+{2,3}$";
		return validate(emailId,regex);
	}
	public boolean validateName(String name) 
	{
		String regex = "[A-Z][a-z]*\\s*";
		return validate(name,regex);
	}
	
	public boolean validatePasswordPolicy(String password) 
	{
		String regex = "^(?=.*[0-9])"
                + "(?=.*[a-z])(?=.*[A-Z])"
                + "(?=.*[@#$%^&+=])"
                + "(?=\\S+$).{8,20}$";
		return validate(password, regex);
	}
	public boolean validatePasswords(String newPassword,String cnfPassword) {
		if(newPassword.equals(cnfPassword)) {
			return true;
		}
		return false;
	}
	
	public boolean validate(String string, String regex) 
	{
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(string);
		return matcher.matches();
	}
	
}