package com.yash.dao;

import com.yash.entity.QuizScores;
import com.yash.exception.DAOException;

public interface QuizScoresDAO {
	public boolean saveQuizScores(QuizScores score) throws DAOException;
	public String fetchQuizScores()throws DAOException;
}
