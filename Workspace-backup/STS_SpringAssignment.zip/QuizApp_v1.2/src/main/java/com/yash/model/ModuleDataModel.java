package com.yash.model;

import java.util.List;

public class ModuleDataModel 
{
	List<QuestionModel> questionsList;

	public ModuleDataModel(List<QuestionModel> questionsList) {
		super();
		this.questionsList = questionsList;
	}

	public List<QuestionModel> getQuestionsList() {
		return questionsList;
	}
	
}
