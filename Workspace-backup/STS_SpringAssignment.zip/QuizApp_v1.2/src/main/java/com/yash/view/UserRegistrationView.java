package com.yash.view;

import java.time.LocalDateTime;
import java.util.Scanner;
import org.springframework.context.ApplicationContext;

import com.yash.controller.UserAuthController;
import com.yash.exception.QuestionParsingException;
import com.yash.exception.UserRegistrationException;
import com.yash.helper.IOCContainer;
import com.yash.model.UserModel;
import com.yash.validation.UserInputValidation;

public class UserRegistrationView 
{
	public static void registerUser(Scanner sc) throws InterruptedException 
	{
		UserModel users = new UserModel();
		try{
			UserInputValidation validator = new UserInputValidation();
			int userId=(int)(Math.random() * 100000);
			String firstName,lastName,emailId,username,password,cnfPassword;
			Long contact;
			while(true) {
			System.out.print("Enter First name : ");
				firstName=sc.next();
				if(!validator.validateName(firstName)) {
//					UIClient.logger.log(Level.INFO,"\n== Invalid : Name cannot contains special charaters and numeric values ==\n");
					System.err.println("\\n== Invalid : Name cannot contains special charaters and numeric values ==\\n");
					Thread.sleep(100);
					continue;
				}
				break;
			}
			while(true) 
			{
				System.out.print("Enter Last name : ");
				lastName=sc.next();
				if(!validator.validateName(lastName)) {
//					UIClient.logger.log(Level.INFO,"\n== Invalid : Name cannot contains special charaters and numeric values ==\n");
					System.err.println("\\n== Invalid : Name cannot contains special charaters and numeric values ==\\n");
					Thread.sleep(100);
					continue;
				}
				break;
			}
			while(true) 
			{
				System.out.print("Enter Email id: ");
				emailId=sc.next();
				if(!validator.validateEmail(emailId)) {
//					UIClient.logger.log(Level.INFO,"\n== Invalid Email Id ==\n");
					System.err.println("\\n== Invalid Email Id ==\\n");
					Thread.sleep(100);
					continue;
				}
				break;
			}
			while(true) 
			{
				System.out.print("Enter Contact no : ");	
				if(sc.hasNextLong()) 
				{
					contact = sc.nextLong();				
					if(!validator.validateContactNumber(contact)) {
//						UIClient.logger.log(Level.INFO,"\n=== Invalid Contact number ===\n");
						System.err.println("\\n=== Invalid Contact number ===\\n");
						Thread.sleep(100);
						continue;					
					}
					break;
				}
				else 
				{
//					UIClient.logger.log(Level.INFO,"\n== Invalid Input : required numeric value ==\n");
					System.err.println("\\n== Invalid Input : required numeric value ==\\n");
					Thread.sleep(100);
					sc.next();
					continue;
				}
			}
			while(true) 
			{
				System.out.println("*** SET PASSWORD ***\n");
				System.out.println("Password policy : ");
				System.out.println(">> It contains at least 8 characters and at most 20 characters.");
				System.out.println(">> It contains at least one digit.");
				System.out.println(">> It contains at least one upper case alphabet.");
				System.out.println(">> It contains at least one lower case alphabet.");
				System.out.println(">> It contains at least one special character which includes !@#$%&*()-+=^.");
				System.out.println(">> It contains at least one special character which includes !@#$%&*()-+=^.");
				
				System.out.print("Enter Password : ");
				password=sc.next();
				if(validator.validatePasswordPolicy(password)) {
					System.out.print("Enter Confirm Password : ");
					cnfPassword=sc.next();
					if(!validator.validatePasswords(password, cnfPassword)) {
//						UIClient.logger.log(Level.WARNING,"\n== Confirm Password didn't matched ==\n");
						System.err.println("\n== Confirm Password didn't matched ==\n");
						Thread.sleep(100);
						continue;
					}
					break;
				}
				else {
//					UIClient.logger.log(Level.WARNING,"\n== Invalid : Password is not as per password policy ==\n");
					System.err.println("\n== Invalid : Password is not as per password policy ==\n");
					Thread.sleep(100);
					continue;
				}
			}
			String[] split = emailId.split("@");
			username=split[0];
			
			users.setUserId(userId);
			users.setName(firstName+" "+lastName);
			users.setContactNo(contact);
			users.setEmail(emailId);
			users.setUserName(username);
			users.setPassword(cnfPassword);
			users.setRegisteredOn(LocalDateTime.now());
			users.setLastLogin(LocalDateTime.now());
			
			ApplicationContext ioc = IOCContainer.getIocContainer();
			UserAuthController userAuthController= (UserAuthController) ioc.getBean("userAuthController");
			
			if(!userAuthController.handleUserDataStore(users)) {
//				UIClient.logger.log(Level.SEVERE,"\n== Unable to register new user try again ==\n");
				System.err.println("\n== Unable to register new user try again ==\n");
				Thread.sleep(100);
				validator=null;
				LoginView.login(sc);
				return;
			}
			
			System.out.println("********** User Registered successfully **********");
			System.out.println("-- User Details --");
			System.out.println("Name : "+users.getName());
			System.out.println("Contact : "+users.getContactNo());
			System.out.println("Email : "+users.getEmail());
			System.out.println("Registered on : "+users.getRegisteredOn());
			System.out.println("User Name : "+users.getUserName());
			System.out.println("-----------------");
			Thread.sleep(100);
			System.err.println("\n>> NOTE : Kindly remember username generated by the system\n");
			Thread.sleep(1000);
			
			validator=null;
			LoginView.login(sc);
			
		} catch (QuestionParsingException | UserRegistrationException e) {
		}
	}
}
