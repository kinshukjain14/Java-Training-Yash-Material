package com.yash.ui;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.yash.exception.QuestionParsingException;
import com.yash.view.LoginView;

public class UIClient 
{
	public static void main(String[] args) 
	{
		try(Scanner sc = new Scanner(System.in))
		{
			System.out.println("***************************** Welcome to Quiz System CLI *****************************");
//			CreateXML.generateXML();
			LoginView.login(sc);
			System.out.println("***************************** Thanks for Visiting *****************************");

		}
		catch(InterruptedException | QuestionParsingException e) {
//			logger.log(Level.SEVERE,"***** Error in Application *****");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
	}
}
