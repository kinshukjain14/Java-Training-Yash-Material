package com.yash.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Controller;

import com.yash.model.QuizScoreModel;
import com.yash.service.QuizScoreServices;

@Controller
@EnableAspectJAutoProxy
public class QuizScoresController {
	
	@Autowired
	private QuizScoreServices quizScoreServices;
//	private static QuizScoreServices quizScoreServices=QuizFactory.newQuizScoreServices();
	
	public boolean handleQuizScoreStorage(QuizScoreModel model)
	{
		return quizScoreServices.addQuizScore(model);
	}
	
	public String handleQuizScoreRetrival() {
		return quizScoreServices.getQuizScore();
	}
}
