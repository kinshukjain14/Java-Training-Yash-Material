package com.yash.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.yash.controller.UserAuthController;
import com.yash.exception.AuthenticationException;
import com.yash.model.UserModel;

class TestUserAuthController {

	private static UserAuthController controller;
	@BeforeAll
	static void setUpBeforeClass() {
		controller = new UserAuthController(); 
	}
	
	@DisplayName("Test user authentication from user data controller : Positive")
	@Test
	void test1() {
		UserModel userModel = new UserModel();
		userModel.setUserName("kinshuk.jain14");
		userModel.setPassword("kinshu123");
		try {
			assertTrue(controller.handleUserAuth(userModel));
		} catch (AuthenticationException e) {
			assertTrue(false);
		}
	}

	@DisplayName("Test user authentication from user data controller : Negative")
	@Test
	void test2() {
		UserModel userModel = new UserModel();
		userModel.setUserName("kinshuk.jain14");
		userModel.setPassword("kinshu");
		try {
			assertTrue(!controller.handleUserAuth(userModel));
		} catch (AuthenticationException e) {
		}
		assertTrue(true);
	}

	@DisplayName("Test user authentication controller : Exception")
	@Test
	void test3() {
		UserModel userModel = new UserModel();
		userModel.setUserName("kinshuk.jain14");
		userModel.setPassword("kinshu");
		try {
			controller.handleUserAuth(userModel);
			assertTrue(false);
		} catch (AuthenticationException e) {
			assertEquals("== Invalid username or password ==",e.getMessage());
		}
	}
	
	@AfterAll
	static void tearDownAfterClass() {
		controller=null;
	}


}
