package com.yash.configuration;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
//import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

//@EnableWebSecurity
//@EnableGlobalMethodSecurity(securedEnabled = true)
//public class InMemoryAuthenticationConfig extends WebSecurityConfigurerAdapter{
public class InMemoryAuthenticationConfig{
	
//	@Autowired
//	AuthenticationEntryPoint authenticationEntryPoint;
//	
//	@Override
//	protected void configure(HttpSecurity http) throws Exception {
//		http.cors()
//		.and()
//		.authorizeRequests()
//		.anyRequest()
//		.authenticated()
//		.and()
//		.httpBasic()
//		.authenticationEntryPoint(authenticationEntryPoint);
//		
//	}
//	
//	@Autowired
//	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
//		auth
//		.inMemoryAuthentication()
//		.withUser("user")
//		.password("{noop}user123")
//		.roles("userrole")
//		.authorities("READ_PRIVILEGES")
//		.and()
//		.withUser("admin")
//		.password("{noop}admin123")
//		.credentialsExpired(false)
//		.accountExpired(false)
//		.accountLocked(false)
//		.roles("adminrole")
//		.authorities("WRITE_PRIVILEGES","READ_PRIVILEGES");
//	}
}
