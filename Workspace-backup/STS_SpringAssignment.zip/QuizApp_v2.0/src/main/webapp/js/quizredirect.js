$(document).ready(function() {
    $("#Java").on("click",function(){
        window.open("QuizStarter.jsp?module=Java","_blank");
    });
    $("#SQL").on("click",function(){
        window.open("QuizStarter.jsp?module=SQL","_blank");
    });
    $("#HTML").on("click",function(){
        window.open("QuizStarter.jsp?module=HTML","_blank");
    });
    $("#CSS").on("click",function(){
        window.open("QuizStarter.jsp?module=CSS","_blank");
    });
})