package com.yash.main;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.yash.dao.JDBCQuizQuestionsDAOImpl;
import com.yash.entities.Module;
import com.yash.entities.Option;
import com.yash.entities.Question;
import com.yash.exception.DAOException;

public class QuestionQuestionsMain
{
	public static void main(String[] args) throws DAOException 
	{
		Configuration configuration = new Configuration();
		configuration.configure();
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Module module = (Module) session.get(Module.class, 1);
		
		System.out.println("Module Name : "+module.getModuleName());
		System.out.println("Module Id : "+module.getModuleId());
		System.out.println("Questions : ");
		List<Question> questions = module.getQuestions();
		int i=1;
		for (Question question : questions) {
			System.out.println(i+" . "+question.getQuestion());
			List<Option> optionsList = question.getOptionsList();
			System.out.println("SIZE : "+optionsList.size());
			int j=1;
			for (Option option : optionsList) {
				System.out.println("  "+j+" ."+option.getOptionDescription()+" ---- "+option.isCorrect());
				j++;
			}
			i++;
		}
	}
}
