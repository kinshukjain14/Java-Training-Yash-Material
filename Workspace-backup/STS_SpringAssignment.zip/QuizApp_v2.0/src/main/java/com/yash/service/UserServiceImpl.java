package com.yash.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.yash.dao.UserDAO;
import com.yash.entities.User;
import com.yash.exception.AuthenticationException;
import com.yash.exception.DAOException;
import com.yash.exception.UserAlreadyExistException;
import com.yash.exception.UserRegistrationException;
import com.yash.model.UserModel;

@Service
public class UserServiceImpl implements UserService {

//	@Autowired@Qualifier("jDBCUserDAOImpl")
	@Autowired@Qualifier("hibernateUserDAOImpl")
	private UserDAO userDAO;
	
	public UserServiceImpl() {
		super();
	}

	@Override
	public UserModel authenticateUser(String userName, String password) throws AuthenticationException {
		UserModel model = new UserModel();
			try {
				Optional<User> userCredentials = userDAO.checkUserCredentials(userName, password);
				if(userCredentials.isPresent()) {
					User user = userCredentials.get();
					System.out.println(user);
					model.setFirstName(user.getFirstName());
					model.setLastName(user.getLastName());
					model.setContactNo(user.getContactNo());
					model.setEmail(user.getEmail());
					model.setAddress(user.getAddress());
					model.setDateOfBirth(user.getDateOfBirth());
					model.setCountry(user.getCountryId().toString());
					model.setState(user.getStateId().toString());
					model.setCity(user.getCityId().toString());
					model.setUserName(user.getUserName());
					model.setUserId(user.getUserId());
					model.setPassword(user.getPassword());
					model.setGender(user.getGender());
					model.setRegisteredOn(user.getRegisteredOn());
					model.setLastLogin(user.getLastLogin());
				}
				else
					throw new AuthenticationException("== Invalid username or password ==");
			} catch (DAOException e) {
				
			}
		return model;
	}

	@Override
	public boolean addUserRegistration(UserModel usermodel) throws UserRegistrationException, UserAlreadyExistException {
		try {
			int countryId = 0;
			System.out.println("Usermodel : "+usermodel);
			if(usermodel.getCountry()!=null) {
				countryId = Integer.parseInt(usermodel.getCountry());
			}
			int stateId = 0;
			if(usermodel.getState()!=null) {
				stateId = Integer.parseInt(usermodel.getState());
			}
			int cityId = 0;
			if(usermodel.getCity()!=null) {
				cityId = Integer.parseInt(usermodel.getCity());
			}
			User user = new User();
					
			user.setUserId(usermodel.getUserId());
			user.setUserName(usermodel.getUserName());
			user.setPassword(usermodel.getPassword());
			user.setFirstName(usermodel.getFirstName());
			user.setLastName(usermodel.getLastName());
			user.setEmail(usermodel.getEmail());
			user.setContactNo(usermodel.getContactNo());
			user.setGender(usermodel.getGender());
			user.setDateOfBirth(usermodel.getDateOfBirth());
			user.setAddress(usermodel.getAddress());
			user.setCountryId(countryId);
			user.setStateId(stateId);
			user.setCityId(cityId);
			user.setRegisteredOn(usermodel.getRegisteredOn());
			user.setLastLogin(usermodel.getLastLogin());
			return userDAO.registerUser(user);
		} catch (DAOException e) 
		{
			e.printStackTrace();
			throw new UserRegistrationException("Unable to register user data");
		} catch (UserAlreadyExistException e) {
			e.printStackTrace();
			throw e;
		}		
	}

	@Override
	public boolean checkUserEmail(String email) {
		return userDAO.checkEmailAvailable(email);
	
	}

	@Override
	public boolean checkUserContact(Long contactNo) {
		return userDAO.checkContactNumberAvailable(contactNo);
	}
	
	

}
