package com.yash.service;

import com.yash.model.QuizScoreModel;

public interface QuizScoreServices {
	public boolean addQuizScore(QuizScoreModel model);
	public String getQuizScore(int userId);
}
