package com.yash.main;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.yash.entities.Module;
import com.yash.entities.Question;

public class FetchModuleId {
	public static void main(String[] args) {
		Configuration configuration = new Configuration();
		configuration.configure();
		SessionFactory sessionFactory = configuration.buildSessionFactory();
		Session session = sessionFactory.openSession();
		Query<?> query = session.createQuery("from Module o where o.moduleName=:name");
		query.setParameter("name","SQL");
		Module module = (Module) query.getSingleResult();
		
		System.out.println(module.getModuleId());
		List<Question> questions = module.getQuestions();
		for (Question question : questions) {
			System.out.println(question.getQuestion());
		}
	}
}
