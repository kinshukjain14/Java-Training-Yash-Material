package com.yash.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.yash.dao.QuizScoresDAO;
import com.yash.entities.Module;
import com.yash.entities.QuizScores;
import com.yash.entities.User;
import com.yash.exception.DAOException;
import com.yash.model.QuizScoreModel;

@Service
public class QuizScoreServiceImpl implements QuizScoreServices {

//	@Autowired@Qualifier("jDBCQuizScoresDAOImpl")
	@Autowired@Qualifier("hibernateQuizScoreDAOImpl")
	private QuizScoresDAO quizScoresDAO;
	
	public QuizScoreServiceImpl() {
	}
	
	@Override
	public boolean addQuizScore(QuizScoreModel model) 
	{
		QuizScores quizScores = new QuizScores();
		User user = new User();
		Module module = new Module();
		user.setUserId(model.getUserId());
		module.setModuleId(model.getModuleId());
		module.setModuleName(model.getModuleName());
		quizScores.setUser(user);
		quizScores.setModule(module);
		quizScores.setCandidateId(model.getCandidateId());
		quizScores.setPercentage(model.getPercentage());
		quizScores.setStatus(model.getStatus());
		quizScores.setTime_taken(model.getTime_taken());
		quizScores.setAppeared_on(model.getAppeared_on());
		quizScores.setGrade(model.getGrade());
		try {
			return quizScoresDAO.saveQuizScores(quizScores);
		} catch (DAOException e) {
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public String getQuizScore(int userId) {
		String quizScoresJson = "{}";
		try {
			ObjectMapper mapper = new ObjectMapper();
			mapper.registerModule(new JavaTimeModule());
			List<QuizScores> quizScores = quizScoresDAO.fetchQuizScores(userId);
			quizScoresJson = mapper.writeValueAsString(quizScores);
		} catch (DAOException e) {
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return quizScoresJson;
	}

}
