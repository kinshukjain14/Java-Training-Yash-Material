package com.yash.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.yash.exception.QuestionParsingException;
import com.yash.model.ModuleDataModel;
import com.yash.service.QuizServices;

@Controller
public class QuizQuestionController {
	@Autowired
	private QuizServices quizServices;
//	
//	@RequestMapping(value = "quizstarter.asp" ,method = RequestMethod.GET)
//	public String loadQuizStarterPage() {
//		return "QuizStarter";
//	}
	
	@RequestMapping(value = "loadquiz.asp",method = RequestMethod.GET,
			produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ModuleDataModel handleQuizQuestionsLoading(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		String moduleName = request.getParameter("module");
		ModuleDataModel subjectQuestions = null;
		try {
			subjectQuestions = quizServices.getModuleQuestions(moduleName);
			session.setAttribute("moduleDetails",subjectQuestions);
			
		} catch (QuestionParsingException e) {
			e.printStackTrace();
		}
		return subjectQuestions;
	}
}
