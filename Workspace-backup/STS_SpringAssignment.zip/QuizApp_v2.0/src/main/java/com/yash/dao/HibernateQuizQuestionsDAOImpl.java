package com.yash.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.yash.entities.Module;
import com.yash.exception.DAOException;

@Repository("hibernateQuizQuestionsDAOImpl")
public class HibernateQuizQuestionsDAOImpl implements QuizQuestionsDAO {

	@Autowired@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Override
	public Module retriveModuleQuestions(String subjectName) throws DAOException {
		Session session = sessionFactory.openSession();
		Query<?> query = session.createQuery("from Module o where o.moduleName=:moduleName");
		query.setParameter("moduleName",subjectName);
		Module module = (Module) query.getSingleResult();
		session.close();
		return module;
	}
	
}
