package com.yash.controller;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.yash.model.CitiesModel;
import com.yash.model.StatesModel;
import com.yash.service.LocationService;

@Controller
public class LocationController {
	@Autowired@Qualifier("locationServiceImpl")
	private LocationService locationService;
	
	@RequestMapping(value = "location.asp" , method = RequestMethod.POST , produces = "application/json")
	@ResponseBody
	public List<?> getData(HttpServletRequest request) {
		String type = request.getParameter("type");
		String code = request.getParameter("code");
		int id = Integer.parseInt(code);
		if(type.equals("country")) {
			List<StatesModel> states = locationService.getStates(id);
			return states;
		}
		else if(type.equals("state")) {
			List<CitiesModel> cities = locationService.getCities(id);
			return cities;
		}
		return Arrays.asList(" No Data ");
	}
}
