package com.yash.controller;

import java.time.LocalDateTime;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.yash.exception.AuthenticationException;
import com.yash.exception.UserAlreadyExistException;
import com.yash.exception.UserRegistrationException;
import com.yash.model.CountriesModel;
import com.yash.model.UserModel;
import com.yash.service.LocationService;
import com.yash.service.UserService;

@Controller
public class UserAuthController {
	
	@Autowired
	private UserService userService;
	
	@Autowired@Qualifier("locationServiceImpl")
	private LocationService locationService;
	
	@Autowired@Qualifier("userModelValidator")
	private Validator validator;
	
	private final String AUTH_PASS = "{\"successflag\":\"true\"}";
	private final String AUTH_FAIL = "{\"successflag\":\"false\"}";
	private final String USER_DATA_EXIST = "{\"successflag\":\"false\",\"message\":\"Email or Contact no. already registered!!\"}";
	private final String USER_DATA_FAIL = "{\"successflag\":\"false\",\"message\":\"Unable to register user!!\"}";

	@RequestMapping(value = "dashboard.asp",method = RequestMethod.GET)
	public String loadDashboard() {
		return "Dashboard";
	}
	
	@RequestMapping(value = "signout.asp", method=RequestMethod.GET)
	public String signOutUser(HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		session.invalidate();
		return "SignIn";
	}
	
	@RequestMapping(value = "signin.asp", method=RequestMethod.GET)
	public String loadSignInForm() {
		return "SignIn";
	}
	
	@RequestMapping(value = "authenticate.asp", method = RequestMethod.POST,
					consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
					produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String handleUserAuthentication(HttpServletRequest request) {
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		try {
			UserModel userData = userService.authenticateUser(userName, password);
			if (userData.getUserId() != 0) {
				System.out.println(userData);
				HttpSession session = request.getSession(true);
				session.setAttribute("userData", userData);
				return AUTH_PASS;
			}
		} catch (AuthenticationException e) {
		}
		return AUTH_FAIL;
	}
	
	@RequestMapping(value = "signup.asp",method = RequestMethod.GET)
	public String loadSignUpform() {
		return "SignUp";
	}
	
	@ModelAttribute("countriesModel")
	public List<CountriesModel> getCountriesList(){
		List<CountriesModel> countries = locationService.getCountries();
		return countries;
	}
	
	@RequestMapping(value = "validateemail.asp",method = RequestMethod.POST)
	@ResponseBody
	public String handleEmailValidation(@RequestParam("email") String email) {
		if(email.equals("")) {
			return "";
		}
		if(userService.checkUserEmail(email)) {
			return "Email already registered";
		}
		return "";
	}
	
	@RequestMapping(value = "validatecontact.asp", method = RequestMethod.POST)
	@ResponseBody
	public String handleContactValidation(@RequestParam("contact") String contact) 
	{
		System.out.println("Contact no : passed"+contact);
		if(contact.equals("")) {
			return "";
		}
		long contactNo = Long.parseLong(contact);
		if(userService.checkUserContact(contactNo)) {
			return "Contact no. already registered";			
		}
		return "";
	}
	
	@RequestMapping(value = "register.asp", method = RequestMethod.POST,
			consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String handleUserDataStore(@ModelAttribute("userModel") UserModel userModel,Errors errors) 
	{
		ValidationUtils.invokeValidator(validator, userModel, errors);
		userModel.setRegisteredOn(LocalDateTime.now());
		userModel.setLastLogin(LocalDateTime.now());
		if(errors.hasErrors()) {
			return USER_DATA_EXIST;
		}
		try {
			if(userService.addUserRegistration(userModel)) {
				return AUTH_PASS;
			}
		} catch (UserRegistrationException e) {
			e.printStackTrace();
		} catch (UserAlreadyExistException e) {
			e.printStackTrace();
			return USER_DATA_EXIST;
		}
		return USER_DATA_FAIL;
	}
	
//	@RequestMapping(value = "register.asp", method = RequestMethod.POST,
//			consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
//			produces = MediaType.APPLICATION_JSON_VALUE)
//	@ResponseBody
//	public String handleUserDataStore(HttpServletRequest request) 
//	{
//		UserModel userModel = new UserModel();
//		String firstName = request.getParameter("firstName");
//		String lastName = request.getParameter("lastName");
//		String contact = request.getParameter("contact");
//		String email = request.getParameter("email");
//		String password = request.getParameter("password");
//		String gender = request.getParameter("gender");
//		String dateOfBirth = request.getParameter("dateOfBirth");
//		DateTimeFormatter pattern = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//		LocalDate birthDate = LocalDate.parse(dateOfBirth, pattern);
//		String address = request.getParameter("address");
//		String countries = request.getParameter("country");
//		String states = request.getParameter("state");
//		String cities = request.getParameter("city");
//
//		userModel.setFirstName(firstName);
//		userModel.setLastName(lastName);
//		userModel.setContactNo(Long.parseLong(contact));
//		userModel.setUserId((int) (Math.random() * 1000000000));
//		userModel.setEmail(email);
//		userModel.setPassword(password);
//		userModel.setUserName(email);
//		userModel.setRegisteredOn(LocalDateTime.now());
//		userModel.setLastLogin(LocalDateTime.now());
//		userModel.setGender(gender);
//		userModel.setDateOfBirth(birthDate);
//		userModel.setAddress(address);
//		userModel.setCountry(countries);
//		userModel.setState(states);
//		userModel.setCity(cities);		
//		try {
//			if(userService.addUserRegistration(userModel)) {
//				return AUTH_PASS;
//			}
//		} catch (UserRegistrationException e) {
//			e.printStackTrace();
//		} catch (UserAlreadyExistException e) {
//			e.printStackTrace();
//			return USER_DATA_EXIST;
//		}
//		return USER_DATA_FAIL;
//	}
	
	
}
