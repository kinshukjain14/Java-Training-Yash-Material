package com.yash.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.yash.entities.Module;
import com.yash.entities.QuizScores;
import com.yash.entities.User;
import com.yash.exception.DAOException;

@Repository("hibernateQuizScoreDAOImpl")
public class HibernateQuizScoreDAOImpl implements QuizScoresDAO {

	@Autowired@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@Override
	public boolean saveQuizScores(QuizScores score) throws DAOException {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.getTransaction();
		transaction.begin();
		session.persist(score);
		transaction.commit();
		QuizScores quizScores = (QuizScores)session.get(QuizScores.class, score.getCandidateId());
		session.close();
		if(quizScores.getCandidateId() == score.getCandidateId()) {
			return true;
		}
		return false;
	}

	@Override
	public List<QuizScores> fetchQuizScores(int userId) throws DAOException {
		Session session = sessionFactory.openSession();
		Query<?> query = session.createQuery("from QuizScores o where o.user.userId=?1");
		query.setParameter(1, userId);
		List<QuizScores> quizScoresList = (List<QuizScores>) query.getResultList();
		for (QuizScores quizScores : quizScoresList) 
		{
			Module module = quizScores.getModule();
			module.setQuestions(null);
		}
		session.close();
		return quizScoresList;
	}

}
