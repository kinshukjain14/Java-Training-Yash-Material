package com.yash.controller;

import java.time.LocalDate;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.yash.model.ModuleDataModel;
import com.yash.model.QuizScoreModel;
import com.yash.model.UserModel;
import com.yash.service.QuizScoreServices;

@Controller
public class QuizScoreController 
{
	@Autowired
	private QuizScoreServices quizScoreServices;
	
	@RequestMapping(value = "fetch.asp", method = RequestMethod.GET,
			produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String getQuizScores(@RequestParam("user") String user) {
		int userId=0;
    	if(user!=null) {
    		userId=Integer.parseInt(user);
    	}
    	String quizScore = quizScoreServices.getQuizScore(userId);
    	return quizScore;
	}
	
	@RequestMapping(value = "save.asp",method = RequestMethod.POST
			,produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public String storeQuizScores(HttpServletRequest request) {
		Integer correct = Integer.parseInt(request.getParameter("correct"));
		Integer totalAttempt = Integer.parseInt(request.getParameter("totalAttempt"));
		Integer totalQuestions = Integer.parseInt(request.getParameter("totalQuestions"));
		Integer unattempted = totalQuestions - totalAttempt;
		Double percentage = (double)((correct * 100)/totalQuestions); 
		String grade = getGrades(percentage);
		String status ="FAIL";
		if(percentage >= 80.0 ) {
			status="PASS";
		}
		HttpSession session = request.getSession(false);
		ModuleDataModel moduleDetails = (ModuleDataModel) session.getAttribute("moduleDetails");
		UserModel userData = (UserModel) session.getAttribute("userData");
		Integer userId = userData.getUserId() ;
		String candidateName =userData.getFirstName()+" "+userData.getLastName();
		String candidate = request.getParameter("candidateID");
		Long candidateId = 0l;
		if(candidate !=null) {
			candidateId=Long.parseLong(candidate);
		}
		int moduleId = moduleDetails.getModuleId();
		String moduleName = moduleDetails.getModuleName();
		String time = request.getParameter("timeTaken");
		Integer timeTaken =0;
		if(time != null) {
			timeTaken = Integer.parseInt(time);
		}
		LocalDate appearedOn = LocalDate.now();
		
		QuizScoreModel model = new QuizScoreModel();
		model.setUserId(userId);
		model.setCandidateId(candidateId);
		model.setCandidateName(candidateName);
		model.setModuleId(moduleId);
		model.setModuleName(moduleName);
		model.setPercentage(percentage);
		model.setStatus(status);
		model.setGrade(grade);
		model.setTime_taken(timeTaken);
		model.setAppeared_on(appearedOn);
		String responseText="";
		if(quizScoreServices.addQuizScore(model)) {
			responseText = "{" + 
					"    \"responseText\":\"true\"," + 
					"    \"moduleName\": \""+moduleName+"\"," + 
					"    \"candidateId\": \""+candidateId+"\"," + 
					"    \"percentage\": \""+percentage+"\"," + 
					"    \"attempted\": \""+totalAttempt+"\"," + 
					"    \"unanswered\": \""+unattempted+"\"," + 
					"    \"correct\": \""+correct+"\"," + 
					"    \"status\": \""+status+"\"," + 
					"    \"grade\": \""+grade+"\"" + 
					"}";
		}
		else {
			responseText = "{\"responseText\":\"false\"}";
		}
		return responseText;
	}
	
	private String getGrades(double percentage) {
		if(percentage > 90)
			return "A";
		else if(percentage > 80 && percentage<=90)
			return "B";	
		else if(percentage > 70 && percentage<=80)
			return "C";
		else if(percentage > 60 && percentage<=70)
			return "D";
		else if(percentage > 50 && percentage<=60)
			return "E";
		else 
			return "F";
	}
}
