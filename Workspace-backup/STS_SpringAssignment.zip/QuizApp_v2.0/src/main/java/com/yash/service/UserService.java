package com.yash.service;

import com.yash.exception.AuthenticationException;
import com.yash.exception.UserAlreadyExistException;
import com.yash.exception.UserRegistrationException;
import com.yash.model.UserModel;

public interface UserService {
	public UserModel authenticateUser(String userName,String password) throws AuthenticationException;
//	public UserModel sendUserData(int userId) throws UserDataNotFoundException;
	public boolean addUserRegistration(UserModel user) throws UserRegistrationException, UserAlreadyExistException;
	public boolean checkUserEmail(String email);
	public boolean checkUserContact(Long contactNo);
}
