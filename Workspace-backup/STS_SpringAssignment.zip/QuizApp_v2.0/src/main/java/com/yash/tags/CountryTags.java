package com.yash.tags;

import java.io.IOException;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyTagSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.yash.configuration.QuizAppConfiguration;
import com.yash.model.CountriesModel;
import com.yash.service.LocationService;

public class CountryTags extends BodyTagSupport{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
//	@Autowired@Qualifier("locationServiceImpl")
	private LocationService locationService;
	
	
	@Override
	public int doEndTag() throws JspException {
		System.out.println(locationService);
//		AnnotationConfigApplicationContext ioc = new AnnotationConfigApplicationContext(QuizAppConfiguration.class);
//		locationService = (LocationService) ioc.getBean("locationService");
		List<CountriesModel> countries = locationService.getCountries();
		JspWriter out = pageContext.getOut();
		try {
			out.write("<select class='fields' id='countries' name='countries'>");
			out.write("<option value='-1'>( Select )</option>");
				countries.forEach((x)->{
					try {
						out.write("<option value='"+x.getCountryId()+"'>"+x.getCountryName()+"</option>");
					} catch (IOException e) {
						e.printStackTrace();
					}
				});
			out.write("</select>");
		} catch (IOException e) {
			e.printStackTrace();
		}
//		ioc.registerShutdownHook();
		return EVAL_PAGE;
	}
}
