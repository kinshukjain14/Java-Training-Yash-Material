package com.yash.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.yash.model.UserModel;
import com.yash.service.UserService;

@Component("userModelValidator")
public class UserModelValidator implements Validator{
	
	@Autowired
	private UserService userService;

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.equals(UserModel.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		UserModel model = (UserModel) target;
		if(userService.checkUserEmail(model.getEmail())) {
			errors.rejectValue("email","com.yash.model.UserModel.email.error","com.yash.model.UserModel.email.error");
		}
		if(userService.checkUserContact(model.getContactNo())) {
			errors.rejectValue("contactNo","com.yash.model.UserModel.contactNo.error","com.yash.model.UserModel.email.error");
		}
	}

}
