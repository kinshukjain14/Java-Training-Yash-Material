package com.yash.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.yash.*")
public class EmployeeDbSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeDbSpringBootApplication.class, args);
	}

}
