package com.yash.model;

import java.util.List;

public class Employees {
	
	private List<AllEmployeesModel> employees;

	public List<AllEmployeesModel> getEmployees() {
		return employees;
	}

	public void setEmployees(List<AllEmployeesModel> employees) {
		this.employees = employees;
	}
	

}
