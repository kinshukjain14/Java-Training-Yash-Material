package com.yash.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.model.ManagersModel;
import com.yash.service.EmployeesService;

@RestController
@RequestMapping("api")
@CrossOrigin(origins = "*")
public class ManagerController {
	
	@Autowired
	private EmployeesService employeesService;
	
	@GetMapping("managers")
	public ResponseEntity<List<ManagersModel>> handleGetAllManagers(){
		List<ManagersModel> managersList=employeesService.getManagers();
		ResponseEntity<List<ManagersModel>> response=null;
		if(!managersList.isEmpty()) {
			response=new ResponseEntity<List<ManagersModel>>(managersList,HttpStatus.OK);
		}else {
			response=new ResponseEntity<List<ManagersModel>>(HttpStatus.NOT_FOUND);

		}
		
		return response;
	}

}
